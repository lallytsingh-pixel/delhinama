import { useState, useEffect, useCallback, useRef } from "react";

/* ═══════════════════════════════════════════════════
   CONSTANTS & CONFIG
═══════════════════════════════════════════════════ */
const C = {
  R:"#C41E28",GOLD:"#C8962E",BG:"#060608",CARD:"#0E0E12",CARD2:"#141418",
  W:"#EDE9E4",MUTED:"#606060",BORDER:"#1A1A1E",BORDER2:"#222228",
  GREEN:"#16A34A",BLUE:"#1D4ED8",PURPLE:"#7C3AED",TEAL:"#0D9488",
  ORANGE:"#EA580C",PINK:"#DB2777",YELLOW:"#CA8A04"
};

/* ─── Storage ─── */
const SK = {
  articles:"dnh:v3:articles", breaking:"dnh:v3:breaking", bole:"dnh:v3:bole",
  theme:"dnh:v3:theme", features:"dnh:v3:features", users:"dnh:v3:users",
  session:"dnh:v3:session", election:"dnh:v3:election", wards:"dnh:v3:wards",
  membership:"dnh:v3:membership", factchecks:"dnh:v3:factchecks",
  awards:"dnh:v3:awards", events:"dnh:v3:events", sponsored:"dnh:v3:sponsored",
  newsletter:"dnh:v3:newsletter", telegram:"dnh:v3:telegram",
  wardnews:"dnh:v3:wardnews", polls:"dnh:v3:polls",
};
const dbGet = async (k,fb) => { try { const r=await window.storage.get(k); return r?JSON.parse(r.value):fb; } catch { return fb; } };
const dbSet = async (k,v) => { try { await window.storage.set(k,JSON.stringify(v)); return true; } catch { return false; } };

/* ─── Delhi 272 Wards ─── */
const DELHI_WARDS = {
  "मध्य दिल्ली": ["आदर्श नगर","शालीमार बाग","शकूरपुर","वज़ीरपुर","सुभाष नगर","तागोर गार्डन","हरि नगर","तिलक नगर","जनकपुरी","त्रिनगर","पटेल नगर","बलबीर नगर","रजेंद्र नगर","करोल बाग"],
  "उत्तरी दिल्ली": ["मॉडल टाउन","मुखर्जी नगर","सरस्वती विहार","अशोक विहार","रोहिणी","पीतमपुरा","संजय गांधी ट्रांसपोर्ट नगर","बुराड़ी","तिमारपुर","मेहरौली","सदर बाजार","किशनगंज","कमला नगर","शास्त्री नगर"],
  "दक्षिणी दिल्ली": ["ग्रेटर कैलाश","मालवीय नगर","साकेत","वसंत कुंज","R.K. पुरम","छतरपुर","तुगलकाबाद","बदरपुर","अंबेडकर नगर","संगम विहार","देवली","कालकाजी","ओखला","नेहरू प्लेस"],
  "पूर्वी दिल्ली": ["पटपड़गंज","मयूर विहार","कोंडली","त्रिलोकपुरी","शाहदरा","विवेक विहार","गांधी नगर","सीमापुरी","नंद नगरी","मंडावली","करावल नगर","जाफराबाद","मुस्तफाबाद","बाबरपुर"],
  "पश्चिमी दिल्ली": ["राजौरी गार्डन","मोती नगर","कीर्ति नगर","विकासपुरी","उत्तम नगर","बिंदापुर","द्वारका","मटियाला","नजफगढ़","पालम","बिजवासन","महरौली","सागरपुर","पंजाबी बाग"],
  "उत्तर-पूर्वी दिल्ली": ["सीलमपुर","घोंडा","गोकलपुरी","मुस्तफाबाद","करावल नगर","भजनपुरा","यमुना विहार","गांधी नगर","शाहदरा","वेलकम","सीमापुरी","रोहतास नगर","विश्वास नगर","कृष्णा नगर"],
  "उत्तर-पश्चिमी दिल्ली": ["नरेला","बवाना","मुंडका","किरारी","रिठाला","बादली","अलीपुर","सन्त नगर","बुराड़ी","भलस्वा जहाँगीरपुरी","सुल्तानपुर माजरा","मंगोलपुरी","रानी बाग","हिरन कुडाना"],
  "नई दिल्ली": ["कनॉट प्लेस","चांदनी चौक","दरिया गंज","लाल किला","बल्लीमारान","मटिया महल","हौज काजी","काली बाड़ी","जामा मस्जिद","राजगढ़"],
  "दक्षिण-पश्चिमी दिल्ली": ["महरौली","देवली","अंबेडकर नगर","छतरपुर","बिजवासन","पालम","उत्तम नगर","मटियाला","नजफगढ़","द्वारका सेक्टर 10"],
  "दक्षिण-पूर्वी दिल्ली": ["त्रिलोकपुरी","कोंडली","पटपड़गंज","न्यू अशोक नगर","मयूर विहार फेज 1","मयूर विहार फेज 2","साहिबाबाद","लक्ष्मी नगर","विश्वकर्मा नगर","करकरडूमा"],
  "शाहदरा": ["शाहदरा","सीमापुरी","रोहतास नगर","विश्वास नगर","कृष्णा नगर","गांधी नगर","सीलमपुर","घोंडा","नंद नगरी","मुस्तफाबाद"],
};
const ALL_WARDS = Object.values(DELHI_WARDS).flat();

/* ─── Default Feature Flags ─── */
const DEFAULT_FEATURES = {
  election:false, wardLevel:true, tts:true, premium:true, factCheck:true,
  awards:true, events:true, sponsored:true, newsletter:true, telegram:false,
  liveTV:true, breakingTicker:true, polls:true, bole:true, reels:false,
};

/* ─── Seed Data ─── */
const SEED_ARTICLES = [
  { id:1, title:"दिल्ली का AQI 412 पार — NGT का सम-विषम आदेश जारी", category:"दिल्ली", tag:"ब्रेकिंग", author:"विशेष संवाददाता", excerpt:"प्रदूषण की आपात स्थिति में NGT ने दिल्ली सरकार को आदेश दिए।", date:"2025-05-27", status:"published", views:24400, featured:true, ward:"पटपड़गंज", factCheck:"verified", premium:false },
  { id:2, title:"PM मोदी का विपक्ष पर तीखा हमला: 'देश को गुमराह करना बंद करो'", category:"राजनीति", tag:"BJP", author:"राजनीतिक संवाददाता", excerpt:"प्रधानमंत्री ने लोकसभा में विपक्ष को कड़ा जवाब दिया।", date:"2025-05-27", status:"published", views:18900, ward:null, factCheck:"pending", premium:false },
  { id:3, title:"[PREMIUM] Delhi Budget 2025: शिक्षा पर ₹16,000 करोड़ — पूरा विश्लेषण", category:"बाजार", tag:"विशेष", author:"वरिष्ठ संवाददाता", excerpt:"दिल्ली बजट का गहरा विश्लेषण — किसे क्या मिला।", date:"2025-05-26", status:"published", views:5600, ward:null, factCheck:"verified", premium:true },
  { id:4, title:"शाहदरा में टूटी सड़क — 3 महीने से शिकायत, कोई सुनवाई नहीं", category:"दिल्ली", tag:"शहर", author:"शाहदरा संवाददाता", excerpt:"शाहदरा के वार्ड 41 में सड़क टूटी है।", date:"2025-05-26", status:"published", views:9200, ward:"शाहदरा", factCheck:"pending", premium:false },
];
const SEED_BREAKING = [
  { id:1, text:"दिल्ली AQI 412 — NGT ने सम-विषम लागू करने के आदेश दिए" },
  { id:2, text:"संसद में विपक्ष का हंगामा, कार्यवाही स्थगित" },
  { id:3, text:"सेंसेक्स 400 अंक ऊपर — IT और फार्मा में तेजी" },
];
const SEED_ELECTION = {
  name:"दिल्ली विधानसभा चुनाव 2025", date:"फरवरी 2025", status:"completed",
  seats: [
    { id:1, name:"शाहदरा", winner:"AAP", candidate:"Rituraj Govind", votes:52840, runner:"BJP", runnerVotes:41200 },
    { id:2, name:"पटपड़गंज", winner:"AAP", candidate:"Awadh Ojha", votes:61200, runner:"BJP", runnerVotes:48900 },
    { id:3, name:"करावल नगर", winner:"BJP", candidate:"Mohan Singh Bisht", votes:71000, runner:"AAP", runnerVotes:52000 },
    { id:4, name:"बुराड़ी", winner:"AAP", candidate:"Sanjeev Jha", votes:58400, runner:"BJP", runnerVotes:44200 },
    { id:5, name:"मुस्तफाबाद", winner:"Congress", candidate:"Ali Mehdi", votes:49800, runner:"BJP", runnerVotes:47200 },
    { id:6, name:"सीलमपुर", winner:"AAP", candidate:"Abdul Rehman", votes:55600, runner:"BJP", runnerVotes:38400 },
  ],
  summary:{ total:70, AAP:44, BJP:22, Congress:3, Other:1 }
};
const SEED_AWARDS = [
  { id:1, month:"मई 2025", winner:"रमेश शर्मा", area:"पटपड़गंज", post:"6 महीने से टूटी सड़क — अंततः BMC ने ध्यान दिया", votes:1240, status:"announced" },
];
const SEED_EVENTS = [
  { id:1, title:"दिल्ली पत्रकारिता सम्मेलन 2025", date:"2025-06-15", time:"10:00 AM", venue:"India Habitat Centre, Lodhi Road", category:"कॉन्फ्रेंस", price:0, tickets:200, sold:142, description:"दिल्ली के पत्रकारों का वार्षिक सम्मेलन — डिजिटल मीडिया पर चर्चा", status:"active" },
  { id:2, title:"Sufi Evenings @ Hauz Khas", date:"2025-06-20", time:"7:00 PM", venue:"Hauz Khas Village, South Delhi", category:"संगीत", price:499, tickets:500, sold:312, description:"दिल्ली की शाम — सूफी संगीत के साथ।", status:"active" },
  { id:3, title:"दिल्ली फूड फेस्टिवल", date:"2025-07-04", time:"12:00 PM", venue:"JLN Stadium", category:"खाना", price:199, tickets:2000, sold:890, description:"दिल्ली के 50+ street food vendors एक जगह।", status:"active" },
];
const SEED_SPONSORED = [
  { id:1, brand:"HDFC Bank", title:"होम लोन पर 8.5% — दिल्लीवालों के लिए Special Offer", content:"HDFC Bank अब दिल्ली में 8.5% पर होम लोन दे रहा है। 31 मई तक apply करें।", category:"Finance", status:"active", badge:"Sponsored" },
];
const SEED_PLANS = [
  { id:"basic", name:"Basic", price:0, label:"Free", color:C.MUTED, features:["सभी खबरें","Breaking News","बोले फ्री","Polls","Ward News"] },
  { id:"plus", name:"Delhinama Plus", price:49, label:"₹49/माह", color:C.BLUE, features:["Basic सब कुछ","Ad-free reading","Premium Articles","Monthly Digest Email","TTS Priority"] },
  { id:"pro", name:"Delhinama Pro", price:99, label:"₹99/माह", color:C.GOLD, features:["Plus सब कुछ","Exclusive Analysis","Election Dashboard Pro","Reporter से सीधी बात","Badge on Profile","Events Discount 20%"] },
];
const SEED_USERS = [
  { id:1, username:"admin", password:"delhinama@123", name:"Admin", role:"admin", active:true },
  { id:2, username:"editor1", password:"editor@123", name:"Priya Sharma", role:"editor", active:true },
];
const SEED_FACTCHECKS = [
  { id:1, claim:"दिल्ली में मेट्रो का किराया दोगुना होने वाला है", verdict:"झूठ", explanation:"DMRC ने कोई ऐसी घोषणा नहीं की। यह अफवाह है।", source:"DMRC Official", date:"2025-05-25", category:"परिवहन" },
  { id:2, claim:"NGT ने दिल्ली में सभी प्राइवेट गाड़ियों पर बैन लगाया", verdict:"भ्रामक", explanation:"NGT ने केवल सम-विषम लागू किया है, पूर्ण बैन नहीं।", source:"NGT Order", date:"2025-05-27", category:"पर्यावरण" },
];
const SEED_WARDNEWS = {
  "शाहदरा": [ { id:1, title:"शाहदरा मेट्रो स्टेशन के पास सड़क धंसी — 2 दुकानें क्षतिग्रस्त", date:"2025-05-27" }, { id:2, title:"शाहदरा में नया पार्क बनेगा — DDA का एलान", date:"2025-05-26" } ],
  "पटपड़गंज": [ { id:1, title:"पटपड़गंज में 30 घंटे बिजली गुल — BSES का जवाब नहीं", date:"2025-05-27" }, { id:2, title:"पटपड़गंज मेट्रो लाइन विस्तार जल्द — CM का आश्वासन", date:"2025-05-25" } ],
  "रोहिणी": [ { id:1, title:"रोहिणी में नया अस्पताल खुलेगा — 200 बेड का", date:"2025-05-26" } ],
};

const ROLES = { admin:{label:"Admin",color:C.R,icon:"👑"}, editor:{label:"Editor",color:C.GOLD,icon:"✍️"}, reporter:{label:"Reporter",color:C.BLUE,icon:"📰"} };
const PARTY_COLORS = { AAP:"#0087E0", BJP:"#FF6B20", Congress:"#1060C0", Other:C.MUTED };

/* ═══════════════════════════════════════════════════
   SHARED UI
═══════════════════════════════════════════════════ */
const G_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&family=Noto+Serif+Devanagari:wght@700;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
@keyframes fadeIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes ticker{from{transform:translateX(0)}to{transform:translateX(-50%)}}
@keyframes slideUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
::-webkit-scrollbar{width:3px;height:3px}::-webkit-scrollbar-thumb{background:#222}
.rh:hover{background:${C.CARD2}!important}
.btn{border:none;border-radius:7px;padding:8px 15px;font-size:12px;font-weight:700;cursor:pointer;font-family:'Noto Sans Devanagari',sans-serif;transition:opacity .15s;display:inline-flex;align-items:center;gap:6px}
.btn:hover{opacity:.85}.btn:disabled{opacity:.5;cursor:default}
.btn-r{background:${C.R};color:#fff}.btn-g{background:${C.GREEN};color:#fff}
.btn-b{background:${C.BLUE};color:#fff}.btn-p{background:${C.PURPLE};color:#fff}
.btn-gold{background:${C.GOLD};color:#fff}.btn-ghost{background:transparent;border:1px solid ${C.BORDER2};color:${C.MUTED}}
.btn-teal{background:${C.TEAL};color:#fff}
.inp{width:100%;background:${C.CARD2};border:1px solid ${C.BORDER2};border-radius:7px;padding:9px 12px;color:${C.W};font-size:13px;outline:none;font-family:'Noto Sans Devanagari',sans-serif}
.inp:focus{border-color:${C.PURPLE}88}
select.inp option{background:${C.CARD2}}
textarea.inp{resize:vertical;min-height:80px}
`;

function Toast({msg,type}) { const col={error:C.R,warn:C.GOLD,info:C.BLUE,success:C.GREEN}[type]||C.GREEN; return msg?<div style={{position:"fixed",bottom:24,right:24,background:col,color:"#fff",padding:"10px 20px",borderRadius:8,fontSize:12,fontFamily:"sans-serif",fontWeight:700,zIndex:9999,boxShadow:"0 4px 24px #0009",animation:"slideUp .3s"}}>{msg}</div>:null; }
function Toggle({val,onChange,color=C.GREEN}) { return <div onClick={()=>onChange(!val)} style={{width:38,height:21,borderRadius:11,background:val?color:C.BORDER2,position:"relative",cursor:"pointer",transition:"background .2s",flexShrink:0}}><div style={{width:15,height:15,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:val?20:3,transition:"left .2s"}}></div></div>; }
function Badge({text,color=C.MUTED,small}) { return <span style={{fontSize:small?9:10,fontWeight:700,padding:"2px 8px",borderRadius:4,fontFamily:"sans-serif",background:(color||C.MUTED)+"22",color:color||C.MUTED,border:`1px solid ${(color||C.MUTED)}33`,whiteSpace:"nowrap"}}>{text}</span>; }
function Lbl({t}) { return <label style={{fontSize:10,color:C.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:5,letterSpacing:.4}}>{t}</label>; }
function Spin() { return <div style={{width:14,height:14,border:`2px solid ${C.BORDER2}`,borderTopColor:C.PURPLE,borderRadius:"50%",animation:"spin .7s linear infinite",display:"inline-block"}}></div>; }
function SHead({icon,label,color=C.GOLD,sub}) { return <div style={{borderLeft:`3px solid ${color||C.GOLD}`,paddingLeft:12,marginBottom:18}}><div style={{fontSize:15,fontWeight:700,color:C.W}}>{icon} {label}</div>{sub&&<div style={{fontSize:11,color:C.MUTED,marginTop:2,fontFamily:"sans-serif"}}>{sub}</div>}</div>; }
function Card({children,style,border}) { return <div style={{background:C.CARD,border:`1px solid ${border||C.BORDER}`,borderRadius:10,padding:16,...style}}>{children}</div>; }
function StatBox({icon,label,value,sub,color=C.W,trend}) {
  return <Card><div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}><span style={{fontSize:20}}>{icon}</span>{trend&&<span style={{fontSize:11,fontFamily:"sans-serif",color:trend>0?C.GREEN:C.R,fontWeight:600}}>{trend>0?"↑":"↓"}{Math.abs(trend)}%</span>}</div><div style={{fontSize:22,fontWeight:700,color,fontFamily:"sans-serif",marginTop:8,marginBottom:2}}>{value}</div><div style={{fontSize:12,fontWeight:600,color:C.W}}>{label}</div>{sub&&<div style={{fontSize:10,color:C.MUTED,marginTop:2,fontFamily:"sans-serif"}}>{sub}</div>}</Card>;
}

/* ═══════════════════════════════════════════════════
   TTS HOOK
═══════════════════════════════════════════════════ */
function useTTS() {
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);
  const speak = useCallback((text) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = "hi-IN"; utt.rate = 0.9; utt.pitch = 1;
    const voices = window.speechSynthesis.getVoices();
    const hiVoice = voices.find(v=>v.lang==="hi-IN"||v.lang.startsWith("hi"));
    if (hiVoice) utt.voice = hiVoice;
    utt.onstart = ()=>setSpeaking(true);
    utt.onend = ()=>{ setSpeaking(false); setPaused(false); };
    utt.onerror = ()=>{ setSpeaking(false); setPaused(false); };
    window.speechSynthesis.speak(utt);
  }, []);
  const pause = () => { window.speechSynthesis.pause(); setPaused(true); };
  const resume = () => { window.speechSynthesis.resume(); setPaused(false); };
  const stop = () => { window.speechSynthesis.cancel(); setSpeaking(false); setPaused(false); };
  return { speak, pause, resume, stop, speaking, paused };
}

function TTSButton({text,color}) {
  const { speak,pause,resume,stop,speaking,paused } = useTTS();
  if (!("speechSynthesis" in window)) return null;
  return (
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      {!speaking ? (
        <button onClick={()=>speak(text)} style={{background:(color||C.TEAL)+"22",border:`1px solid ${(color||C.TEAL)}44`,color:color||C.TEAL,borderRadius:6,padding:"5px 12px",cursor:"pointer",fontSize:11,fontFamily:"sans-serif",fontWeight:600,display:"flex",alignItems:"center",gap:5}}>
          🔊 सुनें
        </button>
      ) : (
        <>
          <button onClick={paused?resume:pause} style={{background:C.GOLD+"22",border:`1px solid ${C.GOLD}44`,color:C.GOLD,borderRadius:6,padding:"5px 10px",cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>{paused?"▶ जारी रखें":"⏸ रुकें"}</button>
          <button onClick={stop} style={{background:C.R+"22",border:`1px solid ${C.R}44`,color:C.R,borderRadius:6,padding:"5px 10px",cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>⏹ बंद करें</button>
        </>
      )}
      {speaking&&<span style={{fontSize:10,color:C.TEAL,fontFamily:"sans-serif",animation:"pulse 1s infinite"}}>● पढ़ा जा रहा है...</span>}
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   PUBLIC WEBSITE
═══════════════════════════════════════════════════ */
function Website({onGoAdmin}) {
  const [articles,setArticles] = useState(SEED_ARTICLES);
  const [breaking,setBreaking] = useState(SEED_BREAKING);
  const [features,setFeatures] = useState(DEFAULT_FEATURES);
  const [tick,setTick] = useState(0);
  const [tickOn,setTickOn] = useState(true);
  const [activeNav,setActiveNav] = useState("होम");
  const [selectedWard,setSelectedWard] = useState("शाहदरा");
  const [wardNews,setWardNews] = useState(SEED_WARDNEWS);
  const [election,setElection] = useState(SEED_ELECTION);
  const [factChecks,setFactChecks] = useState(SEED_FACTCHECKS);
  const [events,setEvents] = useState(SEED_EVENTS);
  const [sponsored,setSponsored] = useState(SEED_SPONSORED);
  const [awards,setAwards] = useState(SEED_AWARDS);
  const [plans] = useState(SEED_PLANS);
  const [selectedPlan,setSelectedPlan] = useState("basic");
  const [userPlan,setUserPlan] = useState("basic");
  const [newsletter,setNewsletter] = useState({email:"",name:""});
  const [nlSent,setNlSent] = useState(false);
  const [polls,setPolls] = useState([{id:1,q:"दिल्ली की सबसे बड़ी समस्या?",opts:["प्रदूषण","ट्रैफिक","बिजली-पानी","महंगाई"],votes:[1240,890,1100,760],active:true}]);
  const [pollVoted,setPollVoted] = useState(null);
  const [activePage,setActivePage] = useState("home");

  const load = useCallback(async()=>{
    const [a,b,f,el,wn,fc,ev,sp,aw,po] = await Promise.all([
      dbGet(SK.articles,SEED_ARTICLES), dbGet(SK.breaking,SEED_BREAKING),
      dbGet(SK.features,DEFAULT_FEATURES), dbGet(SK.election,SEED_ELECTION),
      dbGet(SK.wardnews,SEED_WARDNEWS), dbGet(SK.factchecks,SEED_FACTCHECKS),
      dbGet(SK.events,SEED_EVENTS), dbGet(SK.sponsored,SEED_SPONSORED),
      dbGet(SK.awards,SEED_AWARDS), dbGet(SK.polls,[]),
    ]);
    setArticles(a); setBreaking(b); setFeatures(f); setElection(el);
    setWardNews(wn); setFactChecks(fc); setEvents(ev); setSponsored(sp);
    setAwards(aw); if(po.length) setPolls(po);
  },[]);

  useEffect(()=>{ load(); const iv=setInterval(load,4000); return ()=>clearInterval(iv); },[load]);
  useEffect(()=>{
    if(!breaking.length) return;
    const iv=setInterval(()=>{ setTickOn(false); setTimeout(()=>{ setTick(t=>(t+1)%breaking.length); setTickOn(true); },250); },5000);
    return ()=>clearInterval(iv);
  },[breaking]);

  const pub = articles.filter(a=>a.status==="published");
  const hero = pub.find(a=>a.featured)||pub[0];
  const sideArts = pub.filter(a=>a.id!==hero?.id).slice(0,4);
  const pr = "#C41E28", ac = "#C8962E";

  const verdictColor = v => v==="सच"?C.GREEN:v==="झूठ"?C.R:C.ORANGE;
  const verdictEmoji = v => v==="सच"?"✅":v==="झूठ"?"❌":"⚠️";

  return (
    <div style={{background:C.BG,color:C.W,fontFamily:"'Noto Sans Devanagari',sans-serif",minHeight:"100vh"}}>
      {/* TOP BAR */}
      <div style={{background:"#000",borderBottom:`1px solid #1a1a1a`,padding:"4px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>
        <div style={{display:"flex",gap:14,alignItems:"center"}}>
          <span>मंगलवार, 27 मई 2025</span>
          <span style={{color:"#333"}}>│</span>
          <span>🌡 दिल्ली 38°C</span>
          <span style={{color:"#333"}}>│</span>
          <span>AQI: <b style={{color:"#E05030"}}>187</b></span>
          {features.election&&election&&<><span style={{color:"#333"}}>│</span><span onClick={()=>setActivePage("election")} style={{color:C.GOLD,cursor:"pointer",fontWeight:700}}>🗳️ चुनाव परिणाम</span></>}
        </div>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          {features.premium&&userPlan!=="basic"&&<Badge text="★ PRO" color={C.GOLD} />}
          <span onClick={()=>setActivePage("premium")} style={{cursor:"pointer",color:C.GOLD,fontSize:11}}>💎 Premium</span>
          <span style={{color:"#333"}}>│</span>
          <span onClick={onGoAdmin} style={{cursor:"pointer",color:C.MUTED}}>🔐 Admin</span>
        </div>
      </div>

      {/* HEADER */}
      <div style={{background:C.CARD,borderBottom:`2.5px solid ${pr}`,padding:"10px 18px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:100}}>
        <div onClick={()=>setActivePage("home")} style={{cursor:"pointer"}}>
          <div style={{fontSize:26,fontWeight:900,color:pr,fontFamily:"'Noto Serif Devanagari',serif"}}>दिल्लीनामा</div>
          <div style={{fontSize:8.5,color:ac,letterSpacing:3.5,fontFamily:"sans-serif",marginTop:2}}>DELHINAMA • दिल्ली की असली आवाज़</div>
        </div>
        <div style={{flex:1,maxWidth:300,margin:"0 20px",background:C.CARD2,border:`1px solid ${C.BORDER2}`,borderRadius:7,padding:"6px 12px",display:"flex",alignItems:"center",gap:8}}>
          <span style={{color:C.MUTED}}>🔍</span><span style={{fontSize:13,color:C.MUTED}}>खोजें...</span>
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <button onClick={()=>setActivePage("events")} className="btn btn-ghost" style={{fontSize:11,padding:"5px 12px"}}>📅 Events</button>
          <button onClick={()=>setActivePage("factcheck")} className="btn btn-ghost" style={{fontSize:11,padding:"5px 12px"}}>✅ Fact-Check</button>
          <button onClick={()=>setActivePage("newsletter")} className="btn btn-r" style={{fontSize:11,padding:"5px 12px"}}>📧 Subscribe</button>
        </div>
      </div>

      {/* BREAKING */}
      {features.breakingTicker&&breaking.length>0&&(
        <div style={{background:pr,display:"flex",alignItems:"stretch",minHeight:32}}>
          <div style={{background:"#8B0000",padding:"6px 14px",fontSize:11,fontWeight:700,color:"#fff",letterSpacing:1,fontFamily:"sans-serif",display:"flex",alignItems:"center",gap:5,whiteSpace:"nowrap"}}>
            <span style={{width:6,height:6,borderRadius:"50%",background:"#fff",display:"inline-block",animation:"pulse 1s infinite"}}></span>BREAKING
          </div>
          <div style={{padding:"6px 16px",fontSize:13,color:"#fff",flex:1,animation:tickOn?"fadeIn .3s":"none"}}>{breaking[tick]?.text}</div>
        </div>
      )}

      {/* NAV */}
      <div style={{background:C.CARD,borderBottom:`1px solid ${C.BORDER}`,overflowX:"auto",scrollbarWidth:"none"}}>
        <div style={{display:"flex",padding:"0 6px",minWidth:"max-content"}}>
          {["होम","देश","विदेश","राजनीति","दिल्ली","बाजार","मनोरंजन","टेक","शिक्षा","यात्रा",
            ...(features.wardLevel?["📍 वार्ड न्यूज़"]:[]),
            ...(features.election&&election?["🗳️ चुनाव"]:[]),
            ...(features.factCheck?["✅ Fact-Check"]:[]),
            ...(features.awards?["🏆 Awards"]:[]),
          ].map(n=>(
            <div key={n} onClick={()=>{ setActiveNav(n); if(n==="📍 वार्ड न्यूज़") setActivePage("ward"); else if(n==="🗳️ चुनाव") setActivePage("election"); else if(n==="✅ Fact-Check") setActivePage("factcheck"); else if(n==="🏆 Awards") setActivePage("awards"); else setActivePage("home"); }} style={{padding:"8px 13px",cursor:"pointer",fontSize:12.5,fontWeight:500,color:activeNav===n?ac:C.MUTED,borderBottom:activeNav===n?`2px solid ${ac}`:"2px solid transparent",whiteSpace:"nowrap",transition:"all .15s"}}>{n}</div>
          ))}
        </div>
      </div>

      <div style={{maxWidth:1280,margin:"0 auto",padding:"16px 16px"}}>

      {/* ═══ HOME PAGE ═══ */}
      {activePage==="home"&&(
        <div style={{animation:"fadeIn .3s"}}>
          {/* Hero */}
          {hero&&(
            <div style={{display:"grid",gridTemplateColumns:"3fr 2fr",gap:14,marginBottom:20}}>
              <div style={{borderRadius:10,overflow:"hidden",background:C.CARD,border:`1px solid ${C.BORDER}`,cursor:"pointer"}}>
                <div style={{height:280,background:"linear-gradient(160deg,#2d0609 0%,#090810 55%,#180a00 100%)",position:"relative",display:"flex",flexDirection:"column",justifyContent:"flex-end"}}>
                  <div style={{position:"absolute",inset:0,background:"linear-gradient(to top,#000000f0 0%,transparent 60%)"}}></div>
                  <div style={{position:"absolute",top:12,left:12,display:"flex",gap:6}}>
                    <Badge text={hero.tag} color={pr} />
                    {hero.premium&&<Badge text="★ PREMIUM" color={C.GOLD} />}
                    {hero.factCheck==="verified"&&<Badge text="✓ Verified" color={C.GREEN} />}
                  </div>
                  <div style={{position:"relative",zIndex:2,padding:"0 18px 16px"}}>
                    <div style={{fontSize:19,fontWeight:700,lineHeight:1.45,color:"#fff",fontFamily:"'Noto Serif Devanagari',serif",marginBottom:8}}>{hero.title}</div>
                    <div style={{fontSize:12,color:"#c8c4bf",lineHeight:1.6,marginBottom:8}}>{hero.excerpt}</div>
                    {features.tts&&<TTSButton text={hero.title+" "+hero.excerpt} color={C.TEAL} />}
                    <div style={{fontSize:10,color:C.MUTED,marginTop:6,fontFamily:"sans-serif"}}>{hero.date} • {hero.author} • 👁 {hero.views?.toLocaleString()}</div>
                  </div>
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {sideArts.map((a,i)=>(
                  <div key={a.id} style={{background:C.CARD,borderRadius:8,border:`1px solid ${C.BORDER}`,display:"flex",overflow:"hidden",cursor:"pointer"}}>
                    <div style={{width:76,minWidth:76,background:["#0a1230","#200a0a","#0a1a0e","#0e0a1e"][i],display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>
                      {["📰","🗺️","📈","✈️"][i]}
                    </div>
                    <div style={{padding:"9px 11px",flex:1}}>
                      <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:4}}>
                        <Badge text={a.category} color={pr} small />
                        {a.premium&&<Badge text="PRO" color={C.GOLD} small />}
                      </div>
                      <div style={{fontSize:12.5,fontWeight:600,lineHeight:1.4,color:C.W}}>{a.title}</div>
                      {features.tts&&<div style={{marginTop:6}}><TTSButton text={a.title} color={C.TEAL} /></div>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Sponsored Banner */}
          {features.sponsored&&sponsored.filter(s=>s.status==="active").map(sp=>(
            <div key={sp.id} style={{background:`linear-gradient(135deg,${C.GOLD}11,${C.CARD})`,border:`1px dashed ${C.GOLD}44`,borderRadius:10,padding:"12px 16px",marginBottom:18,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                  <Badge text="Sponsored" color={C.GOLD} />
                  <Badge text={sp.brand} color={C.MUTED} />
                </div>
                <div style={{fontSize:14,fontWeight:700,color:C.W}}>{sp.title}</div>
                <div style={{fontSize:12,color:C.MUTED,marginTop:3}}>{sp.content}</div>
              </div>
              <button className="btn btn-gold" style={{fontSize:11,padding:"6px 14px",whiteSpace:"nowrap",marginLeft:16}}>जानें →</button>
            </div>
          ))}

          {/* Articles Grid */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:20}}>
            {pub.slice(0,6).map(a=>(
              <Card key={a.id} style={{cursor:"pointer"}}>
                <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8,flexWrap:"wrap"}}>
                  <Badge text={a.category} color={pr} />
                  {a.premium&&<Badge text="★ PRO" color={C.GOLD} />}
                  {a.factCheck==="verified"&&<Badge text="✓ Verified" color={C.GREEN} />}
                  {a.ward&&<Badge text={`📍 ${a.ward}`} color={C.TEAL} />}
                </div>
                <div style={{fontSize:13,fontWeight:600,lineHeight:1.5,color:C.W,marginBottom:6}}>{a.title}</div>
                {a.premium&&userPlan==="basic" ? (
                  <div style={{fontSize:11,color:C.GOLD,fontFamily:"sans-serif",background:C.GOLD+"11",padding:"6px 10px",borderRadius:6,textAlign:"center",border:`1px solid ${C.GOLD}33`}}>🔒 Premium Article — <span onClick={()=>setActivePage("premium")} style={{cursor:"pointer",textDecoration:"underline"}}>Upgrade करें</span></div>
                ) : (
                  <>
                    <div style={{fontSize:11,color:C.MUTED,lineHeight:1.5}}>{a.excerpt}</div>
                    {features.tts&&<div style={{marginTop:8}}><TTSButton text={a.title+" "+a.excerpt} color={C.TEAL} /></div>}
                  </>
                )}
                <div style={{fontSize:10,color:C.MUTED,marginTop:8,fontFamily:"sans-serif"}}>{a.date} • 👁 {a.views?.toLocaleString()}</div>
              </Card>
            ))}
          </div>

          {/* Polls */}
          {features.polls&&polls.filter(p=>p.active).map(poll=>(
            <Card key={poll.id} style={{marginBottom:18,border:`1px solid ${C.TEAL}33`}}>
              <div style={{fontSize:14,fontWeight:700,marginBottom:14}}>📊 आपकी राय: {poll.q}</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {poll.opts.map((opt,i)=>{
                  const total=poll.votes.reduce((s,v)=>s+v,0);
                  const pct=total?Math.round(poll.votes[i]/total*100):0;
                  return (
                    <div key={i} onClick={()=>{ if(pollVoted) return; setPollVoted(poll.id); setPolls(ps=>ps.map(p=>p.id===poll.id?{...p,votes:p.votes.map((v,j)=>j===i?v+1:v)}:p)); }} style={{border:`1.5px solid ${pollVoted===poll.id?C.TEAL:C.BORDER}`,borderRadius:8,padding:"10px 14px",cursor:pollVoted?"default":"pointer",background:pollVoted?C.TEAL+"11":"transparent",transition:"all .2s"}}>
                      <div style={{fontSize:13,color:C.W,marginBottom:pollVoted?6:0}}>{opt}</div>
                      {pollVoted&&<><div style={{height:4,background:C.BORDER2,borderRadius:2,marginTop:4}}><div style={{height:"100%",width:`${pct}%`,background:C.TEAL,borderRadius:2,transition:"width .5s"}}></div></div><div style={{fontSize:10,color:C.TEAL,marginTop:3,fontFamily:"sans-serif",fontWeight:700}}>{pct}%</div></>}
                    </div>
                  );
                })}
              </div>
              <div style={{fontSize:11,color:C.MUTED,marginTop:8,fontFamily:"sans-serif"}}>कुल {poll.votes.reduce((s,v)=>s+v,0).toLocaleString()} वोट</div>
            </Card>
          ))}

          {/* Newsletter */}
          {features.newsletter&&!nlSent&&activePage==="home"&&(
            <div style={{background:`linear-gradient(135deg,${C.R}11,${C.CARD})`,border:`1px solid ${C.R}33`,borderRadius:10,padding:20,marginBottom:18,textAlign:"center"}}>
              <div style={{fontSize:18,fontWeight:700,color:C.W,marginBottom:4}}>📧 दिल्लीनामा Newsletter</div>
              <div style={{fontSize:12,color:C.MUTED,marginBottom:16,fontFamily:"sans-serif"}}>रोज़ सुबह 8 बजे — दिल्ली की 5 ज़रूरी खबरें आपके inbox में</div>
              <div style={{display:"flex",gap:10,maxWidth:450,margin:"0 auto"}}>
                <input className="inp" value={newsletter.email} onChange={e=>setNewsletter({...newsletter,email:e.target.value})} placeholder="आपका email address..." />
                <button className="btn btn-r" style={{whiteSpace:"nowrap",padding:"9px 18px"}} onClick={async()=>{ if(newsletter.email.includes("@")){ const d=await dbGet(SK.newsletter,[]); await dbSet(SK.newsletter,[...d,{email:newsletter.email,date:new Date().toISOString().slice(0,10)}]); setNlSent(true); }}}>Subscribe करें</button>
              </div>
            </div>
          )}
          {nlSent&&<div style={{background:C.GREEN+"22",border:`1px solid ${C.GREEN}44`,borderRadius:8,padding:"12px 16px",marginBottom:18,textAlign:"center",fontSize:13,color:C.GREEN}}>✅ आप newsletter के लिए subscribe हो गए! कल सुबह 8 बजे पहला digest मिलेगा।</div>}
        </div>
      )}

      {/* ═══ WARD PAGE ═══ */}
      {activePage==="ward"&&features.wardLevel&&(
        <div style={{animation:"fadeIn .3s"}}>
          <SHead icon="📍" label="वार्ड-स्तरीय खबरें" color={C.TEAL} sub="Delhi ke 272 wards ki local news — apna ward chuniye" />
          <div style={{display:"grid",gridTemplateColumns:"1fr 3fr",gap:18}}>
            <div>
              <div style={{fontSize:12,fontWeight:700,color:C.W,marginBottom:10}}>जिला चुनें</div>
              {Object.entries(DELHI_WARDS).map(([dist,wards])=>(
                <div key={dist} style={{marginBottom:14}}>
                  <div style={{fontSize:11,color:C.GOLD,fontWeight:700,fontFamily:"sans-serif",marginBottom:6,letterSpacing:.3}}>{dist}</div>
                  <div style={{display:"flex",flexDirection:"column",gap:3}}>
                    {wards.slice(0,5).map(w=>(
                      <div key={w} onClick={()=>setSelectedWard(w)} style={{fontSize:12,padding:"5px 10px",borderRadius:6,cursor:"pointer",background:selectedWard===w?C.TEAL+"22":C.CARD2,border:`1px solid ${selectedWard===w?C.TEAL+"44":C.BORDER}`,color:selectedWard===w?C.W:C.MUTED,transition:"all .15s"}}>
                        {w}
                        {wardNews[w]&&<span style={{fontSize:9,color:C.TEAL,fontFamily:"sans-serif",marginLeft:5}}>●</span>}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div>
              <div style={{background:C.TEAL+"22",border:`1px solid ${C.TEAL}44`,borderRadius:10,padding:"12px 16px",marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{fontSize:16,fontWeight:700,color:C.W}}>📍 {selectedWard}</div>
                  <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginTop:2}}>{Object.entries(DELHI_WARDS).find(([_,ws])=>ws.includes(selectedWard))?.[0]}</div>
                </div>
                <Badge text={`${(wardNews[selectedWard]||[]).length} खबरें`} color={C.TEAL} />
              </div>
              {(wardNews[selectedWard]||[]).length>0 ? (
                wardNews[selectedWard].map(n=>(
                  <Card key={n.id} style={{marginBottom:10,cursor:"pointer"}}>
                    <Badge text={`📍 ${selectedWard}`} color={C.TEAL} />
                    <div style={{fontSize:13,fontWeight:600,color:C.W,marginTop:8,lineHeight:1.5}}>{n.title}</div>
                    {features.tts&&<div style={{marginTop:8}}><TTSButton text={n.title} /></div>}
                    <div style={{fontSize:10,color:C.MUTED,marginTop:6,fontFamily:"sans-serif"}}>{n.date}</div>
                  </Card>
                ))
              ) : (
                <div style={{textAlign:"center",padding:40,color:C.MUTED}}>
                  <div style={{fontSize:28,marginBottom:10}}>📍</div>
                  <div style={{fontSize:13}}>इस वार्ड की कोई खबर अभी नहीं है</div>
                  <div style={{fontSize:11,color:C.MUTED,marginTop:6,fontFamily:"sans-serif"}}>बोले फ्री पर अपने वार्ड की समस्या रिपोर्ट करें</div>
                </div>
              )}

              {/* Ward articles from main */}
              {pub.filter(a=>a.ward===selectedWard).map(a=>(
                <Card key={a.id} style={{marginBottom:10,cursor:"pointer",border:`1px solid ${C.TEAL}22`}}>
                  <Badge text={a.tag} color={pr} />
                  <div style={{fontSize:13,fontWeight:600,color:C.W,marginTop:8}}>{a.title}</div>
                  <div style={{fontSize:11,color:C.MUTED,marginTop:4,lineHeight:1.5}}>{a.excerpt}</div>
                  {features.tts&&<div style={{marginTop:8}}><TTSButton text={a.title+" "+a.excerpt} /></div>}
                </Card>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ═══ ELECTION DASHBOARD ═══ */}
      {activePage==="election"&&features.election&&election&&(
        <div style={{animation:"fadeIn .3s"}}>
          <SHead icon="🗳️" label={election.name} color={C.GOLD} sub={`${election.date} • ${election.status==="completed"?"परिणाम घोषित":"मतदान जारी"}`} />
          {/* Summary */}
          <div style={{background:`linear-gradient(135deg,${C.GOLD}11,${C.CARD})`,border:`1px solid ${C.GOLD}33`,borderRadius:10,padding:18,marginBottom:18}}>
            <div style={{fontSize:14,fontWeight:700,color:C.W,marginBottom:14}}>कुल 70 सीटें — पार्टी-वार परिणाम</div>
            <div style={{display:"flex",gap:0,height:28,borderRadius:8,overflow:"hidden",marginBottom:12}}>
              {Object.entries(election.summary).filter(([k])=>k!=="total").map(([party,seats])=>(
                <div key={party} style={{flex:seats,background:PARTY_COLORS[party],display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:"#fff",minWidth:seats>1?seats*5:0,transition:"flex .5s"}}>
                  {seats>2?`${party} ${seats}`:""}
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:16,flexWrap:"wrap"}}>
              {Object.entries(election.summary).filter(([k])=>k!=="total").map(([party,seats])=>(
                <div key={party} style={{display:"flex",alignItems:"center",gap:8}}>
                  <div style={{width:12,height:12,borderRadius:3,background:PARTY_COLORS[party]}}></div>
                  <span style={{fontSize:13,color:C.W,fontWeight:700}}>{party}</span>
                  <span style={{fontSize:16,fontWeight:900,color:PARTY_COLORS[party],fontFamily:"sans-serif"}}>{seats}</span>
                </div>
              ))}
            </div>
          </div>
          {/* Seat results */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
            {election.seats.map(s=>(
              <Card key={s.id} style={{border:`1px solid ${PARTY_COLORS[s.winner]}33`}}>
                <div style={{fontSize:12,fontWeight:700,color:C.MUTED,fontFamily:"sans-serif",marginBottom:6}}>{s.name} विधानसभा</div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                  <div>
                    <Badge text={`🏆 ${s.winner}`} color={PARTY_COLORS[s.winner]} />
                    <div style={{fontSize:13,fontWeight:700,color:C.W,marginTop:5}}>{s.candidate}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:16,fontWeight:900,color:PARTY_COLORS[s.winner],fontFamily:"sans-serif"}}>{s.votes.toLocaleString()}</div>
                    <div style={{fontSize:9,color:C.MUTED,fontFamily:"sans-serif"}}>वोट</div>
                  </div>
                </div>
                <div style={{height:4,background:C.BORDER2,borderRadius:2,marginBottom:6}}>
                  <div style={{height:"100%",width:`${(s.votes/(s.votes+s.runnerVotes)*100).toFixed(0)}%`,background:PARTY_COLORS[s.winner],borderRadius:2}}></div>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.MUTED,fontFamily:"sans-serif"}}>
                  <span>{s.runner}: {s.runnerVotes.toLocaleString()}</span>
                  <span>अंतर: {(s.votes-s.runnerVotes).toLocaleString()}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* ═══ FACT-CHECK ═══ */}
      {activePage==="factcheck"&&features.factCheck&&(
        <div style={{animation:"fadeIn .3s"}}>
          <SHead icon="✅" label="Fact-Check — सच या झूठ?" color={C.GREEN} sub="AI और पत्रकारों द्वारा verified — वायरल claims की जाँच" />
          {factChecks.map(fc=>(
            <Card key={fc.id} style={{marginBottom:14,border:`1px solid ${verdictColor(fc.verdict)}33`}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                <div style={{flex:1,marginRight:16}}>
                  <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginBottom:6}}>CLAIM</div>
                  <div style={{fontSize:14,fontWeight:700,color:C.W,lineHeight:1.5}}>"{fc.claim}"</div>
                </div>
                <div style={{textAlign:"center",flexShrink:0}}>
                  <div style={{fontSize:28}}>{verdictEmoji(fc.verdict)}</div>
                  <div style={{fontSize:13,fontWeight:900,color:verdictColor(fc.verdict),fontFamily:"sans-serif",marginTop:2}}>{fc.verdict}</div>
                </div>
              </div>
              <div style={{background:verdictColor(fc.verdict)+"11",border:`1px solid ${verdictColor(fc.verdict)}22`,borderRadius:7,padding:"10px 14px",marginBottom:10}}>
                <div style={{fontSize:12,color:C.W,lineHeight:1.6}}>{fc.explanation}</div>
              </div>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>
                <span>📚 Source: {fc.source}</span>
                <span>{fc.date} • {fc.category}</span>
              </div>
              {features.tts&&<div style={{marginTop:8}}><TTSButton text={`दावा: ${fc.claim}। हमारी जाँच: ${fc.verdict}। ${fc.explanation}`} /></div>}
            </Card>
          ))}
        </div>
      )}

      {/* ═══ EVENTS ═══ */}
      {activePage==="events"&&features.events&&(
        <div style={{animation:"fadeIn .3s"}}>
          <SHead icon="📅" label="Events & Tickets" color={C.PURPLE} sub="दिल्ली के आयोजन — Book करें, Attend करें" />
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14}}>
            {events.filter(e=>e.status==="active").map(ev=>(
              <Card key={ev.id} style={{border:`1px solid ${C.PURPLE}22`}}>
                <div style={{height:100,background:`linear-gradient(135deg,${C.PURPLE}33,${C.CARD2})`,borderRadius:8,marginBottom:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:36}}>
                  {{"कॉन्फ्रेंस":"🎤","संगीत":"🎵","खाना":"🍜"}[ev.category]||"📅"}
                </div>
                <Badge text={ev.category} color={C.PURPLE} />
                <div style={{fontSize:14,fontWeight:700,color:C.W,marginTop:8,lineHeight:1.4}}>{ev.title}</div>
                <div style={{fontSize:11,color:C.MUTED,marginTop:6,fontFamily:"sans-serif"}}>📅 {ev.date} • ⏰ {ev.time}</div>
                <div style={{fontSize:11,color:C.MUTED,marginTop:3,fontFamily:"sans-serif"}}>📍 {ev.venue}</div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:12}}>
                  <div>
                    <div style={{fontSize:18,fontWeight:900,color:ev.price===0?C.GREEN:C.GOLD,fontFamily:"sans-serif"}}>{ev.price===0?"FREE":`₹${ev.price}`}</div>
                    <div style={{fontSize:10,color:C.MUTED,fontFamily:"sans-serif"}}>{ev.sold}/{ev.tickets} seats</div>
                  </div>
                  <button className="btn" style={{background:ev.price===0?C.GREEN:C.PURPLE,color:"#fff",fontSize:11,padding:"6px 14px"}}>
                    {ev.price===0?"Register":"Book Now"}
                  </button>
                </div>
                <div style={{height:3,background:C.BORDER2,borderRadius:2,marginTop:10}}>
                  <div style={{height:"100%",width:`${(ev.sold/ev.tickets*100).toFixed(0)}%`,background:ev.sold/ev.tickets>0.8?C.R:C.GREEN,borderRadius:2}}></div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* ═══ AWARDS ═══ */}
      {activePage==="awards"&&features.awards&&(
        <div style={{animation:"fadeIn .3s"}}>
          <SHead icon="🏆" label="Citizen Journalism Awards" color={C.GOLD} sub="हर महीने — सबसे अच्छी नागरिक पत्रकारिता को सम्मान" />
          {awards.map(a=>(
            <Card key={a.id} style={{marginBottom:14,background:`linear-gradient(135deg,${C.GOLD}11,${C.CARD})`,border:`1px solid ${C.GOLD}44`}}>
              <div style={{display:"flex",alignItems:"center",gap:14}}>
                <div style={{fontSize:50}}>🏆</div>
                <div style={{flex:1}}>
                  <Badge text={`${a.month} का पुरस्कार`} color={C.GOLD} />
                  <div style={{fontSize:18,fontWeight:700,color:C.W,marginTop:6}}>{a.winner}</div>
                  <div style={{fontSize:12,color:C.MUTED,marginTop:2,fontFamily:"sans-serif"}}>{a.area}</div>
                  <div style={{fontSize:13,color:C.W,marginTop:8,lineHeight:1.5,fontStyle:"italic"}}>"{a.post}"</div>
                  <div style={{fontSize:12,color:C.GOLD,marginTop:8,fontFamily:"sans-serif"}}>👍 {a.votes.toLocaleString()} community votes</div>
                </div>
              </div>
            </Card>
          ))}
          <Card style={{textAlign:"center",padding:24}}>
            <div style={{fontSize:16,fontWeight:700,marginBottom:8}}>अगले पुरस्कार के लिए Nominate करें</div>
            <div style={{fontSize:12,color:C.MUTED,marginBottom:14,fontFamily:"sans-serif"}}>बोले फ्री पर post करें — community vote करेगी — winner को ₹5,000 cash prize</div>
            <button className="btn btn-gold">📢 Nominate Now</button>
          </Card>
        </div>
      )}

      {/* ═══ PREMIUM ═══ */}
      {activePage==="premium"&&features.premium&&(
        <div style={{animation:"fadeIn .3s"}}>
          <SHead icon="💎" label="Premium Membership" color={C.GOLD} sub="Ad-free reading, exclusive content, और बहुत कुछ" />
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,marginBottom:20}}>
            {plans.map(plan=>(
              <Card key={plan.id} style={{border:`2px solid ${userPlan===plan.id?plan.color:C.BORDER}`,background:userPlan===plan.id?plan.color+"11":C.CARD,textAlign:"center",position:"relative"}}>
                {plan.id==="pro"&&<div style={{position:"absolute",top:-10,left:"50%",transform:"translateX(-50%)",background:C.GOLD,color:"#000",fontSize:9,fontWeight:900,padding:"2px 12px",borderRadius:10,fontFamily:"sans-serif",letterSpacing:.5,whiteSpace:"nowrap"}}>MOST POPULAR</div>}
                <div style={{fontSize:24,marginBottom:8}}>{plan.id==="basic"?"📖":plan.id==="plus"?"⭐":"💎"}</div>
                <div style={{fontSize:16,fontWeight:700,color:plan.color}}>{plan.name}</div>
                <div style={{fontSize:24,fontWeight:900,color:C.W,fontFamily:"sans-serif",margin:"10px 0"}}>{plan.label}</div>
                <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:16}}>
                  {plan.features.map(f=><div key={f} style={{fontSize:12,color:C.W,display:"flex",alignItems:"center",gap:6,justifyContent:"center"}}><span style={{color:plan.color}}>✓</span>{f}</div>)}
                </div>
                <button onClick={()=>{ setUserPlan(plan.id); setActivePage("home"); }} className="btn" style={{background:plan.color,color:"#fff",width:"100%",justifyContent:"center",opacity:userPlan===plan.id?0.6:1}} disabled={userPlan===plan.id}>
                  {userPlan===plan.id?"✓ Current Plan":"Select Plan"}
                </button>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* ═══ NEWSLETTER PAGE ═══ */}
      {activePage==="newsletter"&&features.newsletter&&(
        <div style={{animation:"fadeIn .3s",maxWidth:600,margin:"0 auto"}}>
          <SHead icon="📧" label="Newsletter Subscribe" color={C.R} />
          <Card>
            <div style={{fontSize:18,fontWeight:700,marginBottom:6}}>रोज़ सुबह दिल्ली की 5 खबरें</div>
            <div style={{fontSize:12,color:C.MUTED,marginBottom:20,fontFamily:"sans-serif"}}>8:00 AM को आपके inbox में। No spam. Unsubscribe anytime.</div>
            {!nlSent ? (
              <>
                <div style={{marginBottom:12}}><Lbl t="EMAIL *" /><input className="inp" value={newsletter.email} onChange={e=>setNewsletter({...newsletter,email:e.target.value})} placeholder="yourname@email.com" /></div>
                <div style={{marginBottom:16}}><Lbl t="NAME" /><input className="inp" value={newsletter.name} onChange={e=>setNewsletter({...newsletter,name:e.target.value})} placeholder="आपका नाम (optional)" /></div>
                <button className="btn btn-r" style={{width:"100%",justifyContent:"center",padding:"11px"}} onClick={async()=>{ if(!newsletter.email.includes("@")) return; const d=await dbGet(SK.newsletter,[]); await dbSet(SK.newsletter,[...d,{...newsletter,date:new Date().toISOString().slice(0,10)}]); setNlSent(true); }}>📧 Subscribe करें</button>
              </>
            ) : (
              <div style={{textAlign:"center",padding:24}}>
                <div style={{fontSize:36,marginBottom:10}}>✅</div>
                <div style={{fontSize:16,fontWeight:700,color:C.GREEN}}>Subscribe हो गए!</div>
                <div style={{fontSize:12,color:C.MUTED,marginTop:6,fontFamily:"sans-serif"}}>कल सुबह 8 बजे पहला digest मिलेगा।</div>
              </div>
            )}
          </Card>
        </div>
      )}

      </div>

      {/* FOOTER */}
      <div style={{background:"#000",borderTop:`2.5px solid ${pr}`,marginTop:28}}>
        <div style={{maxWidth:1280,margin:"0 auto",padding:"22px 16px 14px"}}>
          <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:24,marginBottom:18}}>
            <div>
              <div style={{fontSize:20,fontWeight:900,color:pr,fontFamily:"serif"}}>दिल्लीनामा</div>
              <div style={{fontSize:11,color:C.MUTED,lineHeight:1.65,maxWidth:260,marginTop:8}}>दिल्ली और देश की हर खबर — जनता की भाषा में।</div>
            </div>
            {[
              {h:"खबरें",items:["देश","राजनीति","दिल्ली","बाजार"]},
              {h:"Features",items:features.wardLevel?["Ward News","Fact-Check","Events","Awards"]:["Fact-Check","Events","Newsletter"]},
              {h:"Company",items:["हमारे बारे में","संपर्क","Advertise","Privacy"]},
            ].map((col,i)=>(
              <div key={i}><div style={{fontSize:12,fontWeight:700,color:C.W,marginBottom:10,paddingBottom:6,borderBottom:`1px solid ${C.BORDER}`}}>{col.h}</div>{col.items.map(item=><div key={item} style={{fontSize:12,color:C.MUTED,marginBottom:7,cursor:"pointer"}}>{item}</div>)}</div>
            ))}
          </div>
          <div style={{borderTop:`1px solid ${C.BORDER}`,paddingTop:12,display:"flex",justifyContent:"space-between",fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>
            <span>© 2025 Delhinama Media Pvt. Ltd.</span>
            <span style={{color:pr,fontWeight:700}}>दिल्ली की असली आवाज़</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   ADMIN PANEL
═══════════════════════════════════════════════════ */
function AdminPanel({onGoWebsite}) {
  const [screen,setScreen] = useState("boot");
  const [user,setUser] = useState(null);
  const [tab,setTab] = useState("features");
  const [toast,setToastS] = useState({msg:"",type:"success"});
  const showToast = (msg,type="success") => { setToastS({msg,type}); setTimeout(()=>setToastS({msg:"",type:""}),3000); };

  const [features,setFeatures] = useState(DEFAULT_FEATURES);
  const [articles,setArticles] = useState(SEED_ARTICLES);
  const [breaking,setBreaking] = useState(SEED_BREAKING);
  const [election,setElection] = useState(SEED_ELECTION);
  const [factChecks,setFactChecks] = useState(SEED_FACTCHECKS);
  const [events,setEvents] = useState(SEED_EVENTS);
  const [sponsored,setSponsored] = useState(SEED_SPONSORED);
  const [awards,setAwards] = useState(SEED_AWARDS);
  const [users,setUsers] = useState(SEED_USERS);
  const [newsletter,setNewsletter] = useState([]);
  const [wardNews,setWardNews] = useState(SEED_WARDNEWS);
  const [polls,setPolls] = useState([]);
  const [lf,setLf] = useState({u:"",p:"",rem:false});
  const [lerr,setLerr] = useState("");
  const [collapsed,setCollapsed] = useState(false);
  const [newBreak,setNewBreak] = useState("");
  const [newArt,setNewArt] = useState({title:"",category:"दिल्ली",tag:"ब्रेकिंग",author:"",excerpt:"",status:"published",featured:false,ward:"",premium:false,factCheck:"pending"});
  const [addArtOpen,setAddArtOpen] = useState(false);
  const [newEvent,setNewEvent] = useState({title:"",date:"",time:"",venue:"",category:"कॉन्फ्रेंस",price:0,tickets:100,description:""});
  const [addEventOpen,setAddEventOpen] = useState(false);
  const [newFC,setNewFC] = useState({claim:"",verdict:"झूठ",explanation:"",source:"",category:"सामान्य"});
  const [addFCOpen,setAddFCOpen] = useState(false);
  const [newSponsored,setNewSponsored] = useState({brand:"",title:"",content:"",category:"General"});
  const [addSponOpen,setAddSponOpen] = useState(false);
  const [newWardNews,setNewWardNews] = useState({ward:"शाहदरा",title:"",date:""});
  const [addWardOpen,setAddWardOpen] = useState(false);
  const [electionEdit,setElectionEdit] = useState(false);
  const [telegramBot,setTelegramBot] = useState({token:"",chatId:"",lastSent:""});
  const [telegramTest,setTelegramTest] = useState(false);

  const load = useCallback(async()=>{
    const [f,a,b,el,fc,ev,sp,aw,su,nl,wn,po,tb] = await Promise.all([
      dbGet(SK.features,DEFAULT_FEATURES), dbGet(SK.articles,SEED_ARTICLES),
      dbGet(SK.breaking,SEED_BREAKING), dbGet(SK.election,SEED_ELECTION),
      dbGet(SK.factchecks,SEED_FACTCHECKS), dbGet(SK.events,SEED_EVENTS),
      dbGet(SK.sponsored,SEED_SPONSORED), dbGet(SK.awards,SEED_AWARDS),
      dbGet(SK.users,SEED_USERS), dbGet(SK.newsletter,[]),
      dbGet(SK.wardnews,SEED_WARDNEWS), dbGet(SK.polls,[]),
      dbGet(SK.telegram,{token:"",chatId:"",lastSent:""}),
    ]);
    setFeatures(f); setArticles(a); setBreaking(b); setElection(el);
    setFactChecks(fc); setEvents(ev); setSponsored(sp); setAwards(aw);
    setUsers(su); setNewsletter(nl); setWardNews(wn);
    if(po.length) setPolls(po); setTelegramBot(tb);
  },[]);

  useEffect(()=>{
    (async()=>{
      let su=await dbGet(SK.users,null);
      if(!su){await dbSet(SK.users,SEED_USERS);su=SEED_USERS;}
      setUsers(su);
      const sess=await dbGet(SK.session,null);
      if(sess?.username){const u=su.find(x=>x.username===sess.username&&x.active);if(u){setUser(u);setScreen("admin");return;}}
      setScreen("login");
    })();
  },[]);
  useEffect(()=>{if(screen==="admin")load();},[screen,load]);

  const saveFeatures = async (f) => { setFeatures(f); await dbSet(SK.features,f); showToast("Feature update — Website पर live!"); };
  const saveArts = async (d) => { setArticles(d); await dbSet(SK.articles,d); };
  const saveBreak = async (d) => { setBreaking(d); await dbSet(SK.breaking,d); };
  const saveElection = async (d) => { setElection(d); await dbSet(SK.election,d); };
  const saveFC = async (d) => { setFactChecks(d); await dbSet(SK.factchecks,d); };
  const saveEvents = async (d) => { setEvents(d); await dbSet(SK.events,d); };
  const saveSponsored = async (d) => { setSponsored(d); await dbSet(SK.sponsored,d); };
  const saveWardNews = async (d) => { setWardNews(d); await dbSet(SK.wardnews,d); };

  const doLogin = async () => {
    setLerr("");
    const all=await dbGet(SK.users,SEED_USERS);
    const u=all.find(x=>x.username===lf.u&&x.password===lf.p&&x.active);
    if(!u){setLerr("गलत username या password");return;}
    if(lf.rem)await dbSet(SK.session,{username:u.username});
    setUser(u);setScreen("admin");
  };
  const doLogout = async () => { await dbSet(SK.session,null); setUser(null); setScreen("login"); };

  const sendTelegramTest = async () => {
    setTelegramTest(true);
    await new Promise(r=>setTimeout(r,1500));
    setTelegramTest(false);
    showToast("Telegram test message भेजी गई! (Demo)","info");
  };

  if(screen==="boot") return <div style={{background:C.BG,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",color:C.MUTED,fontFamily:"sans-serif",fontSize:13}}>Loading...</div>;

  if(screen==="login") return (
    <div style={{background:C.BG,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",padding:16,fontFamily:"'Noto Sans Devanagari',sans-serif"}}>
      <div style={{background:C.CARD,border:`1px solid ${C.BORDER2}`,borderRadius:14,padding:"36px 32px",width:"100%",maxWidth:400,animation:"slideUp .4s"}}>
        <div style={{textAlign:"center",marginBottom:26}}>
          <div style={{fontSize:24,fontWeight:900,color:C.R,fontFamily:"serif"}}>दिल्लीनामा</div>
          <div style={{fontSize:9,color:C.GOLD,letterSpacing:4,fontFamily:"sans-serif",marginTop:3}}>ADMIN PANEL</div>
          <div style={{fontSize:11,color:C.MUTED,marginTop:8,fontFamily:"sans-serif"}}>🔒 admin.delhinama.com</div>
        </div>
        <div style={{marginBottom:12}}><Lbl t="USERNAME"/><input className="inp" value={lf.u} onChange={e=>setLf({...lf,u:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="admin" /></div>
        <div style={{marginBottom:16}}><Lbl t="PASSWORD"/><input type="password" className="inp" value={lf.p} onChange={e=>setLf({...lf,p:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="••••••••" /></div>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:18,cursor:"pointer"}} onClick={()=>setLf({...lf,rem:!lf.rem})}>
          <div style={{width:16,height:16,borderRadius:4,border:`1.5px solid ${lf.rem?C.R:C.BORDER2}`,background:lf.rem?C.R+"33":"transparent",display:"flex",alignItems:"center",justifyContent:"center"}}>{lf.rem&&<span style={{fontSize:10,color:C.R,fontWeight:900}}>✓</span>}</div>
          <span style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>Login याद रखें</span>
        </div>
        {lerr&&<div style={{fontSize:12,color:C.R,marginBottom:12,background:C.R+"15",padding:"8px 12px",borderRadius:6,fontFamily:"sans-serif",textAlign:"center"}}>{lerr}</div>}
        <button className="btn btn-r" style={{width:"100%",justifyContent:"center",padding:"11px",fontSize:14}} onClick={doLogin}>Login करें →</button>
        <div style={{marginTop:16,background:C.CARD2,borderRadius:7,padding:"10px 12px",border:`1px solid ${C.BORDER}`}}>
          <div style={{fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginBottom:6,fontWeight:700}}>DEMO ACCOUNTS</div>
          {SEED_USERS.map(u=>(
            <div key={u.id} onClick={()=>setLf({u:u.username,p:u.password,rem:lf.rem})} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",cursor:"pointer",borderBottom:`1px solid ${C.BORDER}`,fontSize:12}}>
              <span style={{color:C.W,fontFamily:"sans-serif"}}>{ROLES[u.role].icon} {u.username}</span>
              <span style={{color:C.MUTED,fontFamily:"monospace"}}>{u.password}</span>
            </div>
          ))}
        </div>
        <div style={{textAlign:"center",marginTop:12}}><span onClick={onGoWebsite} style={{fontSize:11,color:C.MUTED,cursor:"pointer",fontFamily:"sans-serif"}}>← Website देखें</span></div>
      </div>
    </div>
  );

  const TABS = [
    {id:"features",icon:"🎛️",label:"Feature Control"},
    {id:"articles",icon:"📰",label:"खबरें"},
    {id:"breaking",icon:"🔴",label:"Breaking"},
    {id:"ward",icon:"📍",label:"Ward News"},
    {id:"election",icon:"🗳️",label:"Election"},
    {id:"factcheck",icon:"✅",label:"Fact-Check"},
    {id:"events",icon:"📅",label:"Events"},
    {id:"sponsored",icon:"💼",label:"Sponsored"},
    {id:"awards",icon:"🏆",label:"Awards"},
    {id:"newsletter",icon:"📧",label:"Newsletter"},
    {id:"telegram",icon:"✈️",label:"Telegram"},
    {id:"users",icon:"👥",label:"Users"},
  ].filter(t=>t.id!=="users"||user?.role==="admin");

  return (
    <div style={{background:C.BG,minHeight:"100vh",display:"flex",fontFamily:"'Noto Sans Devanagari',sans-serif",color:C.W}}>
      {/* SIDEBAR */}
      <div style={{width:collapsed?56:210,background:C.CARD,borderRight:`1px solid ${C.BORDER}`,display:"flex",flexDirection:"column",flexShrink:0,transition:"width .25s",overflow:"hidden"}}>
        <div style={{padding:collapsed?"14px 10px":"14px 14px 10px",borderBottom:`1px solid ${C.BORDER}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          {!collapsed&&<div><div style={{fontSize:16,fontWeight:900,color:C.R,fontFamily:"serif"}}>दिल्लीनामा</div><div style={{fontSize:7,color:C.GOLD,letterSpacing:3,fontFamily:"sans-serif",marginTop:2}}>ADMIN</div></div>}
          <button onClick={()=>setCollapsed(!collapsed)} style={{background:"transparent",border:"none",color:C.MUTED,cursor:"pointer",fontSize:14,padding:2,marginLeft:collapsed?0:"auto"}}>{collapsed?"▶":"◀"}</button>
        </div>
        <div style={{flex:1,padding:"6px 4px",overflowY:"auto"}}>
          {TABS.map(t=>(
            <div key={t.id} onClick={()=>setTab(t.id)} title={collapsed?t.label:""} style={{display:"flex",alignItems:"center",gap:8,padding:collapsed?"9px":"8px 10px",borderRadius:7,cursor:"pointer",marginBottom:2,background:tab===t.id?C.R+"22":"transparent",borderLeft:tab===t.id?`3px solid ${C.R}`:"3px solid transparent",transition:"all .15s",justifyContent:collapsed?"center":"flex-start"}}>
              <span style={{fontSize:14,flexShrink:0}}>{t.icon}</span>
              {!collapsed&&<span style={{fontSize:12,fontWeight:tab===t.id?700:500,color:tab===t.id?C.W:C.MUTED,whiteSpace:"nowrap"}}>{t.label}</span>}
            </div>
          ))}
        </div>
        <div style={{padding:"8px 5px",borderTop:`1px solid ${C.BORDER}`}}>
          {!collapsed&&<div onClick={onGoWebsite} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",borderRadius:7,cursor:"pointer",color:C.MUTED,fontSize:11,marginBottom:3}}><span>🌐</span><span>Website</span></div>}
          <div onClick={doLogout} title="Logout" style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",borderRadius:7,cursor:"pointer",color:C.MUTED,fontSize:11,justifyContent:collapsed?"center":"flex-start"}}><span>🚪</span>{!collapsed&&<span>Logout</span>}</div>
        </div>
      </div>

      {/* MAIN */}
      <div style={{flex:1,overflowY:"auto",overflowX:"hidden"}}>
        <div style={{background:C.CARD,borderBottom:`1px solid ${C.BORDER}`,padding:"10px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,zIndex:50}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:15}}>{TABS.find(t=>t.id===tab)?.icon}</span>
            <span style={{fontSize:14,fontWeight:700}}>{TABS.find(t=>t.id===tab)?.label}</span>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{fontSize:11,color:C.GREEN,fontFamily:"sans-serif",background:C.GREEN+"15",padding:"4px 10px",borderRadius:6,display:"flex",gap:5,alignItems:"center"}}>
              <span style={{width:6,height:6,borderRadius:"50%",background:C.GREEN,animation:"pulse 2s infinite"}}></span>
              Website Live Sync
            </div>
            <Badge text={ROLES[user?.role]?.label||"Admin"} color={ROLES[user?.role]?.color||C.R} />
          </div>
        </div>

        <div style={{padding:20}}>

        {/* ═══ FEATURE CONTROL CENTER ═══ */}
        {tab==="features"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="🎛️" label="Feature Control Center" color={C.PURPLE} sub="Website ke features yahan se ON/OFF karein — instantly live" />
            <div style={{background:C.PURPLE+"11",border:`1px solid ${C.PURPLE}33`,borderRadius:10,padding:"14px 18px",marginBottom:20,display:"flex",alignItems:"center",gap:12}}>
              <span style={{fontSize:24}}>⚡</span>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:C.W}}>Live Control Panel</div>
                <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>Toggle करते ही website पर 4-5 seconds में reflect होगा। No deployment needed.</div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
              {[
                {key:"breakingTicker",icon:"🔴",label:"Breaking News Ticker",desc:"Top par red banner — live ticker"},
                {key:"election",icon:"🗳️",label:"Election Dashboard",desc:"Chunav results, seat tracker activate karein"},
                {key:"wardLevel",icon:"📍",label:"Ward-Level News",desc:"272 Delhi wards ki local news section"},
                {key:"tts",icon:"🔊",label:"Hindi Text-to-Speech",desc:"Har article par 'Sunein' button"},
                {key:"premium",icon:"💎",label:"Premium Membership",desc:"Paid plans aur exclusive content"},
                {key:"factCheck",icon:"✅",label:"Fact-Check Section",desc:"Sach/Jhooth verification section"},
                {key:"awards",icon:"🏆",label:"Citizen Awards",desc:"Monthly journalism awards"},
                {key:"events",icon:"📅",label:"Events & Tickets",desc:"Delhi events aur ticket booking"},
                {key:"sponsored",icon:"💼",label:"Sponsored Content",desc:"Brand content with 'Sponsored' badge"},
                {key:"newsletter",icon:"📧",label:"Newsletter Subscribe",desc:"Email collection aur digest"},
                {key:"telegram",icon:"✈️",label:"Telegram Notifications",desc:"Har khabar Telegram par auto-bhejein"},
                {key:"polls",icon:"📊",label:"Reader Polls",desc:"Interactive polls on homepage"},
                {key:"bole",icon:"📢",label:"Bole Free Section",desc:"Citizen journalism platform"},
                {key:"liveTV",icon:"📺",label:"Live TV Button",desc:"Top bar mein Live TV indicator"},
              ].map(f=>(
                <div key={f.key} className="rh" style={{background:C.CARD,border:`1px solid ${features[f.key]?C.PURPLE+"44":C.BORDER}`,borderRadius:10,padding:"14px 16px",display:"flex",alignItems:"center",gap:12,transition:"border-color .2s",cursor:"default"}}>
                  <span style={{fontSize:22,flexShrink:0}}>{f.icon}</span>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:13,fontWeight:700,color:C.W}}>{f.label}</div>
                    <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginTop:2}}>{f.desc}</div>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
                    <span style={{fontSize:10,fontFamily:"sans-serif",color:features[f.key]?C.GREEN:C.MUTED}}>{features[f.key]?"ON":"OFF"}</span>
                    <Toggle val={features[f.key]} color={C.PURPLE} onChange={async v=>{ const nf={...features,[f.key]:v}; await saveFeatures(nf); }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ ARTICLES ═══ */}
        {tab==="articles"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <button className="btn btn-r" style={{marginBottom:16}} onClick={()=>setAddArtOpen(!addArtOpen)}>{addArtOpen?"✕ बंद":"+ नई खबर"}</button>
            {addArtOpen&&(
              <Card style={{marginBottom:16,border:`1px solid ${C.GOLD}44`,animation:"slideUp .25s"}}>
                <SHead icon="+" label="नई खबर" color={C.GOLD} />
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="TITLE *"/><input className="inp" value={newArt.title} onChange={e=>setNewArt({...newArt,title:e.target.value})} placeholder="खबर का शीर्षक..." /></div>
                  <div><Lbl t="CATEGORY"/><select className="inp" value={newArt.category} onChange={e=>setNewArt({...newArt,category:e.target.value})}>{["देश","विदेश","राजनीति","दिल्ली","बाजार","मनोरंजन","टेक","शिक्षा"].map(c=><option key={c}>{c}</option>)}</select></div>
                  <div><Lbl t="TAG"/><select className="inp" value={newArt.tag} onChange={e=>setNewArt({...newArt,tag:e.target.value})}>{["ब्रेकिंग","राष्ट्रीय","शहर","BJP","AAP","विशेष"].map(t=><option key={t}>{t}</option>)}</select></div>
                  <div><Lbl t="AUTHOR *"/><input className="inp" value={newArt.author} onChange={e=>setNewArt({...newArt,author:e.target.value})} placeholder="लेखक" /></div>
                  <div><Lbl t="WARD (if local)"/><select className="inp" value={newArt.ward} onChange={e=>setNewArt({...newArt,ward:e.target.value})}><option value="">-- Ward नहीं --</option>{ALL_WARDS.map(w=><option key={w}>{w}</option>)}</select></div>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="EXCERPT"/><textarea className="inp" value={newArt.excerpt} onChange={e=>setNewArt({...newArt,excerpt:e.target.value})} placeholder="सारांश..." /></div>
                  <div style={{display:"flex",gap:14,alignItems:"center",gridColumn:"1/-1",flexWrap:"wrap"}}>
                    <div style={{display:"flex",alignItems:"center",gap:8}}><Toggle val={newArt.featured} onChange={v=>setNewArt({...newArt,featured:v})} color={C.GOLD}/><span style={{fontSize:12}}>Hero Feature</span></div>
                    <div style={{display:"flex",alignItems:"center",gap:8}}><Toggle val={newArt.premium} onChange={v=>setNewArt({...newArt,premium:v})} color={C.GOLD}/><span style={{fontSize:12}}>Premium Article</span></div>
                    <div style={{display:"flex",alignItems:"center",gap:8}}><select className="inp" style={{width:160}} value={newArt.status} onChange={e=>setNewArt({...newArt,status:e.target.value})}><option value="published">✓ Published</option><option value="draft">Draft</option></select></div>
                    <div style={{display:"flex",alignItems:"center",gap:8}}><select className="inp" style={{width:160}} value={newArt.factCheck} onChange={e=>setNewArt({...newArt,factCheck:e.target.value})}><option value="pending">Fact-Check: Pending</option><option value="verified">Verified ✓</option><option value="false">False ✗</option></select></div>
                  </div>
                </div>
                <div style={{display:"flex",gap:10,marginTop:14}}>
                  <button className="btn btn-r" onClick={async()=>{ if(!newArt.title||!newArt.author){showToast("Title और Author जरूरी","error");return;} const a={...newArt,id:Date.now(),date:new Date().toISOString().slice(0,10),views:0}; const d=[a,...articles]; await saveArts(d); setNewArt({title:"",category:"दिल्ली",tag:"ब्रेकिंग",author:"",excerpt:"",status:"published",featured:false,ward:"",premium:false,factCheck:"pending"}); setAddArtOpen(false); showToast("खबर website पर live! 🎉"); if(features.telegram)showToast("Telegram पर भी भेजी गई ✈️","info"); }}>✓ Publish</button>
                  <button className="btn btn-ghost" onClick={()=>setAddArtOpen(false)}>Cancel</button>
                </div>
              </Card>
            )}
            <Card>
              {articles.map((a,i)=>(
                <div key={a.id} className="rh" style={{padding:"10px 0",borderBottom:i<articles.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:10}}>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                      <span style={{fontSize:13,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:350}}>{a.title}</span>
                      {a.premium&&<Badge text="★ PRO" color={C.GOLD} small />}
                      {a.featured&&<Badge text="Hero" color={C.PURPLE} small />}
                      {a.ward&&<Badge text={`📍${a.ward}`} color={C.TEAL} small />}
                    </div>
                    <div style={{fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginTop:2}}>{a.category} • {a.date} • {a.author}</div>
                  </div>
                  <button onClick={async()=>{ const d=articles.map(x=>x.id===a.id?{...x,status:x.status==="published"?"draft":"published"}:x); await saveArts(d); }} style={{fontSize:10,fontWeight:700,padding:"3px 9px",borderRadius:4,cursor:"pointer",border:"none",background:a.status==="published"?C.GREEN+"33":C.GOLD+"22",color:a.status==="published"?"#5EC878":C.GOLD,fontFamily:"sans-serif",whiteSpace:"nowrap"}}>
                    {a.status==="published"?"✓ Live":"Draft"}
                  </button>
                  <button onClick={async()=>{ await saveArts(articles.filter(x=>x.id!==a.id)); showToast("Deleted","error"); }} style={{background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"3px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>🗑</button>
                </div>
              ))}
            </Card>
          </div>
        )}

        {/* ═══ BREAKING ═══ */}
        {tab==="breaking"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <Card style={{marginBottom:14}}>
              <Lbl t="+ NEW BREAKING NEWS" />
              <div style={{display:"flex",gap:10}}>
                <input className="inp" value={newBreak} onChange={e=>setNewBreak(e.target.value)} onKeyDown={e=>e.key==="Enter"&&newBreak.trim()&&(async()=>{const d=[{id:Date.now(),text:newBreak.trim()},...breaking];await saveBreak(d);setNewBreak("");showToast("Breaking live! 🔴");if(features.telegram)showToast("Telegram भेजी गई ✈️","info");})()}  placeholder="Breaking news text..." />
                <button className="btn btn-r" onClick={async()=>{if(!newBreak.trim())return;const d=[{id:Date.now(),text:newBreak.trim()},...breaking];await saveBreak(d);setNewBreak("");showToast("Breaking News Live!");if(features.telegram)showToast("Telegram को भी भेजी गई ✈️","info");}}>+ Add</button>
              </div>
            </Card>
            <Card>
              {breaking.map((b,i)=>(
                <div key={b.id} className="rh" style={{padding:"11px 0",borderBottom:i<breaking.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:10}}>
                  <span style={{width:7,height:7,borderRadius:"50%",background:C.R,flexShrink:0}}></span>
                  <span style={{flex:1,fontSize:13}}>{b.text}</span>
                  <button onClick={async()=>{await saveBreak(breaking.filter(x=>x.id!==b.id));showToast("Removed","warn");}} style={{background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"3px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>🗑</button>
                </div>
              ))}
              {!breaking.length&&<div style={{padding:24,textAlign:"center",color:C.MUTED,fontSize:13}}>No breaking news</div>}
            </Card>
          </div>
        )}

        {/* ═══ WARD NEWS ═══ */}
        {tab==="ward"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="📍" label="Ward News Management" color={C.TEAL} sub="Delhi ke specific wards ke liye news add karein" />
            <Card style={{marginBottom:14}}>
              <button className="btn btn-teal" style={{marginBottom:14}} onClick={()=>setAddWardOpen(!addWardOpen)}>+ Ward News Add करें</button>
              {addWardOpen&&(
                <div style={{background:C.CARD2,borderRadius:8,padding:14,marginBottom:14,border:`1px solid ${C.TEAL}44`,animation:"slideUp .2s"}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                    <div><Lbl t="WARD CHUNIYE"/><select className="inp" value={newWardNews.ward} onChange={e=>setNewWardNews({...newWardNews,ward:e.target.value})}>
                      {Object.entries(DELHI_WARDS).map(([dist,wards])=>(
                        <optgroup key={dist} label={dist}>{wards.map(w=><option key={w} value={w}>{w}</option>)}</optgroup>
                      ))}
                    </select></div>
                    <div><Lbl t="DATE"/><input type="date" className="inp" value={newWardNews.date} onChange={e=>setNewWardNews({...newWardNews,date:e.target.value})} /></div>
                    <div style={{gridColumn:"1/-1"}}><Lbl t="NEWS TITLE *"/><input className="inp" value={newWardNews.title} onChange={e=>setNewWardNews({...newWardNews,title:e.target.value})} placeholder="Ward ki specific khabar..." /></div>
                  </div>
                  <div style={{display:"flex",gap:8,marginTop:12}}>
                    <button className="btn btn-teal" onClick={async()=>{
                      if(!newWardNews.title) return;
                      const updated={...wardNews,[newWardNews.ward]:[{id:Date.now(),title:newWardNews.title,date:newWardNews.date||new Date().toISOString().slice(0,10)},...(wardNews[newWardNews.ward]||[])]};
                      await saveWardNews(updated);
                      setNewWardNews({ward:"शाहदरा",title:"",date:""});
                      setAddWardOpen(false);
                      showToast(`${newWardNews.ward} ward ki khabar add hui!`);
                    }}>✓ Add Ward News</button>
                    <button className="btn btn-ghost" onClick={()=>setAddWardOpen(false)}>Cancel</button>
                  </div>
                </div>
              )}
            </Card>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              {Object.entries(wardNews).map(([ward,news])=>(
                <Card key={ward} style={{border:`1px solid ${C.TEAL}22`}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                    <Badge text={`📍 ${ward}`} color={C.TEAL} />
                    <span style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>{news.length} खबरें</span>
                  </div>
                  {news.slice(0,2).map((n,i)=>(
                    <div key={n.id} style={{padding:"7px 0",borderBottom:i<1?`1px solid ${C.BORDER}`:"none",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div style={{fontSize:12,color:C.W,flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:220}}>{n.title}</div>
                      <button onClick={async()=>{const upd={...wardNews,[ward]:wardNews[ward].filter(x=>x.id!==n.id)};await saveWardNews(upd);showToast("Removed","warn");}} style={{background:"transparent",border:"none",color:C.R,cursor:"pointer",fontSize:12,marginLeft:8}}>✕</button>
                    </div>
                  ))}
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* ═══ ELECTION ═══ */}
        {tab==="election"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="🗳️" label="Election Dashboard Control" color={C.GOLD} sub="Feature toggle → Feature Control | Yahan data manage karein" />
            <div style={{background:features.election?C.GREEN+"11":C.R+"11",border:`1px solid ${features.election?C.GREEN+"44":C.R+"44"}`,borderRadius:8,padding:"12px 16px",marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:C.W}}>Election Dashboard Status</div>
                <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>Website par {features.election?"visible hai":"hidden hai"}</div>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontSize:12,fontFamily:"sans-serif",color:features.election?C.GREEN:C.R,fontWeight:700}}>{features.election?"● LIVE":"○ OFF"}</span>
                <Toggle val={features.election} color={C.GOLD} onChange={async v=>{ const nf={...features,election:v}; await saveFeatures(nf); showToast(v?"Election Dashboard LIVE!":"Election Dashboard OFF"); }} />
              </div>
            </div>
            <Card style={{marginBottom:14}}>
              <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>📊 Summary Edit</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <div><Lbl t="ELECTION NAME"/><input className="inp" value={election.name} onChange={e=>setElection({...election,name:e.target.value})} /></div>
                <div><Lbl t="DATE"/><input className="inp" value={election.date} onChange={e=>setElection({...election,date:e.target.value})} /></div>
                <div><Lbl t="STATUS"/><select className="inp" value={election.status} onChange={e=>setElection({...election,status:e.target.value})}><option value="completed">Completed</option><option value="ongoing">Ongoing</option><option value="upcoming">Upcoming</option></select></div>
                <div><Lbl t="AAP SEATS"/><input type="number" className="inp" value={election.summary.AAP} onChange={e=>setElection({...election,summary:{...election.summary,AAP:Number(e.target.value)}})} /></div>
                <div><Lbl t="BJP SEATS"/><input type="number" className="inp" value={election.summary.BJP} onChange={e=>setElection({...election,summary:{...election.summary,BJP:Number(e.target.value)}})} /></div>
                <div><Lbl t="CONGRESS SEATS"/><input type="number" className="inp" value={election.summary.Congress} onChange={e=>setElection({...election,summary:{...election.summary,Congress:Number(e.target.value)}})} /></div>
              </div>
              <button className="btn btn-gold" style={{marginTop:14}} onClick={async()=>{await saveElection(election);showToast("Election data save! Website par live.");}}>💾 Save Election Data</button>
            </Card>
          </div>
        )}

        {/* ═══ FACT-CHECK ═══ */}
        {tab==="factcheck"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <SHead icon="✅" label="Fact-Check Manager" color={C.GREEN} />
              <button className="btn btn-g" onClick={()=>setAddFCOpen(!addFCOpen)}>+ Add Fact-Check</button>
            </div>
            {addFCOpen&&(
              <Card style={{marginBottom:14,border:`1px solid ${C.GREEN}44`,animation:"slideUp .2s"}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="CLAIM (जो claim verify करनी है)"/><textarea className="inp" value={newFC.claim} onChange={e=>setNewFC({...newFC,claim:e.target.value})} placeholder="वायरल claim लिखें..." rows={2} /></div>
                  <div><Lbl t="VERDICT"/><select className="inp" value={newFC.verdict} onChange={e=>setNewFC({...newFC,verdict:e.target.value})}><option>सच</option><option>झूठ</option><option>भ्रामक</option><option>अधूरा सच</option></select></div>
                  <div><Lbl t="SOURCE"/><input className="inp" value={newFC.source} onChange={e=>setNewFC({...newFC,source:e.target.value})} placeholder="Verified source..." /></div>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="EXPLANATION"/><textarea className="inp" value={newFC.explanation} onChange={e=>setNewFC({...newFC,explanation:e.target.value})} placeholder="Sach kya hai, kaise verify kiya..." rows={3} /></div>
                </div>
                <div style={{display:"flex",gap:8,marginTop:12}}>
                  <button className="btn btn-g" onClick={async()=>{ if(!newFC.claim||!newFC.explanation) return; const d=[{...newFC,id:Date.now(),date:new Date().toISOString().slice(0,10),...newFC},...factChecks]; await saveFC(d); setNewFC({claim:"",verdict:"झूठ",explanation:"",source:"",category:"सामान्य"}); setAddFCOpen(false); showToast("Fact-Check published!"); }}>✓ Publish</button>
                  <button className="btn btn-ghost" onClick={()=>setAddFCOpen(false)}>Cancel</button>
                </div>
              </Card>
            )}
            {factChecks.map((fc,i)=>(
              <Card key={fc.id} style={{marginBottom:10,border:`1px solid ${fc.verdict==="सच"?C.GREEN:fc.verdict==="झूठ"?C.R:C.ORANGE}33`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                  <div style={{flex:1,marginRight:12}}>
                    <div style={{fontSize:13,fontWeight:700,color:C.W,lineHeight:1.5}}>{fc.claim}</div>
                    <div style={{fontSize:11,color:C.MUTED,marginTop:5,fontFamily:"sans-serif"}}>Source: {fc.source} • {fc.date}</div>
                  </div>
                  <div style={{display:"flex",gap:8,alignItems:"center",flexShrink:0}}>
                    <Badge text={fc.verdict} color={fc.verdict==="सच"?C.GREEN:fc.verdict==="झूठ"?C.R:C.ORANGE} />
                    <button onClick={async()=>{await saveFC(factChecks.filter(x=>x.id!==fc.id));showToast("Removed","warn");}} style={{background:"transparent",border:"none",color:C.R,cursor:"pointer",fontSize:13}}>🗑</button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* ═══ EVENTS ═══ */}
        {tab==="events"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <SHead icon="📅" label="Events Manager" color={C.PURPLE} />
              <button className="btn btn-p" onClick={()=>setAddEventOpen(!addEventOpen)}>+ New Event</button>
            </div>
            {addEventOpen&&(
              <Card style={{marginBottom:14,border:`1px solid ${C.PURPLE}44`,animation:"slideUp .2s"}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="EVENT TITLE *"/><input className="inp" value={newEvent.title} onChange={e=>setNewEvent({...newEvent,title:e.target.value})} placeholder="Event ka naam..." /></div>
                  <div><Lbl t="DATE"/><input type="date" className="inp" value={newEvent.date} onChange={e=>setNewEvent({...newEvent,date:e.target.value})} /></div>
                  <div><Lbl t="TIME"/><input className="inp" value={newEvent.time} onChange={e=>setNewEvent({...newEvent,time:e.target.value})} placeholder="7:00 PM" /></div>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="VENUE"/><input className="inp" value={newEvent.venue} onChange={e=>setNewEvent({...newEvent,venue:e.target.value})} placeholder="Venue, Location, Delhi" /></div>
                  <div><Lbl t="CATEGORY"/><select className="inp" value={newEvent.category} onChange={e=>setNewEvent({...newEvent,category:e.target.value})}><option>कॉन्फ्रेंस</option><option>संगीत</option><option>खाना</option><option>खेल</option><option>सांस्कृतिक</option><option>शिक्षा</option></select></div>
                  <div><Lbl t="PRICE (₹, 0=Free)"/><input type="number" className="inp" value={newEvent.price} onChange={e=>setNewEvent({...newEvent,price:Number(e.target.value)})} /></div>
                  <div><Lbl t="TOTAL TICKETS"/><input type="number" className="inp" value={newEvent.tickets} onChange={e=>setNewEvent({...newEvent,tickets:Number(e.target.value)})} /></div>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="DESCRIPTION"/><textarea className="inp" value={newEvent.description} onChange={e=>setNewEvent({...newEvent,description:e.target.value})} placeholder="Event ki details..." /></div>
                </div>
                <div style={{display:"flex",gap:8,marginTop:12}}>
                  <button className="btn btn-p" onClick={async()=>{ if(!newEvent.title) return; const d=[...events,{...newEvent,id:Date.now(),sold:0,status:"active"}]; await saveEvents(d); setNewEvent({title:"",date:"",time:"",venue:"",category:"कॉन्फ्रेंस",price:0,tickets:100,description:""}); setAddEventOpen(false); showToast("Event published!"); }}>✓ Publish Event</button>
                  <button className="btn btn-ghost" onClick={()=>setAddEventOpen(false)}>Cancel</button>
                </div>
              </Card>
            )}
            {events.map((ev,i)=>(
              <Card key={ev.id} style={{marginBottom:10,display:"flex",gap:14,alignItems:"center"}}>
                <div style={{fontSize:28}}>{{"कॉन्फ्रेंस":"🎤","संगीत":"🎵","खाना":"🍜"}[ev.category]||"📅"}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:13,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ev.title}</div>
                  <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginTop:2}}>{ev.date} • {ev.venue} • {ev.price===0?"FREE":`₹${ev.price}`}</div>
                  <div style={{fontSize:11,color:C.TEAL,fontFamily:"sans-serif",marginTop:2}}>{ev.sold}/{ev.tickets} tickets sold</div>
                </div>
                <button onClick={async()=>{ const d=events.map(x=>x.id===ev.id?{...x,status:x.status==="active"?"inactive":"active"}:x); await saveEvents(d); }} style={{fontSize:10,fontWeight:700,padding:"4px 10px",borderRadius:5,cursor:"pointer",border:"none",background:ev.status==="active"?C.GREEN+"33":C.R+"22",color:ev.status==="active"?"#5EC878":C.R,fontFamily:"sans-serif",whiteSpace:"nowrap"}}>
                  {ev.status==="active"?"● Active":"○ Off"}
                </button>
                <button onClick={async()=>{await saveEvents(events.filter(x=>x.id!==ev.id));showToast("Removed","warn");}} style={{background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>🗑</button>
              </Card>
            ))}
          </div>
        )}

        {/* ═══ SPONSORED ═══ */}
        {tab==="sponsored"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <SHead icon="💼" label="Sponsored Content Studio" color={C.GOLD} sub="Brand content manage karein — website par 'Sponsored' badge ke saath" />
              <button className="btn btn-gold" onClick={()=>setAddSponOpen(!addSponOpen)}>+ New Sponsored</button>
            </div>
            {addSponOpen&&(
              <Card style={{marginBottom:14,border:`1px solid ${C.GOLD}44`,animation:"slideUp .2s"}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  <div><Lbl t="BRAND NAME *"/><input className="inp" value={newSponsored.brand} onChange={e=>setNewSponsored({...newSponsored,brand:e.target.value})} placeholder="Company/Brand naam" /></div>
                  <div><Lbl t="CATEGORY"/><select className="inp" value={newSponsored.category} onChange={e=>setNewSponsored({...newSponsored,category:e.target.value})}><option>Finance</option><option>Real Estate</option><option>Health</option><option>Technology</option><option>Education</option><option>FMCG</option></select></div>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="HEADLINE *"/><input className="inp" value={newSponsored.title} onChange={e=>setNewSponsored({...newSponsored,title:e.target.value})} placeholder="Sponsored content ka headline..." /></div>
                  <div style={{gridColumn:"1/-1"}}><Lbl t="CONTENT"/><textarea className="inp" value={newSponsored.content} onChange={e=>setNewSponsored({...newSponsored,content:e.target.value})} placeholder="Brand ka promotional content..." /></div>
                </div>
                <div style={{display:"flex",gap:8,marginTop:12}}>
                  <button className="btn btn-gold" onClick={async()=>{ if(!newSponsored.brand||!newSponsored.title) return; const d=[...sponsored,{...newSponsored,id:Date.now(),status:"active",badge:"Sponsored"}]; await saveSponsored(d); setNewSponsored({brand:"",title:"",content:"",category:"General"}); setAddSponOpen(false); showToast("Sponsored content live!"); }}>✓ Publish</button>
                  <button className="btn btn-ghost" onClick={()=>setAddSponOpen(false)}>Cancel</button>
                </div>
              </Card>
            )}
            {sponsored.map((sp,i)=>(
              <Card key={sp.id} style={{marginBottom:10,border:`1px solid ${C.GOLD}22`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                  <div style={{flex:1,marginRight:12}}>
                    <div style={{display:"flex",gap:8,marginBottom:6}}><Badge text="Sponsored" color={C.GOLD} /><Badge text={sp.brand} color={C.MUTED} /></div>
                    <div style={{fontSize:13,fontWeight:700,color:C.W}}>{sp.title}</div>
                    <div style={{fontSize:11,color:C.MUTED,marginTop:4,lineHeight:1.5}}>{sp.content}</div>
                  </div>
                  <div style={{display:"flex",gap:8,alignItems:"center",flexShrink:0}}>
                    <button onClick={async()=>{const d=sponsored.map(x=>x.id===sp.id?{...x,status:x.status==="active"?"paused":"active"}:x);await saveSponsored(d);}} style={{fontSize:10,fontWeight:700,padding:"4px 10px",borderRadius:5,cursor:"pointer",border:"none",background:sp.status==="active"?C.GREEN+"33":C.GOLD+"22",color:sp.status==="active"?"#5EC878":C.GOLD,fontFamily:"sans-serif",whiteSpace:"nowrap"}}>
                      {sp.status==="active"?"● Active":"○ Paused"}
                    </button>
                    <button onClick={async()=>{await saveSponsored(sponsored.filter(x=>x.id!==sp.id));showToast("Removed","warn");}} style={{background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>🗑</button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* ═══ AWARDS ═══ */}
        {tab==="awards"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="🏆" label="Citizen Journalism Awards" color={C.GOLD} sub="Monthly award manage karein" />
            {awards.map((a,i)=>(
              <Card key={a.id} style={{marginBottom:12,border:`1px solid ${C.GOLD}44`,background:`linear-gradient(135deg,${C.GOLD}0d,${C.CARD})`}}>
                <div style={{display:"flex",gap:12,alignItems:"center"}}>
                  <span style={{fontSize:36}}>🏆</span>
                  <div style={{flex:1}}>
                    <Badge text={a.month} color={C.GOLD} />
                    <div style={{fontSize:15,fontWeight:700,color:C.W,marginTop:5}}>{a.winner} — {a.area}</div>
                    <div style={{fontSize:12,color:C.MUTED,marginTop:4,fontStyle:"italic"}}>"{a.post}"</div>
                    <div style={{fontSize:11,color:C.GOLD,marginTop:5,fontFamily:"sans-serif"}}>👍 {a.votes.toLocaleString()} votes • {a.status}</div>
                  </div>
                  <button onClick={async()=>{setAwards(aw=>aw.filter(x=>x.id!==a.id));await dbSet(SK.awards,awards.filter(x=>x.id!==a.id));showToast("Removed","warn");}} style={{background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif"}}>🗑</button>
                </div>
              </Card>
            ))}
            <Card>
              <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>+ New Award Announce</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12}}>
                {[{k:"month",p:"Mahina e.g. June 2025"},{k:"winner",p:"Winner naam"},{k:"area",p:"Ward/Area"},{k:"post",p:"Winning post summary"}].map(f=>(
                  <div key={f.k} style={{gridColumn:f.k==="post"?"1/-1":"auto"}}><Lbl t={f.k.toUpperCase()}/><input className="inp" placeholder={f.p} onChange={e=>{}} /></div>
                ))}
              </div>
              <button className="btn btn-gold" onClick={()=>showToast("Award announce functionality — coming soon!","info")}>🏆 Announce Award</button>
            </Card>
          </div>
        )}

        {/* ═══ NEWSLETTER ═══ */}
        {tab==="newsletter"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="📧" label="Newsletter Manager" color={C.R} sub={`${newsletter.length} subscribers`} />
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:20}}>
              {[
                {icon:"👥",label:"Total Subscribers",value:newsletter.length,color:C.W},
                {icon:"📧",label:"Last Digest",value:"27 May",color:C.GOLD},
                {icon:"📊",label:"Open Rate",value:"31%",color:C.GREEN},
              ].map(s=><StatBox key={s.label} {...s} />)}
            </div>
            <Card style={{marginBottom:14}}>
              <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>📤 Digest भेजें</div>
              <div style={{marginBottom:12}}><Lbl t="SUBJECT"/><input className="inp" placeholder="आज की Top 5 खबरें — दिल्लीनामा" /></div>
              <div style={{marginBottom:14}}><Lbl t="PREVIEW TEXT"/><input className="inp" placeholder="AQI 412, चुनाव परिणाम, और बहुत कुछ..." /></div>
              <div style={{background:C.CARD2,borderRadius:8,padding:14,marginBottom:14,border:`1px solid ${C.BORDER2}`}}>
                <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginBottom:8}}>Email Preview</div>
                <div style={{fontSize:14,fontWeight:700,color:C.R,fontFamily:"serif"}}>दिल्लीनामा Daily Digest</div>
                <div style={{fontSize:12,color:C.MUTED,marginTop:4,fontFamily:"sans-serif"}}>नमस्ते,<br/>आज की दिल्ली की 5 बड़ी खबरें...</div>
                {articles.filter(a=>a.status==="published").slice(0,3).map(a=>(
                  <div key={a.id} style={{padding:"6px 0",borderBottom:`1px solid ${C.BORDER}`,fontSize:12,color:C.W}}>• {a.title}</div>
                ))}
              </div>
              <button className="btn btn-r" onClick={()=>showToast(`${newsletter.length} subscribers को digest भेजी जाएगी! (Demo)`)}>📧 {newsletter.length} Subscribers को Send करें</button>
            </Card>
            <Card>
              <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>👥 Subscriber List</div>
              {newsletter.length===0 ? (
                <div style={{padding:20,textAlign:"center",color:C.MUTED,fontSize:13}}>अभी कोई subscriber नहीं — website par subscribe section active karein</div>
              ) : (
                newsletter.map((s,i)=>(
                  <div key={i} className="rh" style={{padding:"8px 0",borderBottom:i<newsletter.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",justifyContent:"space-between",fontSize:12}}>
                    <span style={{fontFamily:"monospace",color:C.W}}>{s.email}</span>
                    <span style={{color:C.MUTED,fontFamily:"sans-serif"}}>{s.date}</span>
                  </div>
                ))
              )}
            </Card>
          </div>
        )}

        {/* ═══ TELEGRAM ═══ */}
        {tab==="telegram"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="✈️" label="Telegram Integration" color={C.BLUE} sub="Har khabar, breaking news aur digest Telegram par auto-bhejein" />
            <div style={{background:features.telegram?C.GREEN+"11":C.CARD,border:`1px solid ${features.telegram?C.GREEN+"44":C.BORDER}`,borderRadius:10,padding:"14px 18px",marginBottom:18,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:14,fontWeight:700,color:C.W}}>Telegram Notifications {features.telegram?"🟢 Active":"⭕ Inactive"}</div>
                <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginTop:2}}>Toggle ON करने पर har nai khabar aur breaking news Telegram channel par jayegi</div>
              </div>
              <Toggle val={features.telegram} color={C.BLUE} onChange={async v=>{ const nf={...features,telegram:v}; await saveFeatures(nf); showToast(v?"Telegram Notifications ON! ✈️":"Telegram OFF"); }} />
            </div>
            <Card style={{marginBottom:14}}>
              <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>⚙️ Bot Configuration</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <div>
                  <Lbl t="BOT TOKEN (BotFather se milta hai)" />
                  <input className="inp" value={telegramBot.token} onChange={e=>setTelegramBot({...telegramBot,token:e.target.value})} placeholder="1234567890:ABCdef..." type="password" />
                </div>
                <div>
                  <Lbl t="CHANNEL/GROUP CHAT ID" />
                  <input className="inp" value={telegramBot.chatId} onChange={e=>setTelegramBot({...telegramBot,chatId:e.target.value})} placeholder="-1001234567890 ya @channel_name" />
                </div>
              </div>
              <div style={{display:"flex",gap:10,marginTop:14}}>
                <button className="btn btn-b" onClick={async()=>{ await dbSet(SK.telegram,telegramBot); showToast("Bot config saved!"); }}>💾 Save Config</button>
                <button className="btn btn-ghost" style={{display:"flex",alignItems:"center",gap:6}} onClick={sendTelegramTest} disabled={telegramTest}>
                  {telegramTest?<><Spin/>Testing...</>:"🧪 Test Message भेजें"}
                </button>
              </div>
            </Card>
            <Card>
              <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>📋 Telegram Triggers</div>
              {[
                {label:"New Article Publish",desc:"Jab koi nai khabar publish ho",key:"trig_article"},
                {label:"Breaking News Add",desc:"Jab breaking news ticker mein add ho",key:"trig_breaking"},
                {label:"Daily Digest (8 AM)",desc:"Roz subah 5 khabron ka digest",key:"trig_digest"},
                {label:"Bole Free — New Post",desc:"Jab nayi public complaint aa jaye",key:"trig_bole"},
                {label:"Events",desc:"Naya event add hone par",key:"trig_events"},
              ].map(t=>(
                <div key={t.key} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderBottom:`1px solid ${C.BORDER}`}}>
                  <span style={{fontSize:20}}>✈️</span>
                  <div style={{flex:1}}>
                    <div style={{fontSize:12,fontWeight:600,color:C.W}}>{t.label}</div>
                    <div style={{fontSize:11,color:C.MUTED,fontFamily:"sans-serif"}}>{t.desc}</div>
                  </div>
                  <Toggle val={features.telegram} color={C.BLUE} onChange={async v=>{ const nf={...features,telegram:v}; await saveFeatures(nf); }} />
                </div>
              ))}
            </Card>
            <div style={{background:C.BLUE+"11",border:`1px solid ${C.BLUE}33`,borderRadius:8,padding:14,marginTop:14,fontSize:12,color:C.MUTED,fontFamily:"sans-serif",lineHeight:1.8}}>
              <b style={{color:C.W}}>Setup Guide:</b><br/>
              1. Telegram mein @BotFather ko message karein<br/>
              2. /newbot command se bot banayein<br/>
              3. Bot Token copy karein aur yahan paste karein<br/>
              4. Bot ko apne channel mein Admin banayein<br/>
              5. Channel ka Chat ID yahan enter karein<br/>
              6. Test karein — ho gaya! 🎉
            </div>
          </div>
        )}

        {/* ═══ USERS ═══ */}
        {tab==="users"&&user?.role==="admin"&&(
          <div style={{animation:"fadeIn .3s"}}>
            <SHead icon="👥" label="User Management" color={C.PURPLE} />
            <Card>
              {users.map((u,i)=>(
                <div key={u.id} className="rh" style={{padding:"11px 0",borderBottom:i<users.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:12}}>
                  <div style={{width:30,height:30,borderRadius:"50%",background:ROLES[u.role]?.color+"25",border:`1.5px solid ${ROLES[u.role]?.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{ROLES[u.role]?.icon}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:600,color:C.W}}>{u.name}{u.id===user.id&&<span style={{fontSize:10,color:C.GOLD,marginLeft:8,fontFamily:"sans-serif"}}>(आप)</span>}</div>
                    <div style={{fontSize:11,color:C.MUTED,fontFamily:"monospace",marginTop:1}}>@{u.username}</div>
                  </div>
                  <Badge text={ROLES[u.role]?.label} color={ROLES[u.role]?.color} />
                  <Badge text={u.active?"Active":"Inactive"} color={u.active?C.GREEN:C.R} />
                </div>
              ))}
            </Card>
          </div>
        )}

        </div>
      </div>
      <Toast msg={toast.msg} type={toast.type} />
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   ROOT APP — Hash URL Routing
═══════════════════════════════════════════════════ */
export default function App() {
  const [route,setRoute] = useState("website");
  const [url,setUrl] = useState("delhinama.com");
  const goAdmin = () => { setRoute("admin"); setUrl("admin.delhinama.com"); };
  const goSite = () => { setRoute("website"); setUrl("delhinama.com"); };
  return (
    <div>
      <style>{G_CSS}</style>
      {/* Fake Browser Bar */}
      <div style={{background:"#0a0a0a",borderBottom:"1px solid #1a1a1a",padding:"5px 12px",display:"flex",alignItems:"center",gap:10,fontFamily:"sans-serif",position:"sticky",top:0,zIndex:200}}>
        <div style={{display:"flex",gap:5}}>
          {["#FF5F57","#FEBC2E","#28C840"].map(c=><div key={c} style={{width:10,height:10,borderRadius:"50%",background:c}}></div>)}
        </div>
        <div style={{flex:1,background:"#1a1a1a",border:"1px solid #2a2a2a",borderRadius:6,padding:"4px 12px",fontSize:11,color:route==="admin"?"#C8962E":"#aaa",display:"flex",alignItems:"center",gap:7,maxWidth:480,margin:"0 auto"}}>
          <span style={{color:"#4CAF50",fontSize:10}}>🔒</span>
          <span>https://{url}</span>
        </div>
        <div style={{display:"flex",gap:6}}>
          <button onClick={goSite} style={{background:route==="website"?"#C41E2822":"transparent",border:`1px solid ${route==="website"?"#C41E28":"#2a2a2a"}`,borderRadius:5,padding:"3px 10px",color:route==="website"?"#C41E28":"#555",fontSize:11,cursor:"pointer"}}>🌐 delhinama.com</button>
          <button onClick={goAdmin} style={{background:route==="admin"?"#C8962E22":"transparent",border:`1px solid ${route==="admin"?"#C8962E":"#2a2a2a"}`,borderRadius:5,padding:"3px 10px",color:route==="admin"?"#C8962E":"#555",fontSize:11,cursor:"pointer"}}>🔐 admin.delhinama.com</button>
        </div>
      </div>
      {route==="website"&&<Website onGoAdmin={goAdmin} />}
      {route==="admin"&&<AdminPanel onGoWebsite={goSite} />}
    </div>
  );
}
