import { useState, useEffect, useCallback } from "react";

/* ── PALETTE ── */
const R="#C41E28",GOLD="#C8962E",BG="#07070A",CARD="#0F0F13",CARD2="#161619",
  WHITE="#EDE9E4",MUTED="#65635F",BORDER="#1D1D21",BORDER2="#252529",
  GREEN="#1B7A3A",BLUE="#1456A8";

/* ── STORAGE HELPERS ── */
const KEYS = { articles:"dnh:articles", breaking:"dnh:breaking", bole:"dnh:bole", stats:"dnh:stats" };

async function dbGet(key, fallback=[]) {
  try { const r = await window.storage.get(key); return r ? JSON.parse(r.value) : fallback; }
  catch { return fallback; }
}
async function dbSet(key, val) {
  try { await window.storage.set(key, JSON.stringify(val)); return true; }
  catch { return false; }
}

/* ── SEED DATA ── */
const SEED_ARTICLES = [
  { id:1, title:"दिल्ली का AQI 412 पार — NGT का आदेश: कल से सम-विषम लागू", category:"दिल्ली", tag:"ब्रेकिंग", author:"विशेष संवाददाता", excerpt:"प्रदूषण की आपातकालीन स्थिति में NGT ने दिल्ली सरकार को सम-विषम योजना लागू करने के आदेश दिए।", date:"2025-05-27", status:"published", views:12400 },
  { id:2, title:"PM मोदी का विपक्ष पर तीखा हमला: 'देश को गुमराह करना बंद करो'", category:"राजनीति", tag:"BJP", author:"राजनीतिक संवाददाता", excerpt:"प्रधानमंत्री ने लोकसभा में विपक्ष को कड़ा जवाब दिया।", date:"2025-05-27", status:"published", views:8900 },
  { id:3, title:"Nifty 23,450 के पार — IT और ऑटो सेक्टर में 3% की छलांग", category:"बाजार", tag:"मार्केट", author:"बिजनेस डेस्क", excerpt:"शेयर बाजार में तेजी, IT और फार्मा में जोरदार उछाल।", date:"2025-05-26", status:"published", views:5600 },
  { id:4, title:"मणिपुर में फिर हिंसा — सेना ने संभाला मोर्चा, इंटरनेट बंद", category:"देश", tag:"राष्ट्रीय", author:"पूर्वोत्तर संवाददाता", excerpt:"मणिपुर में हिंसा की नई घटनाओं के बाद सेना की गश्त बढ़ी।", date:"2025-05-26", status:"published", views:9200 },
  { id:5, title:"दिल्ली मेट्रो फेज-4: तीन स्टेशनों पर काम अटका, यात्री परेशान", category:"दिल्ली", tag:"शहर", author:"शहरी डेस्क", excerpt:"DMRC के फेज-4 प्रोजेक्ट में नई अड़चन — भूमि अधिग्रहण विवाद।", date:"2025-05-25", status:"draft", views:0 },
];
const SEED_BREAKING = [
  { id:1, text:"संसद सत्र में विपक्ष का हंगामा, कार्यवाही स्थगित" },
  { id:2, text:"दिल्ली में बारिश के बाद ITO, मिंटो ब्रिज पर जलभराव" },
  { id:3, text:"सेंसेक्स 400 अंक ऊपर, IT और फार्मा सेक्टर में तेजी" },
];
const SEED_BOLE = [
  { id:1, name:"रमेश शर्मा", area:"पटपड़गंज", issue:"टूटी सड़क", text:"6 महीने से गली में सड़क टूटी है, नगर पालिका नहीं सुन रही।", status:"pending", date:"2025-05-27", votes:312 },
  { id:2, name:"सुनीता देवी", area:"शाहदरा", issue:"बिजली कटौती", text:"रोज 8-10 घंटे बिजली नहीं। बच्चे बीमार पड़ रहे हैं।", status:"pending", date:"2025-05-27", votes:245 },
  { id:3, name:"मोहम्मद अली", area:"जामिया नगर", issue:"सरकारी स्कूल", text:"80 बच्चों के लिए सिर्फ 2 टीचर। बच्चों का भविष्य खतरे में।", status:"approved", date:"2025-05-26", votes:489 },
];

const CATS = ["देश","विदेश","राज्य","राजनीति","बाजार","मनोरंजन","दिल्ली","टेक","शिक्षा","कैरियर","ऑटो","यात्रा","लाइफ","अध्यात्म","फोटो","वीडियो"];
const TAGS = ["ब्रेकिंग","राष्ट्रीय","मार्केट","शहर","BJP","कांग्रेस","AAP","चुनाव","विशेष","ट्रेंडिंग"];

/* ── TOAST ── */
function Toast({ msg, type }) {
  return msg ? (
    <div style={{ position:"fixed", bottom:24, right:24, background: type==="success"?GREEN:type==="error"?R:GOLD, color:WHITE, padding:"10px 20px", borderRadius:8, fontSize:13, fontFamily:"sans-serif", fontWeight:600, zIndex:9999, boxShadow:"0 4px 20px #0008", animation:"slideUp .3s ease" }}>
      {type==="success"?"✓ ":type==="error"?"✗ ":"ℹ "}{msg}
    </div>
  ) : null;
}

/* ── CONFIRM MODAL ── */
function Confirm({ msg, onYes, onNo }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"#000a", display:"flex", alignItems:"center", justifyContent:"center", zIndex:999 }}>
      <div style={{ background:CARD, border:`1px solid ${BORDER2}`, borderRadius:12, padding:28, maxWidth:340, width:"90%" }}>
        <div style={{ fontSize:15, fontWeight:600, color:WHITE, marginBottom:8 }}>क्या आप sure हैं?</div>
        <div style={{ fontSize:13, color:MUTED, marginBottom:20, fontFamily:"sans-serif" }}>{msg}</div>
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onNo} style={{ flex:1, padding:"9px", borderRadius:7, border:`1px solid ${BORDER2}`, background:"transparent", color:MUTED, cursor:"pointer", fontSize:13, fontFamily:"sans-serif" }}>रद्द करें</button>
          <button onClick={onYes} style={{ flex:1, padding:"9px", borderRadius:7, border:"none", background:R, color:WHITE, cursor:"pointer", fontSize:13, fontFamily:"sans-serif", fontWeight:700 }}>हाँ, हटाएं</button>
        </div>
      </div>
    </div>
  );
}

/* ── STAT CARD ── */
function Stat({ icon, label, value, sub, color=WHITE }) {
  return (
    <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, padding:"16px 18px" }}>
      <div style={{ fontSize:22, marginBottom:6 }}>{icon}</div>
      <div style={{ fontSize:26, fontWeight:700, color, fontFamily:"sans-serif", marginBottom:2 }}>{value}</div>
      <div style={{ fontSize:13, fontWeight:600, color:WHITE, marginBottom:3 }}>{label}</div>
      {sub && <div style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>{sub}</div>}
    </div>
  );
}

/* ────────────────────────────────── MAIN APP ──────────────────────────────── */
export default function AdminPanel() {
  const [page, setPage] = useState("login");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [articles, setArticles] = useState([]);
  const [breaking, setBreaking] = useState([]);
  const [bole, setBole] = useState([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ msg:"", type:"success" });
  const [confirm, setConfirm] = useState(null);
  const [loginErr, setLoginErr] = useState("");
  const [loginForm, setLoginForm] = useState({ user:"", pass:"" });
  const [addOpen, setAddOpen] = useState(false);
  const [newArticle, setNewArticle] = useState({ title:"", category:"दिल्ली", tag:"ब्रेकिंग", author:"", excerpt:"", status:"published" });
  const [newBreaking, setNewBreaking] = useState("");
  const [artFilter, setArtFilter] = useState("all");
  const [searchQ, setSearchQ] = useState("");

  const showToast = (msg, type="success") => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg:"", type:"success" }), 3000);
  };

  /* Load from storage */
  const loadData = useCallback(async () => {
    setLoading(true);
    const [arts, brk, bol] = await Promise.all([
      dbGet(KEYS.articles, SEED_ARTICLES),
      dbGet(KEYS.breaking, SEED_BREAKING),
      dbGet(KEYS.bole, SEED_BOLE),
    ]);
    // Seed if empty
    if (!arts.length) { await dbSet(KEYS.articles, SEED_ARTICLES); setArticles(SEED_ARTICLES); }
    else setArticles(arts);
    if (!brk.length) { await dbSet(KEYS.breaking, SEED_BREAKING); setBreaking(SEED_BREAKING); }
    else setBreaking(brk);
    if (!bol.length) { await dbSet(KEYS.bole, SEED_BOLE); setBole(SEED_BOLE); }
    else setBole(bol);
    setLoading(false);
  }, []);

  useEffect(() => { if (page === "admin") loadData(); }, [page, loadData]);

  /* ── LOGIN ── */
  const doLogin = () => {
    if (loginForm.user === "admin" && loginForm.pass === "delhinama123") {
      setPage("admin"); setLoginErr("");
    } else { setLoginErr("गलत Username या Password"); }
  };

  /* ── ARTICLE CRUD ── */
  const addArticle = async () => {
    if (!newArticle.title.trim() || !newArticle.author.trim()) { showToast("Title और Author जरूरी है", "error"); return; }
    const art = { ...newArticle, id: Date.now(), date: new Date().toISOString().slice(0,10), views: 0 };
    const updated = [art, ...articles];
    await dbSet(KEYS.articles, updated);
    setArticles(updated);
    setNewArticle({ title:"", category:"दिल्ली", tag:"ब्रेकिंग", author:"", excerpt:"", status:"published" });
    setAddOpen(false);
    showToast("खबर सफलतापूर्वक जोड़ी गई!");
  };

  const deleteArticle = (id) => {
    setConfirm({ msg:"यह खबर हमेशा के लिए हट जाएगी।", onYes: async () => {
      const updated = articles.filter(a => a.id !== id);
      await dbSet(KEYS.articles, updated);
      setArticles(updated);
      setConfirm(null);
      showToast("खबर हटा दी गई", "error");
    }, onNo: () => setConfirm(null) });
  };

  const toggleStatus = async (id) => {
    const updated = articles.map(a => a.id===id ? { ...a, status: a.status==="published"?"draft":"published" } : a);
    await dbSet(KEYS.articles, updated);
    setArticles(updated);
    showToast("Status बदल दिया गया");
  };

  /* ── BREAKING CRUD ── */
  const addBreaking = async () => {
    if (!newBreaking.trim()) return;
    const item = { id: Date.now(), text: newBreaking.trim() };
    const updated = [item, ...breaking];
    await dbSet(KEYS.breaking, updated);
    setBreaking(updated);
    setNewBreaking("");
    showToast("ब्रेकिंग न्यूज़ जोड़ी गई!");
  };

  const deleteBreaking = async (id) => {
    const updated = breaking.filter(b => b.id !== id);
    await dbSet(KEYS.breaking, updated);
    setBreaking(updated);
    showToast("ब्रेकिंग हटाई गई", "error");
  };

  /* ── BOLE FREE MODERATION ── */
  const updateBole = async (id, status) => {
    const updated = bole.map(b => b.id===id ? { ...b, status } : b);
    await dbSet(KEYS.bole, updated);
    setBole(updated);
    showToast(status==="approved" ? "पोस्ट Approve हुई ✓" : "पोस्ट Reject हुई");
  };

  const deleteBole = async (id) => {
    setConfirm({ msg:"यह पोस्ट हटा दी जाएगी।", onYes: async () => {
      const updated = bole.filter(b => b.id !== id);
      await dbSet(KEYS.bole, updated);
      setBole(updated);
      setConfirm(null);
      showToast("पोस्ट हटाई गई", "error");
    }, onNo: () => setConfirm(null) });
  };

  /* filtered articles */
  const filteredArts = articles.filter(a => {
    const matchCat = artFilter==="all" || a.status===artFilter || a.category===artFilter;
    const matchQ = !searchQ || a.title.toLowerCase().includes(searchQ.toLowerCase()) || a.category.includes(searchQ);
    return matchCat && matchQ;
  });

  /* ════════════════ RENDER ════════════════ */

  /* ── LOGIN PAGE ── */
  if (page === "login") return (
    <div style={{ background:BG, minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Noto Sans Devanagari', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&family=Noto+Serif+Devanagari:wght@700;900&display=swap');*{box-sizing:border-box;margin:0;padding:0}@keyframes slideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}`}</style>
      <div style={{ background:CARD, border:`1px solid ${BORDER2}`, borderRadius:14, padding:"40px 36px", width:380, animation:"slideUp .4s ease" }}>
        <div style={{ textAlign:"center", marginBottom:28 }}>
          <div style={{ fontSize:26, fontWeight:900, color:R, fontFamily:"'Noto Serif Devanagari', serif" }}>दिल्लीनामा</div>
          <div style={{ fontSize:9, color:GOLD, letterSpacing:4, fontFamily:"sans-serif", marginTop:4 }}>DELHINAMA</div>
          <div style={{ marginTop:14, fontSize:14, color:MUTED, fontFamily:"sans-serif" }}>Admin Control Panel</div>
        </div>
        <div style={{ marginBottom:14 }}>
          <label style={{ fontSize:12, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>USERNAME</label>
          <input value={loginForm.user} onChange={e=>setLoginForm({...loginForm,user:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="admin" style={{ width:"100%", background:CARD2, border:`1px solid ${BORDER2}`, borderRadius:8, padding:"10px 14px", color:WHITE, fontSize:14, outline:"none", fontFamily:"sans-serif" }} />
        </div>
        <div style={{ marginBottom:20 }}>
          <label style={{ fontSize:12, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>PASSWORD</label>
          <input type="password" value={loginForm.pass} onChange={e=>setLoginForm({...loginForm,pass:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="••••••••••••" style={{ width:"100%", background:CARD2, border:`1px solid ${BORDER2}`, borderRadius:8, padding:"10px 14px", color:WHITE, fontSize:14, outline:"none", fontFamily:"sans-serif" }} />
        </div>
        {loginErr && <div style={{ fontSize:12, color:R, marginBottom:14, fontFamily:"sans-serif", textAlign:"center" }}>{loginErr}</div>}
        <button onClick={doLogin} style={{ width:"100%", background:R, color:WHITE, border:"none", borderRadius:8, padding:"11px", fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"sans-serif" }}>
          लॉगिन करें →
        </button>
        <div style={{ textAlign:"center", marginTop:18, fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>
          demo: admin / delhinama123
        </div>
      </div>
    </div>
  );

  /* ── NAV ITEMS ── */
  const navItems = [
    { id:"dashboard", icon:"📊", label:"Dashboard" },
    { id:"articles", icon:"📰", label:"खबरें", count: articles.length },
    { id:"breaking", icon:"🔴", label:"ब्रेकिंग", count: breaking.length },
    { id:"bole", icon:"📢", label:"बोले फ्री", count: bole.filter(b=>b.status==="pending").length },
    { id:"stats", icon:"📈", label:"Analytics" },
  ];

  /* ── ADMIN LAYOUT ── */
  return (
    <div style={{ background:BG, minHeight:"100vh", display:"flex", fontFamily:"'Noto Sans Devanagari', sans-serif", color:WHITE }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&family=Noto+Serif+Devanagari:wght@700;900&display=swap');*{box-sizing:border-box;margin:0;padding:0}input,textarea,select{color:${WHITE};background:${CARD2};border:1px solid ${BORDER2};border-radius:7px;padding:8px 12px;font-size:13px;outline:none;width:100%;font-family:'Noto Sans Devanagari',sans-serif}input::placeholder,textarea::placeholder{color:${MUTED}}select option{background:${CARD2}}@keyframes slideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeIn{from{opacity:0}to{opacity:1}}.row-hover:hover{background:${CARD2}!important}.del-btn{background:transparent;border:1px solid ${BORDER};color:${MUTED};padding:4px 10px;border-radius:5px;cursor:pointer;font-size:11px;transition:all .15s;font-family:sans-serif}.del-btn:hover{background:${R}22;color:${R};border-color:${R}}.approve-btn{background:transparent;border:1px solid ${BORDER};color:${MUTED};padding:4px 10px;border-radius:5px;cursor:pointer;font-size:11px;transition:all .15s;font-family:sans-serif}.approve-btn:hover{background:${GREEN}22;color:${GREEN};border-color:${GREEN}}`}</style>

      {/* SIDEBAR */}
      <div style={{ width:210, background:CARD, borderRight:`1px solid ${BORDER}`, display:"flex", flexDirection:"column", flexShrink:0 }}>
        {/* Logo */}
        <div style={{ padding:"20px 18px 14px", borderBottom:`1px solid ${BORDER}` }}>
          <div style={{ fontSize:20, fontWeight:900, color:R, fontFamily:"'Noto Serif Devanagari', serif" }}>दिल्लीनामा</div>
          <div style={{ fontSize:8.5, color:GOLD, letterSpacing:3, fontFamily:"sans-serif", marginTop:3 }}>ADMIN PANEL</div>
        </div>
        {/* Nav */}
        <div style={{ padding:"10px 8px", flex:1 }}>
          {navItems.map(n => (
            <div key={n.id} onClick={()=>setActiveTab(n.id)} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 12px", borderRadius:8, cursor:"pointer", marginBottom:2, background: activeTab===n.id ? R+"22" : "transparent", borderLeft: activeTab===n.id ? `3px solid ${R}` : "3px solid transparent" }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ fontSize:16 }}>{n.icon}</span>
                <span style={{ fontSize:13, fontWeight: activeTab===n.id ? 700 : 500, color: activeTab===n.id ? WHITE : MUTED }}>{n.label}</span>
              </div>
              {n.count!==undefined && <span style={{ background: n.id==="bole"&&n.count>0 ? R : BORDER2, color: n.id==="bole"&&n.count>0 ? WHITE : MUTED, fontSize:10, fontWeight:700, padding:"1px 7px", borderRadius:10, fontFamily:"sans-serif" }}>{n.count}</span>}
            </div>
          ))}
        </div>
        {/* Logout */}
        <div style={{ padding:"14px 10px", borderTop:`1px solid ${BORDER}` }}>
          <div onClick={()=>setPage("login")} style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 12px", borderRadius:8, cursor:"pointer", color:MUTED, fontSize:12 }}>
            <span>🚪</span><span>लॉगआउट</span>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ flex:1, overflowY:"auto", overflowX:"hidden" }}>

        {/* Top bar */}
        <div style={{ background:CARD, borderBottom:`1px solid ${BORDER}`, padding:"12px 24px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, zIndex:50 }}>
          <div style={{ fontSize:16, fontWeight:700 }}>
            {{ dashboard:"📊 Dashboard", articles:"📰 खबरें प्रबंधन", breaking:"🔴 ब्रेकिंग न्यूज़", bole:"📢 बोले फ्री — Moderation", stats:"📈 Analytics" }[activeTab]}
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            <span style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>{new Date().toLocaleDateString("hi-IN",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</span>
            <div style={{ width:32, height:32, borderRadius:"50%", background:R, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:700 }}>A</div>
          </div>
        </div>

        <div style={{ padding:24 }}>

        {/* ══ DASHBOARD ══ */}
        {activeTab==="dashboard" && (
          <div style={{ animation:"fadeIn .3s ease" }}>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:24 }}>
              <Stat icon="📰" label="कुल खबरें" value={articles.length} sub={`${articles.filter(a=>a.status==="published").length} published`} color={GOLD} />
              <Stat icon="🔴" label="ब्रेकिंग" value={breaking.length} sub="Active tickers" color={R} />
              <Stat icon="📢" label="बोले फ्री" value={bole.filter(b=>b.status==="pending").length} sub="Pending approval" color="#E07820" />
              <Stat icon="👁" label="Total Views" value={articles.reduce((s,a)=>s+a.views,0).toLocaleString()} sub="All articles" color="#5BC0DE" />
            </div>

            {/* Recent articles */}
            <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, marginBottom:18 }}>
              <div style={{ padding:"14px 18px", borderBottom:`1px solid ${BORDER}`, display:"flex", justifyContent:"space-between" }}>
                <span style={{ fontSize:14, fontWeight:700 }}>हाल की खबरें</span>
                <span onClick={()=>setActiveTab("articles")} style={{ fontSize:12, color:GOLD, cursor:"pointer", fontFamily:"sans-serif" }}>सब देखें →</span>
              </div>
              {articles.slice(0,5).map((a,i) => (
                <div key={a.id} className="row-hover" style={{ padding:"11px 18px", borderBottom: i<4 ? `1px solid ${BORDER}` : "none", display:"flex", justifyContent:"space-between", alignItems:"center", transition:"background .15s" }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:13, fontWeight:600, color:WHITE, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", maxWidth:480 }}>{a.title}</div>
                    <div style={{ fontSize:11, color:MUTED, marginTop:3, fontFamily:"sans-serif" }}>{a.category} • {a.date} • 👁 {a.views.toLocaleString()}</div>
                  </div>
                  <span style={{ fontSize:10, fontWeight:700, padding:"2px 10px", borderRadius:4, fontFamily:"sans-serif", background: a.status==="published" ? GREEN+"33" : GOLD+"22", color: a.status==="published" ? "#5EC878" : GOLD, border:`1px solid ${a.status==="published" ? GREEN+"44" : GOLD+"33"}`, whiteSpace:"nowrap", marginLeft:12 }}>
                    {a.status==="published" ? "✓ Live" : "Draft"}
                  </span>
                </div>
              ))}
            </div>

            {/* Pending bole free */}
            {bole.filter(b=>b.status==="pending").length > 0 && (
              <div style={{ background:CARD, border:`1px solid ${R}33`, borderRadius:10 }}>
                <div style={{ padding:"14px 18px", borderBottom:`1px solid ${BORDER}`, display:"flex", justifyContent:"space-between" }}>
                  <span style={{ fontSize:14, fontWeight:700, color:GOLD }}>📢 Pending — बोले फ्री</span>
                  <span onClick={()=>setActiveTab("bole")} style={{ fontSize:12, color:GOLD, cursor:"pointer", fontFamily:"sans-serif" }}>Moderate →</span>
                </div>
                {bole.filter(b=>b.status==="pending").map((p,i) => (
                  <div key={p.id} className="row-hover" style={{ padding:"11px 18px", borderBottom: i<bole.filter(b=>b.status==="pending").length-1 ? `1px solid ${BORDER}` : "none", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div>
                      <span style={{ fontSize:12, fontWeight:600, color:WHITE }}>{p.name}</span>
                      <span style={{ fontSize:11, color:MUTED, marginLeft:10, fontFamily:"sans-serif" }}>{p.area} • {p.issue}</span>
                    </div>
                    <div style={{ display:"flex", gap:8 }}>
                      <button className="approve-btn" onClick={()=>updateBole(p.id,"approved")}>✓ Approve</button>
                      <button className="del-btn" onClick={()=>updateBole(p.id,"rejected")}>✗ Reject</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══ ARTICLES ══ */}
        {activeTab==="articles" && (
          <div style={{ animation:"fadeIn .3s ease" }}>
            {/* Toolbar */}
            <div style={{ display:"flex", gap:12, marginBottom:18, alignItems:"center", flexWrap:"wrap" }}>
              <button onClick={()=>setAddOpen(!addOpen)} style={{ background:R, color:WHITE, border:"none", borderRadius:7, padding:"9px 18px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"sans-serif", display:"flex", alignItems:"center", gap:6 }}>
                {addOpen ? "✕ बंद करें" : "+ नई खबर जोड़ें"}
              </button>
              <input value={searchQ} onChange={e=>setSearchQ(e.target.value)} placeholder="खबर खोजें..." style={{ maxWidth:240, background:CARD, border:`1px solid ${BORDER2}` }} />
              <select value={artFilter} onChange={e=>setArtFilter(e.target.value)} style={{ maxWidth:160, background:CARD }}>
                <option value="all">सभी</option>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
                {CATS.slice(0,6).map(c=><option key={c} value={c}>{c}</option>)}
              </select>
              <span style={{ fontSize:12, color:MUTED, fontFamily:"sans-serif", marginLeft:"auto" }}>{filteredArts.length} खबरें मिलीं</span>
            </div>

            {/* Add Article Form */}
            {addOpen && (
              <div style={{ background:CARD, border:`1px solid ${GOLD}44`, borderRadius:10, padding:20, marginBottom:18, animation:"slideUp .25s ease" }}>
                <div style={{ fontSize:14, fontWeight:700, color:GOLD, marginBottom:16, borderLeft:`3px solid ${GOLD}`, paddingLeft:10 }}>+ नई खबर</div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
                  <div style={{ gridColumn:"1/-1" }}>
                    <label style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>TITLE *</label>
                    <input value={newArticle.title} onChange={e=>setNewArticle({...newArticle,title:e.target.value})} placeholder="खबर का शीर्षक लिखें..." />
                  </div>
                  <div>
                    <label style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>CATEGORY</label>
                    <select value={newArticle.category} onChange={e=>setNewArticle({...newArticle,category:e.target.value})}>
                      {CATS.map(c=><option key={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>TAG</label>
                    <select value={newArticle.tag} onChange={e=>setNewArticle({...newArticle,tag:e.target.value})}>
                      {TAGS.map(t=><option key={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>AUTHOR *</label>
                    <input value={newArticle.author} onChange={e=>setNewArticle({...newArticle,author:e.target.value})} placeholder="लेखक / संवाददाता का नाम" />
                  </div>
                  <div>
                    <label style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>STATUS</label>
                    <select value={newArticle.status} onChange={e=>setNewArticle({...newArticle,status:e.target.value})}>
                      <option value="published">Published (Live)</option>
                      <option value="draft">Draft</option>
                    </select>
                  </div>
                  <div style={{ gridColumn:"1/-1" }}>
                    <label style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", display:"block", marginBottom:5 }}>EXCERPT</label>
                    <textarea value={newArticle.excerpt} onChange={e=>setNewArticle({...newArticle,excerpt:e.target.value})} placeholder="खबर का सारांश..." rows={3} style={{ resize:"vertical" }} />
                  </div>
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  <button onClick={addArticle} style={{ background:R, color:WHITE, border:"none", borderRadius:7, padding:"9px 22px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"sans-serif" }}>
                    ✓ खबर पब्लिश करें
                  </button>
                  <button onClick={()=>setAddOpen(false)} style={{ background:"transparent", color:MUTED, border:`1px solid ${BORDER2}`, borderRadius:7, padding:"9px 16px", fontSize:13, cursor:"pointer", fontFamily:"sans-serif" }}>रद्द</button>
                </div>
              </div>
            )}

            {/* Articles Table */}
            <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, overflow:"hidden" }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr auto auto auto auto auto", gap:0, padding:"10px 16px", borderBottom:`1px solid ${BORDER}`, fontSize:10, color:MUTED, fontFamily:"sans-serif", fontWeight:700, letterSpacing:.5 }}>
                <span>TITLE</span><span>CATEGORY</span><span>TAG</span><span>DATE</span><span>STATUS</span><span>ACTION</span>
              </div>
              {loading && <div style={{ padding:24, textAlign:"center", color:MUTED, fontFamily:"sans-serif" }}>Loading...</div>}
              {filteredArts.map((a,i) => (
                <div key={a.id} className="row-hover" style={{ display:"grid", gridTemplateColumns:"1fr auto auto auto auto auto", gap:12, padding:"11px 16px", borderBottom: i<filteredArts.length-1 ? `1px solid ${BORDER}` : "none", alignItems:"center", transition:"background .15s" }}>
                  <div>
                    <div style={{ fontSize:13, fontWeight:600, color:WHITE, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", maxWidth:380 }}>{a.title}</div>
                    <div style={{ fontSize:10, color:MUTED, marginTop:3, fontFamily:"sans-serif" }}>by {a.author} • 👁 {a.views.toLocaleString()}</div>
                  </div>
                  <span style={{ fontSize:11, color:GOLD, fontFamily:"sans-serif", whiteSpace:"nowrap", padding:"2px 8px", background:GOLD+"15", borderRadius:4 }}>{a.category}</span>
                  <span style={{ fontSize:10, fontWeight:700, color:WHITE, fontFamily:"sans-serif", whiteSpace:"nowrap", padding:"2px 8px", background:R+"22", borderRadius:4 }}>{a.tag}</span>
                  <span style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif", whiteSpace:"nowrap" }}>{a.date}</span>
                  <button onClick={()=>toggleStatus(a.id)} style={{ fontSize:10, fontWeight:700, padding:"3px 10px", borderRadius:4, fontFamily:"sans-serif", cursor:"pointer", border:"none", background: a.status==="published" ? GREEN+"33" : GOLD+"22", color: a.status==="published" ? "#5EC878" : GOLD, whiteSpace:"nowrap" }}>
                    {a.status==="published" ? "✓ Live" : "Draft"}
                  </button>
                  <button className="del-btn" onClick={()=>deleteArticle(a.id)}>🗑 हटाएं</button>
                </div>
              ))}
              {filteredArts.length===0 && <div style={{ padding:28, textAlign:"center", color:MUTED, fontSize:13 }}>कोई खबर नहीं मिली</div>}
            </div>
          </div>
        )}

        {/* ══ BREAKING NEWS ══ */}
        {activeTab==="breaking" && (
          <div style={{ animation:"fadeIn .3s ease" }}>
            <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, padding:20, marginBottom:18 }}>
              <div style={{ fontSize:13, fontWeight:700, color:WHITE, marginBottom:14, borderLeft:`3px solid ${R}`, paddingLeft:10 }}>+ नई ब्रेकिंग न्यूज़ जोड़ें</div>
              <div style={{ display:"flex", gap:10 }}>
                <input value={newBreaking} onChange={e=>setNewBreaking(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addBreaking()} placeholder="ब्रेकिंग न्यूज़ का text लिखें..." style={{ flex:1 }} />
                <button onClick={addBreaking} style={{ background:R, color:WHITE, border:"none", borderRadius:7, padding:"8px 20px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"sans-serif", whiteSpace:"nowrap" }}>+ जोड़ें</button>
              </div>
            </div>

            <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, overflow:"hidden" }}>
              <div style={{ padding:"12px 18px", borderBottom:`1px solid ${BORDER}`, fontSize:13, fontWeight:700, display:"flex", justifyContent:"space-between" }}>
                <span>Active Tickers <span style={{ fontSize:11, color:R, fontFamily:"sans-serif", marginLeft:8 }}>{breaking.length} items</span></span>
                <span style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>Drag to reorder (coming soon)</span>
              </div>
              {breaking.map((b,i) => (
                <div key={b.id} className="row-hover" style={{ padding:"13px 18px", borderBottom: i<breaking.length-1 ? `1px solid ${BORDER}` : "none", display:"flex", alignItems:"center", gap:12, transition:"background .15s" }}>
                  <span style={{ width:6, height:6, borderRadius:"50%", background:R, flexShrink:0, animation:"none" }}></span>
                  <span style={{ flex:1, fontSize:13, color:WHITE }}>{b.text}</span>
                  <button className="del-btn" onClick={()=>deleteBreaking(b.id)}>🗑 हटाएं</button>
                </div>
              ))}
              {breaking.length===0 && <div style={{ padding:28, textAlign:"center", color:MUTED, fontSize:13 }}>कोई ब्रेकिंग न्यूज़ नहीं</div>}
            </div>
          </div>
        )}

        {/* ══ BOLE FREE MODERATION ══ */}
        {activeTab==="bole" && (
          <div style={{ animation:"fadeIn .3s ease" }}>
            <div style={{ display:"flex", gap:12, marginBottom:18 }}>
              {["pending","approved","rejected"].map(s => (
                <div key={s} style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:8, padding:"10px 18px", textAlign:"center", minWidth:100 }}>
                  <div style={{ fontSize:20, fontWeight:700, color: s==="pending"?"#E07820":s==="approved"?GREEN:R, fontFamily:"sans-serif" }}>{bole.filter(b=>b.status===s).length}</div>
                  <div style={{ fontSize:11, color:MUTED, marginTop:2, fontFamily:"sans-serif", textTransform:"capitalize" }}>{s}</div>
                </div>
              ))}
            </div>

            {bole.map((p,i) => (
              <div key={p.id} style={{ background:CARD, border:`1px solid ${p.status==="pending"?GOLD+"33":BORDER}`, borderRadius:10, padding:18, marginBottom:12, animation:"slideUp .3s ease" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                  <div>
                    <span style={{ fontSize:14, fontWeight:700, color:WHITE }}>{p.name}</span>
                    <span style={{ fontSize:11, color:MUTED, marginLeft:10, fontFamily:"sans-serif" }}>{p.area} • {p.date}</span>
                    <span style={{ fontSize:10, fontWeight:700, color:R, marginLeft:10, background:R+"22", padding:"2px 8px", borderRadius:4, fontFamily:"sans-serif" }}>{p.issue}</span>
                  </div>
                  <span style={{ fontSize:10, fontWeight:700, padding:"3px 10px", borderRadius:5, fontFamily:"sans-serif", background: p.status==="approved"?GREEN+"33":p.status==="rejected"?R+"22":GOLD+"22", color: p.status==="approved"?"#5EC878":p.status==="rejected"?R:GOLD, border:`1px solid ${p.status==="approved"?GREEN+"44":p.status==="rejected"?R+"44":GOLD+"44"}` }}>
                    {p.status==="approved"?"✓ Approved":p.status==="rejected"?"✗ Rejected":"⏳ Pending"}
                  </span>
                </div>
                <div style={{ fontSize:13, color:"#b5b1ac", lineHeight:1.6, marginBottom:12 }}>{p.text}</div>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <span style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>👍 {p.votes} votes</span>
                  <div style={{ display:"flex", gap:8 }}>
                    {p.status!=="approved" && <button className="approve-btn" onClick={()=>updateBole(p.id,"approved")}>✓ Approve</button>}
                    {p.status!=="rejected" && <button className="del-btn" onClick={()=>updateBole(p.id,"rejected")} style={{ color:"#E07820", borderColor:"#E07820"+"44" }}>✗ Reject</button>}
                    <button className="del-btn" onClick={()=>deleteBole(p.id)}>🗑 Delete</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ══ ANALYTICS ══ */}
        {activeTab==="stats" && (
          <div style={{ animation:"fadeIn .3s ease" }}>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:24 }}>
              <Stat icon="📰" label="Total Articles" value={articles.length} color={GOLD} />
              <Stat icon="👁" label="Total Views" value={articles.reduce((s,a)=>s+a.views,0).toLocaleString()} color="#5BC0DE" />
              <Stat icon="✅" label="Published" value={articles.filter(a=>a.status==="published").length} color={GREEN+"99"} />
              <Stat icon="📝" label="Drafts" value={articles.filter(a=>a.status==="draft").length} color={MUTED} />
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              {/* Category breakdown */}
              <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, padding:18 }}>
                <div style={{ fontSize:13, fontWeight:700, marginBottom:14, borderLeft:`3px solid ${GOLD}`, paddingLeft:10 }}>Category Breakdown</div>
                {[...new Set(articles.map(a=>a.category))].map(cat => {
                  const count = articles.filter(a=>a.category===cat).length;
                  const pct = Math.round(count/articles.length*100);
                  return (
                    <div key={cat} style={{ marginBottom:12 }}>
                      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5, fontSize:12 }}>
                        <span style={{ color:WHITE }}>{cat}</span>
                        <span style={{ color:MUTED, fontFamily:"sans-serif" }}>{count} खबरें</span>
                      </div>
                      <div style={{ height:5, background:BORDER2, borderRadius:3 }}>
                        <div style={{ height:"100%", width:`${pct}%`, background:R, borderRadius:3, transition:"width .5s ease" }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Top stories */}
              <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:10, padding:18 }}>
                <div style={{ fontSize:13, fontWeight:700, marginBottom:14, borderLeft:`3px solid ${R}`, paddingLeft:10 }}>Top Stories by Views</div>
                {[...articles].sort((a,b)=>b.views-a.views).slice(0,5).map((a,i) => (
                  <div key={a.id} style={{ display:"flex", gap:12, alignItems:"flex-start", marginBottom:12 }}>
                    <span style={{ fontSize:18, fontWeight:900, color: i===0?GOLD:MUTED, fontFamily:"sans-serif", minWidth:24, lineHeight:1 }}>{i+1}</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:12, fontWeight:600, color:WHITE, lineHeight:1.4, overflow:"hidden", display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical" }}>{a.title}</div>
                      <div style={{ fontSize:10, color:MUTED, marginTop:4, fontFamily:"sans-serif" }}>👁 {a.views.toLocaleString()} views</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        </div>{/* /padding */}
      </div>{/* /main */}

      {/* Overlays */}
      {confirm && <Confirm msg={confirm.msg} onYes={confirm.onYes} onNo={confirm.onNo} />}
      <Toast msg={toast.msg} type={toast.type} />
    </div>
  );
}
