import { useState, useEffect, useCallback } from "react";

/* ── PALETTE ── */
const R="#C41E28", GOLD="#C8962E", BG="#07070A", CARD="#0F0F13", CARD2="#161619",
  WHITE="#EDE9E4", MUTED="#65635F", BORDER="#1D1D21", BORDER2="#252529",
  GREEN="#1B7A3A", BLUE="#1456A8", PURPLE="#6B21A8";

/* ── ROLE CONFIG ── */
const ROLES = {
  admin:    { label:"Admin",    color:R,      icon:"👑", perms:["dashboard","articles","breaking","bole","stats","users","settings"] },
  editor:   { label:"Editor",   color:GOLD,   icon:"✍️", perms:["dashboard","articles","breaking","bole","stats"] },
  reporter: { label:"Reporter", color:"#2E86C1", icon:"📰", perms:["dashboard","articles"] },
};

/* ── SEED USERS ── */
const SEED_USERS = [
  { id:1, username:"admin",    password:"delhinama123", name:"Suresh Admin",   role:"admin",    active:true,  lastLogin:"2025-05-27" },
  { id:2, username:"editor1",  password:"editor@123",  name:"Priya Sharma",   role:"editor",   active:true,  lastLogin:"2025-05-26" },
  { id:3, username:"reporter1",password:"reporter@1",  name:"Rahul Verma",    role:"reporter", active:true,  lastLogin:"2025-05-25" },
  { id:4, username:"reporter2",password:"reporter@2",  name:"Anita Singh",    role:"reporter", active:false, lastLogin:"2025-05-20" },
];

/* ── SEED DATA ── */
const SEED_ARTICLES = [
  { id:1, title:"दिल्ली का AQI 412 पार — NGT का आदेश: कल से सम-विषम लागू", category:"दिल्ली", tag:"ब्रेकिंग", author:"विशेष संवाददाता", excerpt:"प्रदूषण आपात स्थिति में NGT ने दिल्ली सरकार को सम-विषम योजना लागू करने के आदेश दिए।", date:"2025-05-27", status:"published", views:12400, createdBy:"reporter1" },
  { id:2, title:"PM मोदी का विपक्ष पर तीखा हमला: 'देश को गुमराह करना बंद करो'", category:"राजनीति", tag:"BJP", author:"राजनीतिक संवाददाता", excerpt:"प्रधानमंत्री ने लोकसभा में विपक्ष को कड़ा जवाब दिया।", date:"2025-05-27", status:"published", views:8900, createdBy:"editor1" },
  { id:3, title:"Nifty 23,450 के पार — IT और ऑटो सेक्टर में 3% की छलांग", category:"बाजार", tag:"मार्केट", author:"बिजनेस डेस्क", excerpt:"शेयर बाजार में तेजी, IT और फार्मा में जोरदार उछाल।", date:"2025-05-26", status:"published", views:5600, createdBy:"reporter2" },
  { id:4, title:"मणिपुर में फिर हिंसा — सेना ने संभाला मोर्चा, इंटरनेट बंद", category:"देश", tag:"राष्ट्रीय", author:"पूर्वोत्तर संवाददाता", excerpt:"मणिपुर में हिंसा की नई घटनाओं के बाद सेना की गश्त बढ़ी।", date:"2025-05-26", status:"published", views:9200, createdBy:"reporter1" },
  { id:5, title:"दिल्ली मेट्रो फेज-4: तीन स्टेशनों पर काम अटका", category:"दिल्ली", tag:"शहर", author:"शहरी डेस्क", excerpt:"DMRC के फेज-4 प्रोजेक्ट में नई अड़चन — भूमि अधिग्रहण विवाद।", date:"2025-05-25", status:"draft", views:0, createdBy:"reporter1" },
];
const SEED_BREAKING = [
  { id:1, text:"संसद सत्र में विपक्ष का हंगामा, कार्यवाही स्थगित" },
  { id:2, text:"दिल्ली में बारिश के बाद ITO, मिंटो ब्रिज पर जलभराव" },
  { id:3, text:"सेंसेक्स 400 अंक ऊपर, IT और फार्मा सेक्टर में तेजी" },
];
const SEED_BOLE = [
  { id:1, name:"रमेश शर्मा", area:"पटपड़गंज", issue:"टूटी सड़क", text:"6 महीने से गली में सड़क टूटी है।", status:"pending", date:"2025-05-27", votes:312 },
  { id:2, name:"सुनीता देवी", area:"शाहदरा", issue:"बिजली कटौती", text:"रोज 8-10 घंटे बिजली नहीं। बच्चे बीमार पड़ रहे हैं।", status:"pending", date:"2025-05-27", votes:245 },
  { id:3, name:"मोहम्मद अली", area:"जामिया नगर", issue:"सरकारी स्कूल", text:"80 बच्चों के लिए सिर्फ 2 टीचर।", status:"approved", date:"2025-05-26", votes:489 },
];

const CATS = ["देश","विदेश","राज्य","राजनीति","बाजार","मनोरंजन","दिल्ली","टेक","शिक्षा","कैरियर","ऑटो","यात्रा","लाइफ","अध्यात्म","फोटो","वीडियो"];
const TAGS = ["ब्रेकिंग","राष्ट्रीय","मार्केट","शहर","BJP","कांग्रेस","AAP","चुनाव","विशेष","ट्रेंडिंग"];

/* ── STORAGE ── */
const K = { users:"dnh:users", articles:"dnh:articles2", breaking:"dnh:breaking2", bole:"dnh:bole2", session:"dnh:session" };
async function dbGet(key, fallback) {
  try { const r = await window.storage.get(key); return r ? JSON.parse(r.value) : fallback; }
  catch { return fallback; }
}
async function dbSet(key, val) {
  try { await window.storage.set(key, JSON.stringify(val)); return true; }
  catch { return false; }
}

/* ── TINY COMPONENTS ── */
function Toast({ msg, type }) {
  const bg = type==="error"?R:type==="warn"?GOLD:GREEN;
  return msg ? <div style={{ position:"fixed",bottom:24,right:24,background:bg,color:WHITE,padding:"10px 20px",borderRadius:8,fontSize:13,fontFamily:"sans-serif",fontWeight:600,zIndex:9999,boxShadow:"0 4px 20px #0009",animation:"slideUp .3s ease" }}>{type==="error"?"✗ ":type==="warn"?"⚠ ":"✓ "}{msg}</div> : null;
}
function Confirm({ msg, onYes, onNo }) {
  return (
    <div style={{ position:"fixed",inset:0,background:"#000b",display:"flex",alignItems:"center",justifyContent:"center",zIndex:999 }}>
      <div style={{ background:CARD,border:`1px solid ${BORDER2}`,borderRadius:12,padding:28,maxWidth:340,width:"90%" }}>
        <div style={{ fontSize:15,fontWeight:600,color:WHITE,marginBottom:8 }}>क्या आप sure हैं?</div>
        <div style={{ fontSize:13,color:MUTED,marginBottom:20,fontFamily:"sans-serif" }}>{msg}</div>
        <div style={{ display:"flex",gap:10 }}>
          <button onClick={onNo} style={{ flex:1,padding:"9px",borderRadius:7,border:`1px solid ${BORDER2}`,background:"transparent",color:MUTED,cursor:"pointer",fontSize:13,fontFamily:"sans-serif" }}>रद्द करें</button>
          <button onClick={onYes} style={{ flex:1,padding:"9px",borderRadius:7,border:"none",background:R,color:WHITE,cursor:"pointer",fontSize:13,fontFamily:"sans-serif",fontWeight:700 }}>हाँ, आगे बढ़ें</button>
        </div>
      </div>
    </div>
  );
}
function Label({ text }) {
  return <label style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif",display:"block",marginBottom:5,letterSpacing:.4 }}>{text}</label>;
}
function Input(props) {
  return <input {...props} style={{ width:"100%",background:CARD2,border:`1px solid ${BORDER2}`,borderRadius:7,padding:"9px 12px",color:WHITE,fontSize:13,outline:"none",fontFamily:"'Noto Sans Devanagari',sans-serif",...(props.style||{}) }} />;
}
function Select({ value, onChange, options, style }) {
  return (
    <select value={value} onChange={onChange} style={{ width:"100%",background:CARD2,border:`1px solid ${BORDER2}`,borderRadius:7,padding:"9px 12px",color:WHITE,fontSize:13,outline:"none",fontFamily:"'Noto Sans Devanagari',sans-serif",...(style||{}) }}>
      {options.map(o => <option key={o.value||o} value={o.value||o}>{o.label||o}</option>)}
    </select>
  );
}
function Badge({ role }) {
  const r = ROLES[role]||ROLES.reporter;
  return <span style={{ fontSize:10,fontWeight:700,padding:"2px 9px",borderRadius:5,fontFamily:"sans-serif",background:r.color+"22",color:r.color,border:`1px solid ${r.color}33` }}>{r.icon} {r.label}</span>;
}
function Stat({ icon, label, value, sub, color=WHITE }) {
  return (
    <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:"16px 18px" }}>
      <div style={{ fontSize:22,marginBottom:6 }}>{icon}</div>
      <div style={{ fontSize:26,fontWeight:700,color,fontFamily:"sans-serif",marginBottom:2 }}>{value}</div>
      <div style={{ fontSize:13,fontWeight:600,color:WHITE,marginBottom:3 }}>{label}</div>
      {sub&&<div style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif" }}>{sub}</div>}
    </div>
  );
}

/* ════════════════════════════ MAIN APP ════════════════════════════ */
export default function AdminPanel() {
  const [screen, setScreen] = useState("boot"); // boot | login | admin
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState("dashboard");

  /* Data */
  const [users, setUsers] = useState([]);
  const [articles, setArticles] = useState([]);
  const [breaking, setBreaking] = useState([]);
  const [bole, setBole] = useState([]);

  /* UI state */
  const [toast, setToast] = useState({ msg:"", type:"success" });
  const [confirm, setConfirm] = useState(null);
  const [loading, setLoading] = useState(false);

  /* Login form */
  const [loginForm, setLoginForm] = useState({ username:"", password:"", remember:false });
  const [loginErr, setLoginErr] = useState("");
  const [showPass, setShowPass] = useState(false);

  /* Article form */
  const [addOpen, setAddOpen] = useState(false);
  const [newArt, setNewArt] = useState({ title:"", category:"दिल्ली", tag:"ब्रेकिंग", author:"", excerpt:"", status:"published" });
  const [artFilter, setArtFilter] = useState("all");
  const [searchQ, setSearchQ] = useState("");

  /* Breaking */
  const [newBreaking, setNewBreaking] = useState("");

  /* Settings - password change */
  const [pwForm, setPwForm] = useState({ current:"", newPw:"", confirm:"" });
  const [pwErr, setPwErr] = useState("");
  const [pwShow, setPwShow] = useState({ c:false, n:false, cf:false });

  /* User management (admin only) */
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [newUser, setNewUser] = useState({ username:"", password:"", name:"", role:"reporter", active:true });
  const [userErr, setUserErr] = useState("");
  const [editUserId, setEditUserId] = useState(null);

  const showToast = (msg, type="success") => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg:"", type:"success" }), 3000);
  };

  const hasPerm = useCallback((perm) => {
    if (!currentUser) return false;
    return ROLES[currentUser.role]?.perms.includes(perm);
  }, [currentUser]);

  /* ── BOOT: check saved session ── */
  useEffect(() => {
    (async () => {
      // Initialize users if needed
      let storedUsers = await dbGet(K.users, null);
      if (!storedUsers) { await dbSet(K.users, SEED_USERS); storedUsers = SEED_USERS; }
      setUsers(storedUsers);

      // Check saved session
      const session = await dbGet(K.session, null);
      if (session?.username) {
        const user = storedUsers.find(u => u.username === session.username && u.active);
        if (user) {
          setCurrentUser(user);
          setScreen("admin");
          return;
        }
      }
      setScreen("login");
    })();
  }, []);

  /* ── LOAD DATA ── */
  const loadData = useCallback(async () => {
    setLoading(true);
    const [arts, brk, bol] = await Promise.all([
      dbGet(K.articles, null),
      dbGet(K.breaking, null),
      dbGet(K.bole, null),
    ]);
    if (!arts) { await dbSet(K.articles, SEED_ARTICLES); setArticles(SEED_ARTICLES); }
    else setArticles(arts);
    if (!brk) { await dbSet(K.breaking, SEED_BREAKING); setBreaking(SEED_BREAKING); }
    else setBreaking(brk);
    if (!bol) { await dbSet(K.bole, SEED_BOLE); setBole(SEED_BOLE); }
    else setBole(bol);
    setLoading(false);
  }, []);

  useEffect(() => { if (screen === "admin") loadData(); }, [screen, loadData]);

  /* ── LOGIN ── */
  const doLogin = async () => {
    setLoginErr("");
    const allUsers = await dbGet(K.users, SEED_USERS);
    const user = allUsers.find(u => u.username === loginForm.username && u.password === loginForm.password);
    if (!user) { setLoginErr("गलत Username या Password"); return; }
    if (!user.active) { setLoginErr("यह account निष्क्रिय है। Admin से संपर्क करें।"); return; }

    // Update last login
    const updated = allUsers.map(u => u.id===user.id ? { ...u, lastLogin: new Date().toISOString().slice(0,10) } : u);
    await dbSet(K.users, updated);
    setUsers(updated);

    // Save session if remember checked
    if (loginForm.remember) await dbSet(K.session, { username: user.username });
    else await dbSet(K.session, null);

    setCurrentUser({ ...user, lastLogin: new Date().toISOString().slice(0,10) });
    setScreen("admin");
  };

  /* ── LOGOUT ── */
  const doLogout = async () => {
    await dbSet(K.session, null);
    setCurrentUser(null);
    setLoginForm({ username:"", password:"", remember:false });
    setScreen("login");
    setActiveTab("dashboard");
  };

  /* ── CHANGE PASSWORD ── */
  const doChangePassword = async () => {
    setPwErr("");
    if (!pwForm.current || !pwForm.newPw || !pwForm.confirm) { setPwErr("सभी fields भरें"); return; }
    if (pwForm.current !== currentUser.password) { setPwErr("मौजूदा पासवर्ड गलत है"); return; }
    if (pwForm.newPw.length < 6) { setPwErr("नया पासवर्ड कम से कम 6 characters का होना चाहिए"); return; }
    if (pwForm.newPw !== pwForm.confirm) { setPwErr("नया पासवर्ड और Confirm पासवर्ड match नहीं करते"); return; }

    const updated = users.map(u => u.id===currentUser.id ? { ...u, password: pwForm.newPw } : u);
    await dbSet(K.users, updated);
    setUsers(updated);
    setCurrentUser(prev => ({ ...prev, password: pwForm.newPw }));
    setPwForm({ current:"", newPw:"", confirm:"" });
    showToast("पासवर्ड सफलतापूर्वक बदल दिया गया!");
  };

  /* ── USER MANAGEMENT (admin only) ── */
  const addUser = async () => {
    setUserErr("");
    if (!newUser.username.trim() || !newUser.password.trim() || !newUser.name.trim()) { setUserErr("सभी fields जरूरी हैं"); return; }
    if (newUser.password.length < 6) { setUserErr("पासवर्ड कम से कम 6 characters का होना चाहिए"); return; }
    if (users.find(u => u.username === newUser.username)) { setUserErr("यह username पहले से मौजूद है"); return; }

    const user = { ...newUser, id: Date.now() };
    const updated = [...users, user];
    await dbSet(K.users, updated);
    setUsers(updated);
    setNewUser({ username:"", password:"", name:"", role:"reporter", active:true });
    setAddUserOpen(false);
    showToast("नया user जोड़ा गया!");
  };

  const toggleUserActive = async (id) => {
    if (id === currentUser.id) { showToast("खुद को disable नहीं कर सकते", "error"); return; }
    const updated = users.map(u => u.id===id ? { ...u, active: !u.active } : u);
    await dbSet(K.users, updated);
    setUsers(updated);
    showToast("User status बदल दिया गया");
  };

  const deleteUser = (id) => {
    if (id === currentUser.id) { showToast("खुद को delete नहीं कर सकते", "error"); return; }
    setConfirm({ msg:"यह user हमेशा के लिए हट जाएगा।", onYes: async () => {
      const updated = users.filter(u => u.id !== id);
      await dbSet(K.users, updated);
      setUsers(updated);
      setConfirm(null);
      showToast("User हटा दिया गया", "error");
    }, onNo: () => setConfirm(null) });
  };

  const updateUserRole = async (id, role) => {
    if (id === currentUser.id) { showToast("खुद की role नहीं बदल सकते", "warn"); return; }
    const updated = users.map(u => u.id===id ? { ...u, role } : u);
    await dbSet(K.users, updated);
    setUsers(updated);
    showToast("Role बदल दी गई");
  };

  /* ── ARTICLES ── */
  const addArticle = async () => {
    if (!newArt.title.trim() || !newArt.author.trim()) { showToast("Title और Author जरूरी है", "error"); return; }
    const art = { ...newArt, id:Date.now(), date:new Date().toISOString().slice(0,10), views:0, createdBy:currentUser.username };
    const updated = [art, ...articles];
    await dbSet(K.articles, updated);
    setArticles(updated);
    setNewArt({ title:"", category:"दिल्ली", tag:"ब्रेकिंग", author:"", excerpt:"", status:"published" });
    setAddOpen(false);
    showToast("खबर सफलतापूर्वक जोड़ी गई!");
  };

  const deleteArticle = (id) => {
    setConfirm({ msg:"यह खबर हमेशा के लिए हट जाएगी।", onYes: async () => {
      const updated = articles.filter(a => a.id!==id);
      await dbSet(K.articles, updated);
      setArticles(updated);
      setConfirm(null);
      showToast("खबर हटा दी गई", "error");
    }, onNo: () => setConfirm(null) });
  };

  const toggleStatus = async (id) => {
    if (!hasPerm("breaking")) { showToast("आपके पास यह permission नहीं है", "error"); return; }
    const updated = articles.map(a => a.id===id ? { ...a, status:a.status==="published"?"draft":"published" } : a);
    await dbSet(K.articles, updated);
    setArticles(updated);
    showToast("Status बदल दिया गया");
  };

  /* ── BREAKING ── */
  const addBreaking = async () => {
    if (!newBreaking.trim()) return;
    const item = { id:Date.now(), text:newBreaking.trim() };
    const updated = [item, ...breaking];
    await dbSet(K.breaking, updated);
    setBreaking(updated);
    setNewBreaking("");
    showToast("ब्रेकिंग न्यूज़ जोड़ी गई!");
  };
  const deleteBreaking = async (id) => {
    const updated = breaking.filter(b => b.id!==id);
    await dbSet(K.breaking, updated);
    setBreaking(updated);
    showToast("ब्रेकिंग हटाई गई", "error");
  };

  /* ── BOLE FREE ── */
  const updateBole = async (id, status) => {
    const updated = bole.map(b => b.id===id ? { ...b, status } : b);
    await dbSet(K.bole, updated);
    setBole(updated);
    showToast(status==="approved" ? "पोस्ट Approve हुई ✓" : "पोस्ट Reject हुई");
  };
  const deleteBole = (id) => {
    setConfirm({ msg:"यह पोस्ट हटा दी जाएगी।", onYes: async () => {
      const updated = bole.filter(b => b.id!==id);
      await dbSet(K.bole, updated);
      setBole(updated);
      setConfirm(null);
      showToast("पोस्ट हटाई गई", "error");
    }, onNo: () => setConfirm(null) });
  };

  const filteredArts = articles.filter(a => {
    const matchF = artFilter==="all"||a.status===artFilter||a.category===artFilter;
    const matchQ = !searchQ||a.title.includes(searchQ)||a.category.includes(searchQ);
    // Reporter can only see own articles
    const matchOwn = currentUser?.role==="reporter" ? a.createdBy===currentUser.username : true;
    return matchF && matchQ && matchOwn;
  });

  /* ── NAV ── */
  const NAV = [
    { id:"dashboard", icon:"📊", label:"Dashboard" },
    { id:"articles",  icon:"📰", label:"खबरें",    count:articles.length },
    { id:"breaking",  icon:"🔴", label:"ब्रेकिंग", count:breaking.length },
    { id:"bole",      icon:"📢", label:"बोले फ्री", count:bole.filter(b=>b.status==="pending").length, badge:true },
    { id:"stats",     icon:"📈", label:"Analytics" },
    { id:"users",     icon:"👥", label:"Users",     count:users.length, adminOnly:true },
    { id:"settings",  icon:"⚙️", label:"Settings" },
  ].filter(n => !n.adminOnly || currentUser?.role==="admin");

  /* ══════════════════ BOOT SCREEN ══════════════════ */
  if (screen === "boot") return (
    <div style={{ background:BG,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center" }}>
      <style>{CSS}</style>
      <div style={{ textAlign:"center" }}>
        <div style={{ fontSize:24,fontWeight:900,color:R,fontFamily:"serif" }}>दिल्लीनामा</div>
        <div style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif",marginTop:8 }}>Loading...</div>
      </div>
    </div>
  );

  /* ══════════════════ LOGIN SCREEN ══════════════════ */
  if (screen === "login") return (
    <div style={{ background:BG,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",padding:16 }}>
      <style>{CSS}</style>
      <div style={{ background:CARD,border:`1px solid ${BORDER2}`,borderRadius:16,padding:"40px 36px",width:"100%",maxWidth:400,animation:"slideUp .4s ease" }}>

        {/* Logo */}
        <div style={{ textAlign:"center",marginBottom:30 }}>
          <div style={{ display:"inline-flex",width:54,height:54,borderRadius:14,background:R+"22",border:`1.5px solid ${R}44`,alignItems:"center",justifyContent:"center",fontSize:24,marginBottom:12 }}>📰</div>
          <div style={{ fontSize:26,fontWeight:900,color:R,fontFamily:"serif" }}>दिल्लीनामा</div>
          <div style={{ fontSize:9,color:GOLD,letterSpacing:4,fontFamily:"sans-serif",marginTop:4 }}>ADMIN PANEL</div>
        </div>

        {/* Form */}
        <div style={{ marginBottom:14 }}>
          <Label text="USERNAME" />
          <Input value={loginForm.username} onChange={e=>setLoginForm({...loginForm,username:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="अपना username डालें" />
        </div>
        <div style={{ marginBottom:14,position:"relative" }}>
          <Label text="PASSWORD" />
          <Input type={showPass?"text":"password"} value={loginForm.password} onChange={e=>setLoginForm({...loginForm,password:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="••••••••••" />
          <span onClick={()=>setShowPass(!showPass)} style={{ position:"absolute",right:12,top:30,cursor:"pointer",fontSize:14,color:MUTED }}>
            {showPass?"🙈":"👁"}
          </span>
        </div>

        {/* Remember me */}
        <div style={{ display:"flex",alignItems:"center",gap:9,marginBottom:18,cursor:"pointer" }} onClick={()=>setLoginForm({...loginForm,remember:!loginForm.remember})}>
          <div style={{ width:18,height:18,borderRadius:4,border:`1.5px solid ${loginForm.remember?R:BORDER2}`,background:loginForm.remember?R+"33":"transparent",display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s" }}>
            {loginForm.remember && <span style={{ fontSize:11,color:R,fontWeight:900 }}>✓</span>}
          </div>
          <span style={{ fontSize:12,color:MUTED,fontFamily:"sans-serif" }}>Login याद रखें (browser बंद होने पर भी)</span>
        </div>

        {loginErr && <div style={{ fontSize:12,color:R,marginBottom:14,fontFamily:"sans-serif",textAlign:"center",background:R+"15",padding:"8px 12px",borderRadius:6,border:`1px solid ${R}33` }}>{loginErr}</div>}

        <button onClick={doLogin} style={{ width:"100%",background:R,color:WHITE,border:"none",borderRadius:8,padding:"11px",fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif",transition:"opacity .2s" }}>
          लॉगिन करें →
        </button>

        {/* Demo credentials */}
        <div style={{ marginTop:22,background:CARD2,borderRadius:8,padding:"12px 14px",border:`1px solid ${BORDER}` }}>
          <div style={{ fontSize:10,color:MUTED,fontFamily:"sans-serif",letterSpacing:.5,marginBottom:8,fontWeight:700 }}>DEMO ACCOUNTS</div>
          {SEED_USERS.filter(u=>u.active).map(u=>(
            <div key={u.id} onClick={()=>setLoginForm({username:u.username,password:u.password,remember:loginForm.remember})} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"5px 0",cursor:"pointer",borderBottom:`1px solid ${BORDER}` }}>
              <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                <span style={{ fontSize:12 }}>{ROLES[u.role].icon}</span>
                <span style={{ fontSize:12,color:WHITE,fontFamily:"sans-serif" }}>{u.username}</span>
              </div>
              <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                <span style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif" }}>{u.password}</span>
                <Badge role={u.role} />
              </div>
            </div>
          ))}
          <div style={{ fontSize:10,color:MUTED,fontFamily:"sans-serif",marginTop:6 }}>👆 क्लिक करके auto-fill करें</div>
        </div>

      </div>
    </div>
  );

  /* ══════════════════ ADMIN LAYOUT ══════════════════ */
  return (
    <div style={{ background:BG,minHeight:"100vh",display:"flex",fontFamily:"'Noto Sans Devanagari',sans-serif",color:WHITE }}>
      <style>{CSS}</style>

      {/* ── SIDEBAR ── */}
      <div style={{ width:215,background:CARD,borderRight:`1px solid ${BORDER}`,display:"flex",flexDirection:"column",flexShrink:0 }}>
        <div style={{ padding:"18px 16px 14px",borderBottom:`1px solid ${BORDER}` }}>
          <div style={{ fontSize:20,fontWeight:900,color:R,fontFamily:"serif" }}>दिल्लीनामा</div>
          <div style={{ fontSize:8.5,color:GOLD,letterSpacing:3.5,fontFamily:"sans-serif",marginTop:3 }}>ADMIN PANEL</div>
        </div>

        {/* User info card */}
        <div style={{ margin:"12px 10px",background:CARD2,borderRadius:9,padding:"10px 12px",border:`1px solid ${BORDER2}` }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <div style={{ width:34,height:34,borderRadius:"50%",background:ROLES[currentUser?.role]?.color+"33",border:`1.5px solid ${ROLES[currentUser?.role]?.color}55`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,flexShrink:0 }}>
              {ROLES[currentUser?.role]?.icon}
            </div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:12.5,fontWeight:700,color:WHITE,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{currentUser?.name}</div>
              <Badge role={currentUser?.role} />
            </div>
          </div>
        </div>

        {/* Nav */}
        <div style={{ padding:"6px 8px",flex:1,overflowY:"auto" }}>
          {NAV.filter(n=>hasPerm(n.id)).map(n=>(
            <div key={n.id} onClick={()=>setActiveTab(n.id)} style={{ display:"flex",alignItems:"center",justifyContent:"space-between",padding:"9px 11px",borderRadius:8,cursor:"pointer",marginBottom:2,background:activeTab===n.id?R+"22":"transparent",borderLeft:activeTab===n.id?`3px solid ${R}`:"3px solid transparent",transition:"all .15s" }}>
              <div style={{ display:"flex",alignItems:"center",gap:9 }}>
                <span style={{ fontSize:15 }}>{n.icon}</span>
                <span style={{ fontSize:13,fontWeight:activeTab===n.id?700:500,color:activeTab===n.id?WHITE:MUTED }}>{n.label}</span>
              </div>
              {n.count!==undefined && <span style={{ background:n.badge&&n.count>0?R:BORDER2,color:n.badge&&n.count>0?WHITE:MUTED,fontSize:10,fontWeight:700,padding:"1px 7px",borderRadius:10,fontFamily:"sans-serif" }}>{n.count}</span>}
            </div>
          ))}
        </div>

        {/* Logout */}
        <div style={{ padding:"12px 10px",borderTop:`1px solid ${BORDER}` }}>
          <div onClick={doLogout} style={{ display:"flex",alignItems:"center",gap:9,padding:"9px 11px",borderRadius:8,cursor:"pointer",color:MUTED,fontSize:12,transition:"color .15s" }}>
            <span>🚪</span><span>लॉगआउट</span>
          </div>
        </div>
      </div>

      {/* ── MAIN ── */}
      <div style={{ flex:1,overflowY:"auto",overflowX:"hidden" }}>

        {/* Topbar */}
        <div style={{ background:CARD,borderBottom:`1px solid ${BORDER}`,padding:"11px 24px",display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,zIndex:50 }}>
          <div style={{ fontSize:15,fontWeight:700 }}>
            {{"dashboard":"📊 Dashboard","articles":"📰 खबरें","breaking":"🔴 ब्रेकिंग न्यूज़","bole":"📢 बोले फ्री","stats":"📈 Analytics","users":"👥 User Management","settings":"⚙️ Settings"}[activeTab]}
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:14 }}>
            <span style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif" }}>{new Date().toLocaleDateString("hi-IN",{weekday:"short",day:"numeric",month:"short"})}</span>
            <div onClick={()=>setActiveTab("settings")} style={{ display:"flex",alignItems:"center",gap:8,cursor:"pointer",background:CARD2,border:`1px solid ${BORDER2}`,borderRadius:8,padding:"5px 10px" }}>
              <div style={{ width:26,height:26,borderRadius:"50%",background:ROLES[currentUser?.role]?.color+"33",border:`1.5px solid ${ROLES[currentUser?.role]?.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12 }}>
                {ROLES[currentUser?.role]?.icon}
              </div>
              <span style={{ fontSize:12,color:WHITE,fontFamily:"sans-serif" }}>{currentUser?.name?.split(" ")[0]}</span>
            </div>
          </div>
        </div>

        <div style={{ padding:22 }}>

        {/* ══ DASHBOARD ══ */}
        {activeTab==="dashboard" && (
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:22 }}>
              <Stat icon="📰" label="खबरें" value={articles.length} sub={`${articles.filter(a=>a.status==="published").length} live`} color={GOLD} />
              <Stat icon="🔴" label="ब्रेकिंग" value={breaking.length} sub="Active tickers" color={R} />
              <Stat icon="📢" label="Pending" value={bole.filter(b=>b.status==="pending").length} sub="बोले फ्री" color="#E07820" />
              <Stat icon="👥" label="Users" value={users.filter(u=>u.active).length} sub={`${users.length} total`} color={BLUE+"cc"} />
            </div>
            {/* Recent + pending widget same as before */}
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,marginBottom:16 }}>
              <div style={{ padding:"13px 18px",borderBottom:`1px solid ${BORDER}`,display:"flex",justifyContent:"space-between" }}>
                <span style={{ fontSize:14,fontWeight:700 }}>हाल की खबरें</span>
                <span onClick={()=>setActiveTab("articles")} style={{ fontSize:12,color:GOLD,cursor:"pointer",fontFamily:"sans-serif" }}>सब देखें →</span>
              </div>
              {articles.slice(0,5).map((a,i)=>(
                <div key={a.id} className="rh" style={{ padding:"10px 18px",borderBottom:i<4?`1px solid ${BORDER}`:"none",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:460 }}>{a.title}</div>
                    <div style={{ fontSize:10,color:MUTED,marginTop:2,fontFamily:"sans-serif" }}>{a.category} • {a.date} • by {a.createdBy}</div>
                  </div>
                  <span style={{ fontSize:10,fontWeight:700,padding:"2px 9px",borderRadius:4,fontFamily:"sans-serif",background:a.status==="published"?GREEN+"33":GOLD+"22",color:a.status==="published"?"#5EC878":GOLD,marginLeft:12,whiteSpace:"nowrap" }}>
                    {a.status==="published"?"✓ Live":"Draft"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ ARTICLES ══ */}
        {activeTab==="articles" && (
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"flex",gap:10,marginBottom:16,flexWrap:"wrap",alignItems:"center" }}>
              <button onClick={()=>setAddOpen(!addOpen)} style={{ background:R,color:WHITE,border:"none",borderRadius:7,padding:"9px 16px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif" }}>
                {addOpen?"✕ बंद करें":"+ नई खबर"}
              </button>
              <Input value={searchQ} onChange={e=>setSearchQ(e.target.value)} placeholder="खोजें..." style={{ maxWidth:200 }} />
              <Select value={artFilter} onChange={e=>setArtFilter(e.target.value)} style={{ maxWidth:150 }} options={[{value:"all",label:"सभी"},{value:"published",label:"Published"},{value:"draft",label:"Draft"},...CATS.slice(0,5).map(c=>({value:c,label:c}))]} />
              {currentUser?.role==="reporter" && <span style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif" }}>सिर्फ आपकी खबरें दिख रही हैं</span>}
            </div>

            {addOpen && (
              <div style={{ background:CARD,border:`1px solid ${GOLD}44`,borderRadius:10,padding:20,marginBottom:16,animation:"slideUp .25s" }}>
                <div style={{ fontSize:13,fontWeight:700,color:GOLD,marginBottom:14,borderLeft:`3px solid ${GOLD}`,paddingLeft:10 }}>+ नई खबर जोड़ें</div>
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                  <div style={{ gridColumn:"1/-1" }}><Label text="TITLE *" /><Input value={newArt.title} onChange={e=>setNewArt({...newArt,title:e.target.value})} placeholder="खबर का शीर्षक..." /></div>
                  <div><Label text="CATEGORY" /><Select value={newArt.category} onChange={e=>setNewArt({...newArt,category:e.target.value})} options={CATS} /></div>
                  <div><Label text="TAG" /><Select value={newArt.tag} onChange={e=>setNewArt({...newArt,tag:e.target.value})} options={TAGS} /></div>
                  <div><Label text="AUTHOR *" /><Input value={newArt.author} onChange={e=>setNewArt({...newArt,author:e.target.value})} placeholder="लेखक का नाम" /></div>
                  <div><Label text="STATUS" /><Select value={newArt.status} onChange={e=>setNewArt({...newArt,status:e.target.value})} options={[{value:"published",label:"Published (Live)"},{value:"draft",label:"Draft"}]} /></div>
                  <div style={{ gridColumn:"1/-1" }}><Label text="EXCERPT" /><textarea value={newArt.excerpt} onChange={e=>setNewArt({...newArt,excerpt:e.target.value})} placeholder="खबर का सारांश..." rows={3} style={{ width:"100%",background:CARD2,border:`1px solid ${BORDER2}`,borderRadius:7,padding:"9px 12px",color:WHITE,fontSize:13,outline:"none",fontFamily:"'Noto Sans Devanagari',sans-serif",resize:"vertical" }} /></div>
                </div>
                <div style={{ display:"flex",gap:10,marginTop:14 }}>
                  <button onClick={addArticle} style={{ background:R,color:WHITE,border:"none",borderRadius:7,padding:"9px 22px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif" }}>✓ पब्लिश करें</button>
                  <button onClick={()=>setAddOpen(false)} style={{ background:"transparent",color:MUTED,border:`1px solid ${BORDER2}`,borderRadius:7,padding:"9px 16px",fontSize:13,cursor:"pointer",fontFamily:"sans-serif" }}>रद्द</button>
                </div>
              </div>
            )}

            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,overflow:"hidden" }}>
              {filteredArts.map((a,i)=>(
                <div key={a.id} className="rh" style={{ padding:"11px 16px",borderBottom:i<filteredArts.length-1?`1px solid ${BORDER}`:"none",display:"flex",alignItems:"center",gap:10 }}>
                  <div style={{ flex:1,minWidth:0 }}>
                    <div style={{ fontSize:13,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{a.title}</div>
                    <div style={{ fontSize:10,color:MUTED,marginTop:3,fontFamily:"sans-serif" }}>by {a.author} • {a.category} • {a.date}</div>
                  </div>
                  <span style={{ fontSize:10,color:GOLD,fontFamily:"sans-serif",whiteSpace:"nowrap",padding:"2px 7px",background:GOLD+"15",borderRadius:4 }}>{a.tag}</span>
                  {hasPerm("breaking") && (
                    <button onClick={()=>toggleStatus(a.id)} style={{ fontSize:10,fontWeight:700,padding:"3px 10px",borderRadius:4,cursor:"pointer",border:"none",background:a.status==="published"?GREEN+"33":GOLD+"22",color:a.status==="published"?"#5EC878":GOLD,whiteSpace:"nowrap",fontFamily:"sans-serif" }}>
                      {a.status==="published"?"✓ Live":"Draft"}
                    </button>
                  )}
                  <button className="db" onClick={()=>deleteArticle(a.id)}>🗑</button>
                </div>
              ))}
              {filteredArts.length===0 && <div style={{ padding:28,textAlign:"center",color:MUTED,fontSize:13 }}>कोई खबर नहीं मिली</div>}
            </div>
          </div>
        )}

        {/* ══ BREAKING ══ */}
        {activeTab==="breaking" && (
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:18,marginBottom:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:12,borderLeft:`3px solid ${R}`,paddingLeft:10 }}>+ नई ब्रेकिंग जोड़ें</div>
              <div style={{ display:"flex",gap:10 }}>
                <Input value={newBreaking} onChange={e=>setNewBreaking(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addBreaking()} placeholder="ब्रेकिंग न्यूज़ का text..." />
                <button onClick={addBreaking} style={{ background:R,color:WHITE,border:"none",borderRadius:7,padding:"9px 20px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif",whiteSpace:"nowrap" }}>+ जोड़ें</button>
              </div>
            </div>
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,overflow:"hidden" }}>
              {breaking.map((b,i)=>(
                <div key={b.id} className="rh" style={{ padding:"13px 18px",borderBottom:i<breaking.length-1?`1px solid ${BORDER}`:"none",display:"flex",alignItems:"center",gap:12 }}>
                  <span style={{ width:7,height:7,borderRadius:"50%",background:R,flexShrink:0 }}></span>
                  <span style={{ flex:1,fontSize:13 }}>{b.text}</span>
                  <button className="db" onClick={()=>deleteBreaking(b.id)}>🗑</button>
                </div>
              ))}
              {!breaking.length && <div style={{ padding:28,textAlign:"center",color:MUTED,fontSize:13 }}>कोई ब्रेकिंग नहीं</div>}
            </div>
          </div>
        )}

        {/* ══ BOLE FREE ══ */}
        {activeTab==="bole" && (
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"flex",gap:12,marginBottom:16 }}>
              {["pending","approved","rejected"].map(s=>(
                <div key={s} style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:8,padding:"10px 18px",textAlign:"center",minWidth:90 }}>
                  <div style={{ fontSize:22,fontWeight:700,color:s==="pending"?"#E07820":s==="approved"?GREEN:R,fontFamily:"sans-serif" }}>{bole.filter(b=>b.status===s).length}</div>
                  <div style={{ fontSize:11,color:MUTED,marginTop:2,fontFamily:"sans-serif" }}>{s}</div>
                </div>
              ))}
            </div>
            {bole.map(p=>(
              <div key={p.id} style={{ background:CARD,border:`1px solid ${p.status==="pending"?GOLD+"33":BORDER}`,borderRadius:10,padding:16,marginBottom:12,animation:"slideUp .3s" }}>
                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:9 }}>
                  <div>
                    <span style={{ fontSize:14,fontWeight:700 }}>{p.name}</span>
                    <span style={{ fontSize:11,color:MUTED,marginLeft:10,fontFamily:"sans-serif" }}>{p.area} • {p.date}</span>
                    <span style={{ fontSize:10,fontWeight:700,color:R,marginLeft:10,background:R+"22",padding:"2px 8px",borderRadius:4,fontFamily:"sans-serif" }}>{p.issue}</span>
                  </div>
                  <span style={{ fontSize:10,fontWeight:700,padding:"3px 10px",borderRadius:5,fontFamily:"sans-serif",background:p.status==="approved"?GREEN+"33":p.status==="rejected"?R+"22":GOLD+"22",color:p.status==="approved"?"#5EC878":p.status==="rejected"?R:GOLD }}>
                    {p.status==="approved"?"✓ Approved":p.status==="rejected"?"✗ Rejected":"⏳ Pending"}
                  </span>
                </div>
                <div style={{ fontSize:13,color:"#b5b1ac",lineHeight:1.6,marginBottom:10 }}>{p.text}</div>
                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                  <span style={{ fontSize:11,color:MUTED,fontFamily:"sans-serif" }}>👍 {p.votes}</span>
                  <div style={{ display:"flex",gap:8 }}>
                    {p.status!=="approved" && <button className="ab" onClick={()=>updateBole(p.id,"approved")}>✓ Approve</button>}
                    {p.status!=="rejected" && <button className="db" onClick={()=>updateBole(p.id,"rejected")}>✗ Reject</button>}
                    <button className="db" onClick={()=>deleteBole(p.id)}>🗑 Delete</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ══ ANALYTICS ══ */}
        {activeTab==="stats" && (
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:22 }}>
              <Stat icon="📰" label="Total Articles" value={articles.length} color={GOLD} />
              <Stat icon="👁" label="Total Views" value={articles.reduce((s,a)=>s+a.views,0).toLocaleString()} color="#5BC0DE" />
              <Stat icon="✅" label="Published" value={articles.filter(a=>a.status==="published").length} color={GREEN+"cc"} />
              <Stat icon="👥" label="Active Users" value={users.filter(u=>u.active).length} color={BLUE+"cc"} />
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:16 }}>
              <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:18 }}>
                <div style={{ fontSize:13,fontWeight:700,marginBottom:14,borderLeft:`3px solid ${GOLD}`,paddingLeft:10 }}>Category Breakdown</div>
                {[...new Set(articles.map(a=>a.category))].map(cat=>{
                  const count=articles.filter(a=>a.category===cat).length;
                  const pct=Math.round(count/articles.length*100);
                  return (
                    <div key={cat} style={{ marginBottom:11 }}>
                      <div style={{ display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:12 }}>
                        <span>{cat}</span><span style={{ color:MUTED,fontFamily:"sans-serif" }}>{count}</span>
                      </div>
                      <div style={{ height:5,background:BORDER2,borderRadius:3 }}>
                        <div style={{ height:"100%",width:`${pct}%`,background:R,borderRadius:3,transition:"width .5s" }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:18 }}>
                <div style={{ fontSize:13,fontWeight:700,marginBottom:14,borderLeft:`3px solid ${R}`,paddingLeft:10 }}>Top Stories</div>
                {[...articles].sort((a,b)=>b.views-a.views).slice(0,5).map((a,i)=>(
                  <div key={a.id} style={{ display:"flex",gap:10,marginBottom:11,alignItems:"flex-start" }}>
                    <span style={{ fontSize:18,fontWeight:900,color:i===0?GOLD:MUTED,fontFamily:"sans-serif",minWidth:22,lineHeight:1 }}>{i+1}</span>
                    <div>
                      <div style={{ fontSize:12,fontWeight:600,lineHeight:1.4 }}>{a.title.slice(0,60)}…</div>
                      <div style={{ fontSize:10,color:MUTED,marginTop:3,fontFamily:"sans-serif" }}>👁 {a.views.toLocaleString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ══ USER MANAGEMENT (admin only) ══ */}
        {activeTab==="users" && currentUser?.role==="admin" && (
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"flex",gap:12,marginBottom:16,flexWrap:"wrap" }}>
              <button onClick={()=>setAddUserOpen(!addUserOpen)} style={{ background:BLUE,color:WHITE,border:"none",borderRadius:7,padding:"9px 16px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif" }}>
                {addUserOpen?"✕ बंद करें":"+ नया User"}
              </button>
              <div style={{ display:"flex",gap:10,marginLeft:"auto" }}>
                {Object.entries(ROLES).map(([k,v])=>(
                  <span key={k} style={{ fontSize:11,fontFamily:"sans-serif",color:v.color,background:v.color+"18",padding:"4px 12px",borderRadius:6,border:`1px solid ${v.color}33` }}>
                    {v.icon} {v.label}: {users.filter(u=>u.role===k).length}
                  </span>
                ))}
              </div>
            </div>

            {addUserOpen && (
              <div style={{ background:CARD,border:`1px solid ${BLUE}44`,borderRadius:10,padding:20,marginBottom:16,animation:"slideUp .25s" }}>
                <div style={{ fontSize:13,fontWeight:700,color:"#5BC0DE",marginBottom:14,borderLeft:`3px solid ${BLUE}`,paddingLeft:10 }}>+ नया User जोड़ें</div>
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                  <div><Label text="FULL NAME *" /><Input value={newUser.name} onChange={e=>setNewUser({...newUser,name:e.target.value})} placeholder="पूरा नाम" /></div>
                  <div><Label text="USERNAME *" /><Input value={newUser.username} onChange={e=>setNewUser({...newUser,username:e.target.value})} placeholder="login username" /></div>
                  <div><Label text="PASSWORD *" /><Input type="password" value={newUser.password} onChange={e=>setNewUser({...newUser,password:e.target.value})} placeholder="कम से कम 6 characters" /></div>
                  <div><Label text="ROLE" /><Select value={newUser.role} onChange={e=>setNewUser({...newUser,role:e.target.value})} options={Object.entries(ROLES).map(([k,v])=>({value:k,label:`${v.icon} ${v.label}`}))} /></div>
                </div>
                {userErr && <div style={{ fontSize:12,color:R,marginTop:10,fontFamily:"sans-serif" }}>{userErr}</div>}
                <div style={{ display:"flex",gap:10,marginTop:14 }}>
                  <button onClick={addUser} style={{ background:BLUE,color:WHITE,border:"none",borderRadius:7,padding:"9px 22px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif" }}>✓ User जोड़ें</button>
                  <button onClick={()=>{setAddUserOpen(false);setUserErr("")}} style={{ background:"transparent",color:MUTED,border:`1px solid ${BORDER2}`,borderRadius:7,padding:"9px 16px",fontSize:13,cursor:"pointer",fontFamily:"sans-serif" }}>रद्द</button>
                </div>
              </div>
            )}

            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,overflow:"hidden" }}>
              <div style={{ display:"grid",gridTemplateColumns:"1fr auto auto auto auto",gap:0,padding:"10px 16px",borderBottom:`1px solid ${BORDER}`,fontSize:10,color:MUTED,fontFamily:"sans-serif",fontWeight:700,letterSpacing:.5 }}>
                <span>USER</span><span>USERNAME</span><span>ROLE</span><span>STATUS</span><span>ACTION</span>
              </div>
              {users.map((u,i)=>(
                <div key={u.id} className="rh" style={{ display:"grid",gridTemplateColumns:"1fr auto auto auto auto",gap:14,padding:"12px 16px",borderBottom:i<users.length-1?`1px solid ${BORDER}`:"none",alignItems:"center" }}>
                  <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                    <div style={{ width:32,height:32,borderRadius:"50%",background:ROLES[u.role]?.color+"25",border:`1.5px solid ${ROLES[u.role]?.color}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0 }}>{ROLES[u.role]?.icon}</div>
                    <div>
                      <div style={{ fontSize:13,fontWeight:600,color:WHITE }}>{u.name}{u.id===currentUser.id&&<span style={{ fontSize:10,color:GOLD,marginLeft:8,fontFamily:"sans-serif" }}>(आप)</span>}</div>
                      <div style={{ fontSize:10,color:MUTED,marginTop:2,fontFamily:"sans-serif" }}>Last login: {u.lastLogin||"Never"}</div>
                    </div>
                  </div>
                  <span style={{ fontSize:12,color:MUTED,fontFamily:"sans-serif",fontStyle:"italic" }}>{u.username}</span>
                  <Select value={u.role} onChange={e=>updateUserRole(u.id,e.target.value)} style={{ width:130,padding:"5px 8px",fontSize:11 }}
                    options={Object.entries(ROLES).map(([k,v])=>({value:k,label:`${v.icon} ${v.label}`}))} />
                  <button onClick={()=>toggleUserActive(u.id)} style={{ fontSize:10,fontWeight:700,padding:"4px 11px",borderRadius:5,cursor:"pointer",border:"none",background:u.active?GREEN+"33":R+"22",color:u.active?"#5EC878":R,fontFamily:"sans-serif",whiteSpace:"nowrap" }}>
                    {u.active?"● Active":"○ Inactive"}
                  </button>
                  <button className="db" onClick={()=>deleteUser(u.id)}>🗑</button>
                </div>
              ))}
            </div>

            {/* Role permissions table */}
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:18,marginTop:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:14,borderLeft:`3px solid ${PURPLE}`,paddingLeft:10,color:WHITE }}>Role Permissions</div>
              <div style={{ display:"grid",gridTemplateColumns:`auto repeat(${Object.keys(ROLES).length},1fr)`,gap:0,fontSize:11,fontFamily:"sans-serif" }}>
                <div style={{ padding:"6px 12px",fontWeight:700,color:MUTED }}>SECTION</div>
                {Object.entries(ROLES).map(([k,v])=>(
                  <div key={k} style={{ padding:"6px 12px",textAlign:"center",fontWeight:700,color:v.color }}>{v.icon} {v.label}</div>
                ))}
                {["dashboard","articles","breaking","bole","stats","users","settings"].map(perm=>(
                  <>
                    <div key={perm+"l"} style={{ padding:"6px 12px",color:MUTED,borderTop:`1px solid ${BORDER}` }}>{perm}</div>
                    {Object.entries(ROLES).map(([k,v])=>(
                      <div key={k+perm} style={{ padding:"6px 12px",textAlign:"center",borderTop:`1px solid ${BORDER}` }}>
                        {v.perms.includes(perm) ? <span style={{ color:GREEN }}>✓</span> : <span style={{ color:R }}>✗</span>}
                      </div>
                    ))}
                  </>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ══ SETTINGS ══ */}
        {activeTab==="settings" && (
          <div style={{ animation:"fadeIn .3s",maxWidth:560 }}>

            {/* Profile */}
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:20,marginBottom:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:16,borderLeft:`3px solid ${GOLD}`,paddingLeft:10 }}>👤 Profile</div>
              <div style={{ display:"flex",alignItems:"center",gap:16 }}>
                <div style={{ width:58,height:58,borderRadius:"50%",background:ROLES[currentUser?.role]?.color+"33",border:`2px solid ${ROLES[currentUser?.role]?.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0 }}>
                  {ROLES[currentUser?.role]?.icon}
                </div>
                <div>
                  <div style={{ fontSize:18,fontWeight:700,color:WHITE }}>{currentUser?.name}</div>
                  <div style={{ fontSize:12,color:MUTED,fontFamily:"sans-serif",marginTop:3 }}>@{currentUser?.username}</div>
                  <div style={{ marginTop:6 }}><Badge role={currentUser?.role} /></div>
                </div>
              </div>
            </div>

            {/* Change Password */}
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:20,marginBottom:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:16,borderLeft:`3px solid ${R}`,paddingLeft:10 }}>🔑 पासवर्ड बदलें</div>

              {[
                { key:"current", label:"मौजूदा पासवर्ड", show:pwShow.c, toggle:()=>setPwShow({...pwShow,c:!pwShow.c}) },
                { key:"newPw",   label:"नया पासवर्ड",     show:pwShow.n, toggle:()=>setPwShow({...pwShow,n:!pwShow.n}) },
                { key:"confirm", label:"नया पासवर्ड confirm करें", show:pwShow.cf, toggle:()=>setPwShow({...pwShow,cf:!pwShow.cf}) },
              ].map(f=>(
                <div key={f.key} style={{ marginBottom:14,position:"relative" }}>
                  <Label text={f.label.toUpperCase()} />
                  <Input type={f.show?"text":"password"} value={pwForm[f.key]} onChange={e=>setPwForm({...pwForm,[f.key]:e.target.value})} placeholder="••••••••" />
                  <span onClick={f.toggle} style={{ position:"absolute",right:12,top:30,cursor:"pointer",fontSize:14,color:MUTED }}>{f.show?"🙈":"👁"}</span>
                </div>
              ))}

              {pwErr && <div style={{ fontSize:12,color:R,marginBottom:12,fontFamily:"sans-serif",background:R+"15",padding:"8px 12px",borderRadius:6,border:`1px solid ${R}33` }}>{pwErr}</div>}

              {/* Password strength indicator */}
              {pwForm.newPw && (
                <div style={{ marginBottom:14 }}>
                  <div style={{ display:"flex",gap:4,marginBottom:4 }}>
                    {[
                      pwForm.newPw.length >= 6,
                      /[A-Z]/.test(pwForm.newPw),
                      /[0-9]/.test(pwForm.newPw),
                      /[@#$!%^&*]/.test(pwForm.newPw),
                    ].map((ok,i)=>(
                      <div key={i} style={{ flex:1,height:4,borderRadius:2,background:ok?GREEN:BORDER2,transition:"background .3s" }}></div>
                    ))}
                  </div>
                  <div style={{ fontSize:10,color:MUTED,fontFamily:"sans-serif" }}>
                    {[pwForm.newPw.length>=6,/[A-Z]/.test(pwForm.newPw),/[0-9]/.test(pwForm.newPw),/[@#$!%^&*]/.test(pwForm.newPw)].filter(Boolean).length} / 4 — 6+ chars, uppercase, number, special
                  </div>
                </div>
              )}

              <button onClick={doChangePassword} style={{ background:R,color:WHITE,border:"none",borderRadius:7,padding:"10px 24px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif" }}>
                🔑 पासवर्ड बदलें
              </button>
            </div>

            {/* Session */}
            <div style={{ background:CARD,border:`1px solid ${BORDER}`,borderRadius:10,padding:20 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:14,borderLeft:`3px solid ${BLUE}`,paddingLeft:10 }}>🔐 Session Info</div>
              <div style={{ fontSize:13,color:MUTED,lineHeight:1.8,fontFamily:"sans-serif" }}>
                <div>Status: <span style={{ color:GREEN }}>● Active</span></div>
                <div>Last Login: <span style={{ color:WHITE }}>{currentUser?.lastLogin}</span></div>
                <div>Remember Me: <span style={{ color:WHITE }}>Storage-based (persistent)</span></div>
              </div>
              <button onClick={async()=>{await dbSet(K.session,null);showToast("Session clear हो गया","warn")}} style={{ marginTop:14,background:"transparent",color:MUTED,border:`1px solid ${BORDER2}`,borderRadius:7,padding:"8px 16px",fontSize:12,cursor:"pointer",fontFamily:"sans-serif" }}>
                सभी Sessions Clear करें
              </button>
            </div>
          </div>
        )}

        </div>
      </div>

      {confirm && <Confirm msg={confirm.msg} onYes={confirm.onYes} onNo={confirm.onNo} />}
      <Toast msg={toast.msg} type={toast.type} />
    </div>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&family=Noto+Serif+Devanagari:wght@700;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
@keyframes slideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
input::placeholder,textarea::placeholder{color:${MUTED}}
select option{background:${CARD2};color:${WHITE}}
.rh{transition:background .15s;cursor:default}.rh:hover{background:${CARD2}!important}
.db{background:transparent;border:1px solid ${BORDER};color:${MUTED};padding:4px 10px;border-radius:5px;cursor:pointer;font-size:11px;transition:all .15s;font-family:sans-serif}
.db:hover{background:${R}22;color:${R};border-color:${R}}
.ab{background:transparent;border:1px solid ${BORDER};color:${MUTED};padding:4px 10px;border-radius:5px;cursor:pointer;font-size:11px;transition:all .15s;font-family:sans-serif}
.ab:hover{background:${GREEN}22;color:${GREEN};border-color:${GREEN}}
`;
