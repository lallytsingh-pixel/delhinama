import { useState, useEffect, useCallback, useRef } from "react";
import { AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

/* ══════════════════════════════════════════════════════
   SHARED CONSTANTS
══════════════════════════════════════════════════════ */
const C = {
  R:"#C41E28", GOLD:"#C8962E", BG:"#060608", CARD:"#0E0E12", CARD2:"#141418",
  W:"#EDE9E4", MUTED:"#606060", BORDER:"#1A1A1E", BORDER2:"#222228",
  GREEN:"#16A34A", BLUE:"#1D4ED8", PURPLE:"#7C3AED", TEAL:"#0D9488",
  ORANGE:"#EA580C", PINK:"#DB2777"
};

/* ── Shared Storage ── */
const SK = {
  articles:"dnh:pub:articles", breaking:"dnh:pub:breaking",
  bole:"dnh:pub:bole", theme:"dnh:pub:theme", reels:"dnh:pub:reels",
  users:"dnh:adm:users", session:"dnh:adm:session",
  ads:"dnh:adm:ads", auditlog:"dnh:adm:log",
  categories:"dnh:pub:cats", polls:"dnh:pub:polls",
  newsletter:"dnh:pub:newsletter",
};
async function dbGet(k, fb) { try { const r = await window.storage.get(k); return r ? JSON.parse(r.value) : fb; } catch { return fb; } }
async function dbSet(k, v) { try { await window.storage.set(k, JSON.stringify(v)); return true; } catch { return false; } }

/* ── Seed Data ── */
const SEED_ARTICLES = [
  { id:1, title:"दिल्ली का AQI 412 पार — NGT का सम-विषम आदेश जारी", category:"दिल्ली", tag:"ब्रेकिंग", author:"विशेष संवाददाता", excerpt:"प्रदूषण की आपात स्थिति में NGT ने दिल्ली सरकार को सम-विषम लागू करने के आदेश दिए।", date:"2025-05-27", status:"published", views:24400, featured:true, seo_title:"दिल्ली AQI 412: NGT का सम-विषम आदेश", seo_desc:"दिल्ली में प्रदूषण खतरनाक स्तर पर, NGT ने तत्काल आदेश जारी किया।" },
  { id:2, title:"PM मोदी का विपक्ष पर तीखा हमला: 'देश को गुमराह करना बंद करो'", category:"राजनीति", tag:"BJP", author:"राजनीतिक संवाददाता", excerpt:"प्रधानमंत्री ने लोकसभा में विपक्ष को कड़ा जवाब दिया।", date:"2025-05-27", status:"published", views:18900, featured:false, seo_title:"", seo_desc:"" },
  { id:3, title:"Nifty 23,450 के पार — IT और ऑटो में 3% की छलांग", category:"बाजार", tag:"मार्केट", author:"बिजनेस डेस्क", excerpt:"शेयर बाजार में जोरदार तेजी, सेंसेक्स भी 400 अंक ऊपर।", date:"2025-05-26", status:"published", views:14200, featured:false, seo_title:"", seo_desc:"" },
  { id:4, title:"मणिपुर में फिर हिंसा — सेना हाई अलर्ट, इंटरनेट बंद", category:"देश", tag:"राष्ट्रीय", author:"पूर्वोत्तर डेस्क", excerpt:"मणिपुर में हिंसा की नई घटनाओं के बाद सेना की गश्त बढ़ाई गई।", date:"2025-05-26", status:"published", views:9200, featured:false, seo_title:"", seo_desc:"" },
  { id:5, title:"दिल्ली मेट्रो फेज-4 में नई अड़चन — 3 स्टेशनों पर काम ठप", category:"दिल्ली", tag:"शहर", author:"शहरी डेस्क", excerpt:"भूमि अधिग्रहण विवाद के कारण मेट्रो फेज-4 का काम रुका।", date:"2025-05-25", status:"published", views:8400, featured:false, seo_title:"", seo_desc:"" },
];
const SEED_BREAKING = [
  { id:1, text:"संसद सत्र में विपक्ष का हंगामा, कार्यवाही स्थगित" },
  { id:2, text:"दिल्ली में बारिश के बाद ITO पर जलभराव, ट्रैफिक जाम" },
  { id:3, text:"सेंसेक्स 400 अंक ऊपर, IT और फार्मा सेक्टर में तेजी" },
];
const SEED_BOLE = [
  { id:1, name:"रमेश शर्मा", area:"पटपड़गंज", issue:"टूटी सड़क", text:"6 महीने से गली में सड़क टूटी है, नगर पालिका नहीं सुन रही।", status:"approved", date:"2025-05-27", votes:312 },
  { id:2, name:"सुनीता देवी", area:"शाहदरा", issue:"बिजली कटौती", text:"रोज 8-10 घंटे बिजली नहीं। बच्चे बीमार पड़ रहे हैं।", status:"approved", date:"2025-05-27", votes:245 },
  { id:3, name:"मोहम्मद अली", area:"जामिया नगर", issue:"सरकारी स्कूल", text:"80 बच्चों के लिए सिर्फ 2 टीचर। बच्चों का भविष्य खतरे में।", status:"pending", date:"2025-05-26", votes:489 },
];
const SEED_USERS = [
  { id:1, username:"admin",    password:"delhinama@123", name:"Suresh Admin",  role:"admin",    active:true },
  { id:2, username:"editor1",  password:"editor@123",   name:"Priya Sharma",  role:"editor",   active:true },
  { id:3, username:"reporter1",password:"report@123",   name:"Rahul Verma",   role:"reporter", active:true },
];
const SEED_CATS = ["देश","विदेश","राज्य","राजनीति","बाजार","मनोरंजन","दिल्ली","टेक","शिक्षा","कैरियर","ऑटो","यात्रा","लाइफ","अध्यात्म","फोटो","वीडियो","बोले फ्री"];
const SEED_THEME = { primary:"#C41E28", accent:"#C8962E", bg:"#060608", font:"Noto Sans Devanagari" };
const SEED_REELS = [
  { id:1, title:"दिल्ली प्रदूषण ग्राउंड रिपोर्ट", views:214000, likes:8400, status:"published", category:"दिल्ली" },
  { id:2, title:"संसद में हंगामा — पूरा सच", views:531000, likes:21200, status:"published", category:"राजनीति" },
];
const SEED_POLLS = [
  { id:1, q:"दिल्ली की सबसे बड़ी समस्या कौन सी है?", opts:["प्रदूषण","ट्रैफिक","बिजली-पानी","महंगाई"], votes:[1240,890,1100,760], active:true },
];
const SEED_ADS = [
  { id:1, name:"Delhi Elections 2025", slot:"Hero Banner", status:"active", impressions:124000, clicks:3200, rev:18400, client:"BJP Media Cell" },
  { id:2, name:"Flipkart Big Sale",   slot:"Sidebar",      status:"active", impressions:89200, clicks:4100, rev:12200, client:"Flipkart" },
];

const ROLES = {
  admin:   { label:"Admin",    color:C.R,      icon:"👑", perms:["all"] },
  editor:  { label:"Editor",   color:C.GOLD,   icon:"✍️", perms:["articles","breaking","bole","reels"] },
  reporter:{ label:"Reporter", color:C.BLUE,   icon:"📰", perms:["articles"] },
};
const ALL_TAGS = ["ब्रेकिंग","राष्ट्रीय","मार्केट","शहर","BJP","कांग्रेस","AAP","चुनाव","विशेष","ट्रेंडिंग"];

/* ══════════════════════════════════════════════════════
   SHARED UI ATOMS
══════════════════════════════════════════════════════ */
const globalCSS = `
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&family=Noto+Serif+Devanagari:wght@700;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes ticker{from{transform:translateX(0)}to{transform:translateX(-50%)}}
@keyframes slideUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
::-webkit-scrollbar{width:3px;height:3px}
::-webkit-scrollbar-thumb{background:#222;border-radius:3px}
.rh:hover{background:${C.CARD2}!important}
.btn{border:none;border-radius:7px;padding:8px 15px;font-size:12px;font-weight:700;cursor:pointer;font-family:'Noto Sans Devanagari',sans-serif;transition:opacity .15s;display:inline-flex;align-items:center;gap:6px}
.btn:hover{opacity:.85}.btn:disabled{opacity:.5;cursor:default}
.btn-r{background:${C.R};color:#fff}.btn-g{background:${C.GREEN};color:#fff}
.btn-b{background:${C.BLUE};color:#fff}.btn-p{background:${C.PURPLE};color:#fff}
.btn-gold{background:${C.GOLD};color:#fff}.btn-ghost{background:transparent;border:1px solid ${C.BORDER2};color:${C.MUTED}}
.inp{width:100%;background:${C.CARD2};border:1px solid ${C.BORDER2};border-radius:7px;padding:9px 12px;color:${C.W};font-size:13px;outline:none;font-family:'Noto Sans Devanagari',sans-serif}
.inp:focus{border-color:${C.PURPLE}88}
select.inp option{background:${C.CARD2}}
textarea.inp{resize:vertical;min-height:80px}
`;

function Toast({ msg, type }) {
  const col = type==="error"?C.R:type==="warn"?C.GOLD:C.GREEN;
  return msg ? <div style={{ position:"fixed",bottom:24,right:24,background:col,color:"#fff",padding:"10px 20px",borderRadius:8,fontSize:12,fontFamily:"sans-serif",fontWeight:700,zIndex:9999,boxShadow:"0 4px 24px #0009",animation:"slideUp .3s" }}>{msg}</div> : null;
}
function Toggle({ val, onChange, color=C.GREEN }) {
  return <div onClick={()=>onChange(!val)} style={{ width:38,height:21,borderRadius:11,background:val?color:C.BORDER2,position:"relative",cursor:"pointer",transition:"background .2s",flexShrink:0 }}><div style={{ width:15,height:15,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:val?20:3,transition:"left .2s" }}></div></div>;
}
function Badge({ text, color=C.MUTED }) {
  return <span style={{ fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:4,fontFamily:"sans-serif",background:color+"22",color,border:`1px solid ${color}33` }}>{text}</span>;
}
function Lbl({ t }) { return <label style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:5,letterSpacing:.4 }}>{t}</label>; }
function Spin() { return <div style={{ width:14,height:14,border:`2px solid ${C.BORDER2}`,borderTopColor:C.PURPLE,borderRadius:"50%",animation:"spin .7s linear infinite" }}></div>; }
function SHead({ icon, label, color=C.GOLD, sub }) {
  return <div style={{ borderLeft:`3px solid ${color}`,paddingLeft:12,marginBottom:20 }}><div style={{ fontSize:16,fontWeight:700,color:C.W }}>{icon} {label}</div>{sub&&<div style={{ fontSize:11,color:C.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{sub}</div>}</div>;
}
function Card({ ch, style }) { return <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18,...style }}>{ch}</div>; }

/* ══════════════════════════════════════════════════════
   PUBLIC WEBSITE
══════════════════════════════════════════════════════ */
function Website({ onGoAdmin }) {
  const [articles, setArticles] = useState([]);
  const [breaking, setBreaking] = useState([]);
  const [bole, setBole] = useState([]);
  const [theme, setTheme] = useState(SEED_THEME);
  const [reels, setReels] = useState([]);
  const [polls, setPolls] = useState([]);
  const [cats, setCats] = useState(SEED_CATS);
  const [tick, setTick] = useState(0);
  const [tickOn, setTickOn] = useState(true);
  const [activeNav, setActiveNav] = useState("होम");
  const [voted, setVoted] = useState(null);
  const [pollVotes, setPollVotes] = useState(null);

  const load = useCallback(async () => {
    const [a,b,bl,th,r,p,ct] = await Promise.all([
      dbGet(SK.articles, SEED_ARTICLES),
      dbGet(SK.breaking, SEED_BREAKING),
      dbGet(SK.bole, SEED_BOLE),
      dbGet(SK.theme, SEED_THEME),
      dbGet(SK.reels, SEED_REELS),
      dbGet(SK.polls, SEED_POLLS),
      dbGet(SK.categories, SEED_CATS),
    ]);
    setArticles(a); setBreaking(b); setBole(bl.filter(x=>x.status==="approved"));
    setTheme(th); setReels(r.filter(x=>x.status==="published")); setPolls(p); setCats(ct);
    // init pollVotes
    const pv = {};
    p.forEach(pl=>{ pv[pl.id]=[...pl.votes]; });
    setPollVotes(pv);
  }, []);

  useEffect(() => { load(); const iv = setInterval(load, 5000); return ()=>clearInterval(iv); }, [load]);

  useEffect(() => {
    if (!breaking.length) return;
    const iv = setInterval(() => {
      setTickOn(false);
      setTimeout(()=>{ setTick(t=>(t+1)%breaking.length); setTickOn(true); }, 250);
    }, 5000);
    return ()=>clearInterval(iv);
  }, [breaking]);

  const pub = articles.filter(a=>a.status==="published");
  const hero = pub.find(a=>a.featured) || pub[0];
  const sideArts = pub.filter(a=>a.id!==hero?.id).slice(0,4);
  const delhiArts = pub.filter(a=>a.category==="दिल्ली").slice(0,6);
  const polArts = pub.filter(a=>a.category==="राजनीति").slice(0,4);
  const pr = theme.primary||C.R, ac = theme.accent||C.GOLD;

  const doVotePoll = (pollId, optIdx) => {
    if (voted === pollId) return;
    setVoted(pollId);
    setPollVotes(pv=>({ ...pv, [pollId]: pv[pollId].map((v,i)=>i===optIdx?v+1:v) }));
  };

  return (
    <div style={{ background:"#080809",color:C.W,fontFamily:"'Noto Sans Devanagari',sans-serif",minHeight:"100vh" }}>
      {/* TOP BAR */}
      <div style={{ background:"#000",borderBottom:`1px solid #1a1a1a`,padding:"4px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",fontSize:11,color:C.MUTED,fontFamily:"sans-serif" }}>
        <div style={{ display:"flex",gap:16 }}>
          <span>मंगलवार, 27 मई 2025</span>
          <span style={{ color:"#333" }}>│</span>
          <span>🌡 दिल्ली 38°C</span>
          <span style={{ color:"#333" }}>│</span>
          <span>AQI: <b style={{ color:"#E05030" }}>187</b></span>
        </div>
        <div style={{ display:"flex",gap:14,alignItems:"center" }}>
          <span style={{ display:"flex",alignItems:"center",gap:5 }}>
            <span style={{ width:6,height:6,borderRadius:"50%",background:pr,display:"inline-block",animation:"pulse 1.4s infinite" }}></span>
            <span style={{ color:pr,fontWeight:700 }}>LIVE TV</span>
          </span>
          <span style={{ color:"#333" }}>│</span>
          <span onClick={onGoAdmin} style={{ cursor:"pointer",color:C.MUTED,borderLeft:`1px solid #222`,paddingLeft:14 }}>🔐 Admin</span>
        </div>
      </div>

      {/* HEADER */}
      <div style={{ background:C.CARD,borderBottom:`2.5px solid ${pr}`,padding:"10px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:100 }}>
        <div>
          <div style={{ fontSize:28,fontWeight:900,color:pr,fontFamily:"'Noto Serif Devanagari',serif",letterSpacing:-1 }}>दिल्लीनामा</div>
          <div style={{ fontSize:9,color:ac,letterSpacing:3.5,fontFamily:"sans-serif",marginTop:2 }}>DELHINAMA • दिल्ली की असली आवाज़</div>
        </div>
        <div style={{ flex:1,maxWidth:320,margin:"0 24px",background:C.CARD2,border:`1px solid ${C.BORDER2}`,borderRadius:7,padding:"7px 14px",display:"flex",alignItems:"center",gap:8 }}>
          <span style={{ color:C.MUTED,fontSize:14 }}>🔍</span>
          <span style={{ fontSize:13,color:C.MUTED }}>खोजें — खबर, शहर, मुद्दा...</span>
        </div>
        <div style={{ display:"flex",gap:8 }}>
          {[{l:"YT",co:"#FF0000"},{l:"FB",co:"#1877F2"},{l:"TW",co:"#1DA1F2"}].map(({l,co})=>(
            <div key={l} style={{ width:28,height:28,borderRadius:6,background:C.CARD2,border:`1px solid ${C.BORDER2}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,color:co,fontFamily:"sans-serif",fontWeight:700,cursor:"pointer" }}>{l}</div>
          ))}
          <div style={{ background:pr,color:"#fff",padding:"6px 14px",borderRadius:7,fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif" }}>SUBSCRIBE</div>
        </div>
      </div>

      {/* BREAKING TICKER */}
      {breaking.length > 0 && (
        <div style={{ background:pr,display:"flex",alignItems:"stretch",minHeight:32 }}>
          <div style={{ background:"#8B0000",padding:"6px 16px",fontSize:11,fontWeight:700,color:"#fff",letterSpacing:1,fontFamily:"sans-serif",display:"flex",alignItems:"center",gap:5,whiteSpace:"nowrap" }}>
            <span style={{ width:6,height:6,borderRadius:"50%",background:"#fff",display:"inline-block",animation:"pulse 1s infinite" }}></span>
            ब्रेकिंग न्यूज़
          </div>
          <div style={{ padding:"6px 18px",fontSize:13,color:"#fff",flex:1,animation:tickOn?"fadeIn .3s ease":"none" }}>
            {breaking[tick]?.text || ""}
          </div>
        </div>
      )}

      {/* NAV */}
      <div style={{ background:C.CARD,borderBottom:`1px solid ${C.BORDER}`,overflowX:"auto",scrollbarWidth:"none" }}>
        <div style={{ display:"flex",padding:"0 8px",minWidth:"max-content" }}>
          {cats.slice(0,14).map(cat=>(
            <div key={cat} onClick={()=>setActiveNav(cat)} style={{ padding:"8px 14px",cursor:"pointer",fontSize:13,fontWeight:500,color:activeNav===cat?ac:C.MUTED,borderBottom:activeNav===cat?`2px solid ${ac}`:"2px solid transparent",whiteSpace:"nowrap",transition:"all .15s" }}>{cat}</div>
          ))}
        </div>
      </div>

      <div style={{ maxWidth:1280,margin:"0 auto",padding:"18px 18px" }}>

        {/* HERO */}
        {hero && (
          <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:14,marginBottom:22 }}>
            <div style={{ borderRadius:10,overflow:"hidden",background:C.CARD,border:`1px solid ${C.BORDER}`,cursor:"pointer" }}>
              <div style={{ height:290,background:`linear-gradient(160deg,#2d0609 0%,#090810 55%,#180a00 100%)`,position:"relative",display:"flex",flexDirection:"column",justifyContent:"flex-end" }}>
                <div style={{ position:"absolute",inset:0,background:"linear-gradient(to top,#000000f0 0%,#00000044 45%,transparent 100%)" }}></div>
                <div style={{ position:"absolute",top:14,left:14,display:"flex",gap:8 }}>
                  <span style={{ background:pr,color:"#fff",padding:"3px 10px",borderRadius:5,fontSize:10,fontWeight:700,fontFamily:"sans-serif" }}>{hero.tag}</span>
                  <span style={{ background:ac+"25",color:ac,padding:"3px 10px",borderRadius:5,fontSize:10,fontWeight:600,border:`1px solid ${ac}44`,fontFamily:"sans-serif" }}>{hero.category}</span>
                </div>
                <div style={{ position:"relative",zIndex:2,padding:"0 20px 18px" }}>
                  <div style={{ fontSize:20,fontWeight:700,lineHeight:1.45,color:"#fff",fontFamily:"'Noto Serif Devanagari',serif",marginBottom:8 }}>{hero.title}</div>
                  <div style={{ fontSize:12,color:"#c8c4bf",lineHeight:1.6 }}>{hero.excerpt}</div>
                  <div style={{ fontSize:10,color:C.MUTED,marginTop:8,fontFamily:"sans-serif" }}>{hero.date} • {hero.author} • 👁 {hero.views?.toLocaleString()}</div>
                </div>
              </div>
            </div>
            <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
              {sideArts.map((a,i)=>(
                <div key={a.id} style={{ background:C.CARD,borderRadius:8,border:`1px solid ${C.BORDER}`,display:"flex",gap:0,overflow:"hidden",cursor:"pointer" }}>
                  <div style={{ width:80,minWidth:80,background:[`#0a1230`,`#200a0a`,`#0a1a0e`,`#0e0a1e`][i],display:"flex",alignItems:"center",justifyContent:"center",fontSize:20 }}>
                    {["📰","🗺️","📈","✈️"][i]}
                  </div>
                  <div style={{ padding:"10px 12px",flex:1 }}>
                    <span style={{ fontSize:10,fontWeight:700,color:pr,fontFamily:"sans-serif" }}>{a.category}</span>
                    <div style={{ fontSize:12.5,fontWeight:600,lineHeight:1.45,color:C.W,marginTop:4 }}>{a.title}</div>
                    <div style={{ fontSize:10,color:C.MUTED,marginTop:5,fontFamily:"sans-serif" }}>{a.date}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DELHI LOCAL */}
        {delhiArts.length > 0 && (
          <div style={{ marginBottom:22 }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:14 }}>
              <div style={{ borderLeft:`3.5px solid ${pr}`,paddingLeft:12 }}>
                <div style={{ fontSize:18,fontWeight:700,color:C.W,fontFamily:"'Noto Serif Devanagari',serif" }}>📍 दिल्ली की बात</div>
                <div style={{ fontSize:10,color:C.MUTED,marginTop:2,fontFamily:"sans-serif" }}>HYPERLOCAL • हर गली की खबर</div>
              </div>
              <span style={{ fontSize:12,color:ac,cursor:"pointer",fontFamily:"sans-serif" }}>सब देखें →</span>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12 }}>
              {delhiArts.map(a=>(
                <div key={a.id} style={{ background:C.CARD,borderRadius:9,padding:14,border:`1px solid ${C.BORDER}`,cursor:"pointer" }}>
                  <div style={{ display:"flex",justifyContent:"space-between",marginBottom:8 }}>
                    <span style={{ background:pr+"22",color:pr,padding:"2px 9px",borderRadius:4,fontSize:10,fontWeight:600,border:`1px solid ${pr}30` }}>{a.tag}</span>
                    <span style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif" }}>👁 {a.views?.toLocaleString()}</span>
                  </div>
                  <div style={{ fontSize:13,fontWeight:600,lineHeight:1.5,color:C.W }}>{a.title}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:18,marginBottom:22 }}>
          {/* POLITICS */}
          {polArts.length > 0 && (
            <div>
              <div style={{ borderLeft:`3.5px solid #9C27B0`,paddingLeft:12,marginBottom:14 }}>
                <div style={{ fontSize:17,fontWeight:700,color:C.W,fontFamily:"'Noto Serif Devanagari',serif" }}>⚡ राजनीति</div>
              </div>
              {polArts.map(a=>(
                <div key={a.id} style={{ background:C.CARD,borderRadius:8,padding:12,border:`1px solid ${C.BORDER}`,marginBottom:10,cursor:"pointer" }}>
                  <span style={{ background:pr,color:"#fff",padding:"2px 8px",borderRadius:4,fontSize:9.5,fontWeight:700,fontFamily:"sans-serif" }}>{a.tag}</span>
                  <div style={{ fontSize:13,fontWeight:600,lineHeight:1.45,color:C.W,marginTop:6 }}>{a.title}</div>
                  <div style={{ fontSize:10,color:C.MUTED,marginTop:5,fontFamily:"sans-serif" }}>{a.date}</div>
                </div>
              ))}
            </div>
          )}

          {/* BOLE FREE */}
          {bole.length > 0 && (
            <div style={{ background:`linear-gradient(160deg,${pr}0d 0%,${C.CARD} 100%)`,border:`1px solid ${pr}2a`,borderRadius:10,padding:16 }}>
              <div style={{ borderLeft:`3.5px solid ${ac}`,paddingLeft:12,marginBottom:14 }}>
                <div style={{ fontSize:17,fontWeight:700,color:ac,fontFamily:"'Noto Serif Devanagari',serif" }}>📢 बोले फ्री</div>
                <div style={{ fontSize:10,color:C.MUTED,marginTop:2,fontFamily:"sans-serif" }}>CIVIC VOICE PLATFORM</div>
              </div>
              {bole.map((p,i)=>(
                <div key={p.id} style={{ background:C.CARD2,borderRadius:8,padding:12,border:`1px solid ${C.BORDER}`,marginBottom:i<bole.length-1?10:0 }}>
                  <div style={{ display:"flex",justifyContent:"space-between",marginBottom:6 }}>
                    <span style={{ fontSize:12.5,fontWeight:600,color:C.W }}>{p.name}</span>
                    <span style={{ background:pr+"1a",color:pr,padding:"2px 8px",borderRadius:4,fontSize:9.5,fontWeight:600,border:`1px solid ${pr}30`,fontFamily:"sans-serif" }}>{p.issue}</span>
                  </div>
                  <div style={{ fontSize:12.5,color:"#b8b4b0",lineHeight:1.55,marginBottom:8 }}>{p.text}</div>
                  <span style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif" }}>👍 {p.votes} • {p.area}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* REELS */}
        {reels.length > 0 && (
          <div style={{ marginBottom:22 }}>
            <div style={{ borderLeft:`3.5px solid ${C.ORANGE}`,paddingLeft:12,marginBottom:14 }}>
              <div style={{ fontSize:17,fontWeight:700,color:C.W,fontFamily:"'Noto Serif Devanagari',serif" }}>🎬 Reels</div>
            </div>
            <div style={{ display:"flex",gap:12,overflowX:"auto",paddingBottom:8,scrollbarWidth:"none" }}>
              {reels.map(r=>(
                <div key={r.id} style={{ flexShrink:0,width:160,background:C.CARD,borderRadius:10,overflow:"hidden",border:`1px solid ${C.BORDER}`,cursor:"pointer" }}>
                  <div style={{ height:200,background:`linear-gradient(160deg,${C.ORANGE}33,${C.CARD2})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32 }}>🎬</div>
                  <div style={{ padding:"10px 10px 12px" }}>
                    <div style={{ fontSize:12,fontWeight:600,color:C.W,lineHeight:1.4 }}>{r.title}</div>
                    <div style={{ fontSize:10,color:C.MUTED,marginTop:5,fontFamily:"sans-serif" }}>👁 {(r.views/1000).toFixed(0)}K • ❤️ {(r.likes/1000).toFixed(0)}K</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* POLLS */}
        {polls.filter(p=>p.active).length > 0 && pollVotes && (
          <div style={{ marginBottom:22 }}>
            <div style={{ borderLeft:`3.5px solid ${C.TEAL}`,paddingLeft:12,marginBottom:14 }}>
              <div style={{ fontSize:17,fontWeight:700,color:C.W,fontFamily:"'Noto Serif Devanagari',serif" }}>📊 Poll: आपकी राय</div>
            </div>
            {polls.filter(p=>p.active).map(poll=>{
              const pv = pollVotes[poll.id] || poll.votes;
              const total = pv.reduce((s,v)=>s+v,0);
              return (
                <div key={poll.id} style={{ background:C.CARD,border:`1px solid ${C.TEAL}33`,borderRadius:10,padding:18,maxWidth:500 }}>
                  <div style={{ fontSize:14,fontWeight:700,color:C.W,marginBottom:14 }}>{poll.q}</div>
                  {poll.opts.map((opt,i)=>{
                    const pct = total ? Math.round(pv[i]/total*100) : 0;
                    const hasVoted = voted===poll.id;
                    return (
                      <div key={i} onClick={()=>doVotePoll(poll.id,i)} style={{ marginBottom:10,cursor:hasVoted?"default":"pointer" }}>
                        <div style={{ display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:13 }}>
                          <span style={{ color:C.W }}>{opt}</span>
                          {hasVoted && <span style={{ color:C.TEAL,fontFamily:"sans-serif",fontWeight:700 }}>{pct}%</span>}
                        </div>
                        <div style={{ height:6,background:C.BORDER2,borderRadius:3 }}>
                          <div style={{ height:"100%",width:hasVoted?`${pct}%`:"0%",background:C.TEAL,borderRadius:3,transition:"width .5s ease" }}></div>
                        </div>
                      </div>
                    );
                  })}
                  <div style={{ fontSize:11,color:C.MUTED,marginTop:8,fontFamily:"sans-serif" }}>कुल {total.toLocaleString()} वोट {voted===poll.id?"• आपने vote किया ✓":""}</div>
                </div>
              );
            })}
          </div>
        )}

        {/* ALL ARTICLES */}
        {pub.length > 0 && (
          <div>
            <div style={{ borderLeft:`3.5px solid ${ac}`,paddingLeft:12,marginBottom:14 }}>
              <div style={{ fontSize:17,fontWeight:700,color:C.W,fontFamily:"'Noto Serif Devanagari',serif" }}>📰 ताज़ा खबरें</div>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12 }}>
              {pub.map(a=>(
                <div key={a.id} style={{ background:C.CARD,borderRadius:9,padding:14,border:`1px solid ${C.BORDER}`,cursor:"pointer" }}>
                  <Badge text={a.category} color={pr} />
                  <div style={{ fontSize:13,fontWeight:600,lineHeight:1.5,color:C.W,margin:"8px 0 6px" }}>{a.title}</div>
                  <div style={{ fontSize:11,color:C.MUTED,lineHeight:1.5 }}>{a.excerpt}</div>
                  <div style={{ fontSize:10,color:C.MUTED,marginTop:8,fontFamily:"sans-serif" }}>{a.date} • 👁 {a.views?.toLocaleString()}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* FOOTER */}
      <div style={{ background:"#000",borderTop:`2.5px solid ${pr}`,marginTop:32 }}>
        <div style={{ maxWidth:1280,margin:"0 auto",padding:"24px 18px 16px" }}>
          <div style={{ display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:24,marginBottom:20 }}>
            <div>
              <div style={{ fontSize:22,fontWeight:900,color:pr,fontFamily:"'Noto Serif Devanagari',serif" }}>दिल्लीनामा</div>
              <div style={{ fontSize:12,color:C.MUTED,lineHeight:1.65,maxWidth:260,marginTop:10 }}>दिल्ली और देश की हर खबर — जनता की भाषा में। सवाल भी, समाधान भी।</div>
            </div>
            {[
              { h:"मुख्य खबरें", items:["देश","विदेश","राजनीति","दिल्ली","बाजार"] },
              { h:"सेवाएं",      items:["बोले फ्री","Live TV","ई-पेपर","Podcast"] },
              { h:"कंपनी",      items:["हमारे बारे में","संपर्क","विज्ञापन","गोपनीयता"] },
            ].map((col,i)=>(
              <div key={i}>
                <div style={{ fontSize:12,fontWeight:700,color:C.W,marginBottom:12,paddingBottom:8,borderBottom:`1px solid ${C.BORDER}` }}>{col.h}</div>
                {col.items.map(item=><div key={item} style={{ fontSize:12,color:C.MUTED,marginBottom:8,cursor:"pointer" }}>{item}</div>)}
              </div>
            ))}
          </div>
          <div style={{ borderTop:`1px solid ${C.BORDER}`,paddingTop:14,display:"flex",justifyContent:"space-between",fontSize:11,color:C.MUTED,fontFamily:"sans-serif" }}>
            <span>© 2025 Delhinama Media Pvt. Ltd.</span>
            <span style={{ color:pr,fontWeight:700 }}>दिल्ली की असली आवाज़</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   ADMIN PANEL
══════════════════════════════════════════════════════ */
const ADMIN_TABS = [
  { id:"dashboard",  icon:"📊", label:"Dashboard",       color:C.GOLD },
  { id:"articles",   icon:"📰", label:"खबरें",           color:C.R },
  { id:"breaking",   icon:"🔴", label:"Breaking",        color:C.R },
  { id:"bole",       icon:"📢", label:"बोले फ्री",       color:C.ORANGE },
  { id:"reels",      icon:"🎬", label:"Reels",            color:C.ORANGE },
  { id:"polls",      icon:"📊", label:"Polls",            color:C.TEAL },
  { id:"categories", icon:"🏷️", label:"Categories",     color:C.PURPLE },
  { id:"seo",        icon:"🔍", label:"SEO Manager",     color:C.BLUE },
  { id:"ads",        icon:"💰", label:"Ads Manager",     color:C.GOLD },
  { id:"push",       icon:"🔔", label:"Push Alerts",     color:C.GREEN },
  { id:"analytics",  icon:"📈", label:"Analytics",       color:C.BLUE },
  { id:"users",      icon:"👥", label:"Users",            color:C.PURPLE },
  { id:"auditlog",   icon:"📋", label:"Audit Log",       color:C.MUTED },
  { id:"settings",   icon:"⚙️", label:"Settings",       color:C.MUTED },
];

function AdminPanel({ onGoWebsite }) {
  const [screen, setScreen] = useState("boot");
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState("dashboard");
  const [toastS, setToastS] = useState({ msg:"", type:"success" });
  const [collapsed, setCollapsed] = useState(false);

  /* Data state */
  const [articles, setArticlesS] = useState([]);
  const [breaking, setBreakingS] = useState([]);
  const [bole, setBoleS] = useState([]);
  const [cats, setCatsS] = useState(SEED_CATS);
  const [reels, setReelsS] = useState(SEED_REELS);
  const [polls, setPollsS] = useState(SEED_POLLS);
  const [ads, setAdsS] = useState(SEED_ADS);
  const [users, setUsersS] = useState(SEED_USERS);
  const [auditLog, setAuditLog] = useState([]);
  const [theme, setThemeS] = useState(SEED_THEME);

  /* Login state */
  const [lf, setLf] = useState({ u:"", p:"", rem:false });
  const [lerr, setLerr] = useState("");
  const [showP, setShowP] = useState(false);

  /* Forms */
  const [addArtOpen, setAddArtOpen] = useState(false);
  const [newArt, setNewArt] = useState({ title:"", category:"दिल्ली", tag:"ब्रेकिंग", author:"", excerpt:"", status:"published", featured:false, seo_title:"", seo_desc:"" });
  const [newBreak, setNewBreak] = useState("");
  const [addCat, setAddCat] = useState("");
  const [newPoll, setNewPoll] = useState({ q:"", opts:["","","",""], active:true });
  const [addPollOpen, setAddPollOpen] = useState(false);
  const [addAdOpen, setAddAdOpen] = useState(false);
  const [newAd, setNewAd] = useState({ name:"", slot:"Hero Banner", client:"", status:"active" });
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [newUser, setNewUser] = useState({ username:"", password:"", name:"", role:"reporter", active:true });
  const [pushForm, setPushForm] = useState({ title:"", body:"", topic:"all" });
  const [pushSending, setPushSending] = useState(false);
  const [pushHistory, setPushHistory] = useState([]);
  const [artSearch, setArtSearch] = useState("");
  const [artFilter, setArtFilter] = useState("all");
  const [pwForm, setPwForm] = useState({ cur:"", nw:"", cf:"" });
  const [pwErr, setPwErr] = useState("");

  const toast = (msg, type="success") => { setToastS({ msg, type }); setTimeout(()=>setToastS({ msg:"", type:"" }),3000); };

  const addLog = useCallback(async (action) => {
    const entry = { id:Date.now(), user:user?.username||"?", action, time:new Date().toLocaleString("hi-IN").slice(0,16) };
    const updated = [entry, ...auditLog].slice(0,50);
    setAuditLog(updated);
    await dbSet(SK.auditlog, updated);
  }, [user, auditLog]);

  /* Boot */
  useEffect(()=>{
    (async()=>{
      let su = await dbGet(SK.users, null);
      if (!su) { await dbSet(SK.users, SEED_USERS); su = SEED_USERS; }
      setUsersS(su);
      const sess = await dbGet(SK.session, null);
      if (sess?.username) {
        const u = su.find(x=>x.username===sess.username&&x.active);
        if (u) { setUser(u); setScreen("admin"); return; }
      }
      setScreen("login");
    })();
  },[]);

  /* Load shared data */
  const loadData = useCallback(async()=>{
    const [a,b,bl,r,p,ad,lg,th] = await Promise.all([
      dbGet(SK.articles, SEED_ARTICLES),
      dbGet(SK.breaking, SEED_BREAKING),
      dbGet(SK.bole, SEED_BOLE),
      dbGet(SK.reels, SEED_REELS),
      dbGet(SK.polls, SEED_POLLS),
      dbGet(SK.ads, SEED_ADS),
      dbGet(SK.auditlog, []),
      dbGet(SK.theme, SEED_THEME),
    ]);
    setArticlesS(a); setBreakingS(b); setBoleS(bl); setReelsS(r);
    setPollsS(p); setAdsS(ad); setAuditLog(lg); setThemeS(th);
  }, []);

  useEffect(()=>{ if(screen==="admin") loadData(); },[screen, loadData]);

  /* Save helpers */
  const saveArts = async (data) => { setArticlesS(data); await dbSet(SK.articles, data); };
  const saveBreak = async (data) => { setBreakingS(data); await dbSet(SK.breaking, data); };
  const saveBole = async (data) => { setBoleS(data); await dbSet(SK.bole, data); };
  const saveReels = async (data) => { setReelsS(data); await dbSet(SK.reels, data); };
  const savePolls = async (data) => { setPollsS(data); await dbSet(SK.polls, data); };
  const saveAds = async (data) => { setAdsS(data); await dbSet(SK.ads, data); };
  const saveUsers = async (data) => { setUsersS(data); await dbSet(SK.users, data); };
  const saveCats = async (data) => { setCatsS(data); await dbSet(SK.categories, data); };
  const saveTheme = async (data) => { setThemeS(data); await dbSet(SK.theme, data); };

  /* LOGIN */
  const doLogin = async () => {
    setLerr("");
    const all = await dbGet(SK.users, SEED_USERS);
    const u = all.find(x=>x.username===lf.u&&x.password===lf.p&&x.active);
    if (!u) { setLerr("गलत Username या Password"); return; }
    if (lf.rem) await dbSet(SK.session, { username:u.username });
    else await dbSet(SK.session, null);
    setUser(u); setScreen("admin");
    addLog(`Login: ${u.name} (${u.role})`);
  };
  const doLogout = async () => { await dbSet(SK.session, null); setUser(null); setScreen("login"); setTab("dashboard"); };

  /* ─ BOOT ─ */
  if (screen==="boot") return <div style={{ background:C.BG,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",color:C.MUTED,fontFamily:"sans-serif",fontSize:13 }}>Loading...</div>;

  /* ─ LOGIN SCREEN ─ */
  if (screen==="login") return (
    <div style={{ background:C.BG,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",padding:16,fontFamily:"'Noto Sans Devanagari',sans-serif" }}>
      <div style={{ background:C.CARD,border:`1px solid ${C.BORDER2}`,borderRadius:14,padding:"38px 34px",width:"100%",maxWidth:400,animation:"slideUp .4s" }}>
        <div style={{ textAlign:"center",marginBottom:28 }}>
          <div style={{ fontSize:26,fontWeight:900,color:C.R,fontFamily:"serif",marginBottom:4 }}>दिल्लीनामा</div>
          <div style={{ fontSize:9,color:C.GOLD,letterSpacing:4,fontFamily:"sans-serif" }}>ADMIN PANEL</div>
          <div style={{ fontSize:13,color:C.MUTED,marginTop:10,fontFamily:"sans-serif" }}>admin.delhinama.com</div>
        </div>
        <div style={{ marginBottom:14 }}>
          <Lbl t="USERNAME" />
          <input className="inp" value={lf.u} onChange={e=>setLf({...lf,u:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="username डालें" />
        </div>
        <div style={{ marginBottom:14,position:"relative" }}>
          <Lbl t="PASSWORD" />
          <input className="inp" type={showP?"text":"password"} value={lf.p} onChange={e=>setLf({...lf,p:e.target.value})} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="••••••••" />
          <span onClick={()=>setShowP(!showP)} style={{ position:"absolute",right:12,top:30,cursor:"pointer",color:C.MUTED,fontSize:14 }}>{showP?"🙈":"👁"}</span>
        </div>
        <div style={{ display:"flex",alignItems:"center",gap:9,marginBottom:20,cursor:"pointer" }} onClick={()=>setLf({...lf,rem:!lf.rem})}>
          <div style={{ width:18,height:18,borderRadius:4,border:`1.5px solid ${lf.rem?C.R:C.BORDER2}`,background:lf.rem?C.R+"33":"transparent",display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s" }}>
            {lf.rem&&<span style={{ fontSize:11,color:C.R,fontWeight:900 }}>✓</span>}
          </div>
          <span style={{ fontSize:12,color:C.MUTED,fontFamily:"sans-serif" }}>Login याद रखें (browser band हो तो भी)</span>
        </div>
        {lerr&&<div style={{ fontSize:12,color:C.R,marginBottom:14,background:C.R+"15",padding:"8px 12px",borderRadius:6,fontFamily:"sans-serif",textAlign:"center" }}>{lerr}</div>}
        <button className="btn btn-r" style={{ width:"100%",justifyContent:"center",fontSize:14,padding:"11px" }} onClick={doLogin}>लॉगिन करें →</button>
        <div style={{ marginTop:20,background:C.CARD2,borderRadius:8,padding:"12px 14px",border:`1px solid ${C.BORDER}` }}>
          <div style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginBottom:8,fontWeight:700,letterSpacing:.5 }}>DEMO ACCOUNTS</div>
          {SEED_USERS.map(u=>(
            <div key={u.id} onClick={()=>setLf({u:u.username,p:u.password,rem:lf.rem})} style={{ display:"flex",justifyContent:"space-between",padding:"5px 0",cursor:"pointer",borderBottom:`1px solid ${C.BORDER}` }}>
              <span style={{ fontSize:12,color:C.W,fontFamily:"sans-serif" }}>{ROLES[u.role].icon} {u.username}</span>
              <div style={{ display:"flex",gap:8,alignItems:"center" }}>
                <span style={{ fontSize:11,color:C.MUTED,fontFamily:"monospace" }}>{u.password}</span>
                <Badge text={ROLES[u.role].label} color={ROLES[u.role].color} />
              </div>
            </div>
          ))}
          <div style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginTop:6 }}>👆 Click करके auto-fill करें</div>
        </div>
        <div style={{ textAlign:"center",marginTop:16 }}>
          <span onClick={onGoWebsite} style={{ fontSize:12,color:C.MUTED,cursor:"pointer",fontFamily:"sans-serif" }}>← Website पर जाएं</span>
        </div>
      </div>
    </div>
  );

  /* ─ ADMIN MAIN ─ */
  const canDo = (perm) => user?.role==="admin" || ROLES[user?.role]?.perms?.includes(perm);

  /* ── ARTICLES ── */
  const filteredArts = articles.filter(a=>{
    const mq = !artSearch||a.title.includes(artSearch);
    const mf = artFilter==="all"||a.status===artFilter||a.category===artFilter;
    const mo = user?.role==="reporter"?a.createdBy===user.username:true;
    return mq&&mf&&mo;
  });

  return (
    <div style={{ background:C.BG,minHeight:"100vh",display:"flex",fontFamily:"'Noto Sans Devanagari',sans-serif",color:C.W }}>

      {/* SIDEBAR */}
      <div style={{ width:collapsed?58:210,background:C.CARD,borderRight:`1px solid ${C.BORDER}`,display:"flex",flexDirection:"column",flexShrink:0,transition:"width .25s",overflow:"hidden" }}>
        <div style={{ padding:collapsed?"14px 10px":"16px 14px 12px",borderBottom:`1px solid ${C.BORDER}`,display:"flex",alignItems:"center",justifyContent:"space-between" }}>
          {!collapsed&&<div><div style={{ fontSize:17,fontWeight:900,color:C.R,fontFamily:"serif" }}>दिल्लीनामा</div><div style={{ fontSize:7.5,color:C.GOLD,letterSpacing:3,fontFamily:"sans-serif",marginTop:2 }}>ADMIN PANEL</div></div>}
          <button onClick={()=>setCollapsed(!collapsed)} style={{ background:"transparent",border:"none",color:C.MUTED,cursor:"pointer",fontSize:16,padding:2,marginLeft:collapsed?0:"auto" }}>{collapsed?"▶":"◀"}</button>
        </div>
        {/* User pill */}
        {!collapsed&&user&&(
          <div style={{ margin:"10px 8px",background:C.CARD2,borderRadius:8,padding:"9px 11px",border:`1px solid ${C.BORDER2}`,display:"flex",alignItems:"center",gap:9 }}>
            <div style={{ width:30,height:30,borderRadius:"50%",background:ROLES[user.role]?.color+"25",border:`1.5px solid ${ROLES[user.role]?.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0 }}>{ROLES[user.role]?.icon}</div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:12,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{user.name}</div>
              <Badge text={ROLES[user.role]?.label} color={ROLES[user.role]?.color} />
            </div>
          </div>
        )}
        <div style={{ flex:1,padding:"6px 5px",overflowY:"auto" }}>
          {ADMIN_TABS.filter(t=>t.id!=="users"||user?.role==="admin").map(t=>(
            <div key={t.id} onClick={()=>setTab(t.id)} title={collapsed?t.label:""} style={{ display:"flex",alignItems:"center",gap:9,padding:collapsed?"10px":"8px 10px",borderRadius:8,cursor:"pointer",marginBottom:2,background:tab===t.id?t.color+"22":"transparent",borderLeft:tab===t.id?`3px solid ${t.color}`:"3px solid transparent",transition:"all .15s",justifyContent:collapsed?"center":"flex-start" }}>
              <span style={{ fontSize:15,flexShrink:0 }}>{t.icon}</span>
              {!collapsed&&<span style={{ fontSize:12,fontWeight:tab===t.id?700:500,color:tab===t.id?C.W:C.MUTED,whiteSpace:"nowrap" }}>{t.label}</span>}
            </div>
          ))}
        </div>
        <div style={{ padding:"10px 6px",borderTop:`1px solid ${C.BORDER}` }}>
          {!collapsed&&<div onClick={onGoWebsite} style={{ display:"flex",alignItems:"center",gap:9,padding:"8px 10px",borderRadius:8,cursor:"pointer",color:C.MUTED,fontSize:12,marginBottom:4 }}><span>🌐</span><span>Website देखें</span></div>}
          <div onClick={doLogout} title="Logout" style={{ display:"flex",alignItems:"center",gap:9,padding:"8px 10px",borderRadius:8,cursor:"pointer",color:C.MUTED,fontSize:12,justifyContent:collapsed?"center":"flex-start" }}><span>🚪</span>{!collapsed&&<span>Logout</span>}</div>
        </div>
      </div>

      {/* MAIN */}
      <div style={{ flex:1,overflowY:"auto",overflowX:"hidden" }}>
        {/* Topbar */}
        <div style={{ background:C.CARD,borderBottom:`1px solid ${C.BORDER}`,padding:"10px 22px",display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,zIndex:50 }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <span style={{ fontSize:16 }}>{ADMIN_TABS.find(t=>t.id===tab)?.icon}</span>
            <span style={{ fontSize:14,fontWeight:700 }}>{ADMIN_TABS.find(t=>t.id===tab)?.label}</span>
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <div style={{ display:"flex",alignItems:"center",gap:5,fontSize:11,color:C.GREEN,fontFamily:"sans-serif",background:C.GREEN+"15",padding:"4px 10px",borderRadius:6 }}>
              <span style={{ width:6,height:6,borderRadius:"50%",background:C.GREEN,animation:"pulse 2s infinite" }}></span>
              Website Live
            </div>
            <span style={{ fontSize:11,color:C.MUTED,fontFamily:"sans-serif" }}>admin.delhinama.com</span>
          </div>
        </div>

        <div style={{ padding:20 }}>

        {/* ═══ DASHBOARD ═══ */}
        {tab==="dashboard"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
              {[
                { icon:"📰", label:"Published", value:articles.filter(a=>a.status==="published").length, color:C.GOLD },
                { icon:"🔴", label:"Breaking",  value:breaking.length, color:C.R },
                { icon:"📢", label:"Pending",   value:bole.filter(b=>b.status==="pending").length, color:C.ORANGE },
                { icon:"🎬", label:"Reels Live", value:reels.filter(r=>r.status==="published").length, color:C.TEAL },
              ].map(s=>(
                <div key={s.label} style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:"16px 18px" }}>
                  <div style={{ fontSize:22,marginBottom:6 }}>{s.icon}</div>
                  <div style={{ fontSize:26,fontWeight:700,color:s.color,fontFamily:"sans-serif" }}>{s.value}</div>
                  <div style={{ fontSize:12,color:C.W,marginTop:2 }}>{s.label}</div>
                  <div style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginTop:3 }}>Website pe live</div>
                </div>
              ))}
            </div>

            {/* Live indicator */}
            <div style={{ background:`linear-gradient(135deg,${C.GREEN}11,${C.CARD})`,border:`1px solid ${C.GREEN}33`,borderRadius:10,padding:"14px 18px",marginBottom:18,display:"flex",alignItems:"center",gap:14 }}>
              <span style={{ width:12,height:12,borderRadius:"50%",background:C.GREEN,animation:"pulse 1.5s infinite",flexShrink:0 }}></span>
              <div>
                <div style={{ fontSize:13,fontWeight:700,color:C.W }}>Website live sync हो रही है</div>
                <div style={{ fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginTop:2 }}>Admin में कोई भी बदलाव 5 seconds में website पर दिख जाएगा — auto-refresh के जरिये</div>
              </div>
            </div>

            <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:16 }}>
              <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10 }}>
                <div style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,display:"flex",justifyContent:"space-between" }}>
                  <span style={{ fontSize:13,fontWeight:700 }}>ताज़ा खबरें</span>
                  <span onClick={()=>setTab("articles")} style={{ fontSize:12,color:C.GOLD,cursor:"pointer",fontFamily:"sans-serif" }}>सब देखें →</span>
                </div>
                {articles.slice(0,5).map((a,i)=>(
                  <div key={a.id} className="rh" style={{ padding:"10px 16px",borderBottom:i<4?`1px solid ${C.BORDER}`:"none",display:"flex",justifyContent:"space-between",alignItems:"center",transition:"background .15s",cursor:"default" }}>
                    <div style={{ flex:1,minWidth:0 }}>
                      <div style={{ fontSize:13,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:400 }}>{a.title}</div>
                      <div style={{ fontSize:10,color:C.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{a.category} • {a.date}</div>
                    </div>
                    <Badge text={a.status==="published"?"✓ Live":"Draft"} color={a.status==="published"?C.GREEN:C.GOLD} />
                  </div>
                ))}
              </div>
              <div>
                {bole.filter(b=>b.status==="pending").length>0&&(
                  <div style={{ background:C.CARD,border:`1px solid ${C.ORANGE}33`,borderRadius:10,marginBottom:12 }}>
                    <div style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,display:"flex",justifyContent:"space-between" }}>
                      <span style={{ fontSize:13,fontWeight:700,color:C.ORANGE }}>Pending बोले फ्री</span>
                      <span onClick={()=>setTab("bole")} style={{ fontSize:12,color:C.GOLD,cursor:"pointer",fontFamily:"sans-serif" }}>देखें →</span>
                    </div>
                    {bole.filter(b=>b.status==="pending").slice(0,3).map(p=>(
                      <div key={p.id} style={{ padding:"10px 16px",borderBottom:`1px solid ${C.BORDER}` }}>
                        <div style={{ fontSize:12,fontWeight:600 }}>{p.name} — {p.issue}</div>
                        <div style={{ display:"flex",gap:8,marginTop:8 }}>
                          <button className="btn btn-g" style={{ fontSize:10,padding:"3px 10px" }} onClick={async()=>{ const d=bole.map(b=>b.id===p.id?{...b,status:"approved"}:b); await saveBole(d); toast("Approved ✓"); addLog(`Approved बोले फ्री: ${p.name}`); }}>✓</button>
                          <button className="btn btn-r" style={{ fontSize:10,padding:"3px 10px" }} onClick={async()=>{ const d=bole.map(b=>b.id===p.id?{...b,status:"rejected"}:b); await saveBole(d); toast("Rejected","warn"); }}>✗</button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:14 }}>
                  <div style={{ fontSize:12,fontWeight:700,marginBottom:12 }}>🚀 Quick Actions</div>
                  {[
                    { label:"+ नई खबर", action:()=>{ setTab("articles"); setAddArtOpen(true); }, color:C.R },
                    { label:"+ Breaking", action:()=>setTab("breaking"), color:C.ORANGE },
                    { label:"📢 Push भेजें", action:()=>setTab("push"), color:C.GREEN },
                    { label:"🎨 Theme", action:()=>setTab("settings"), color:C.PURPLE },
                  ].map(a=>(
                    <button key={a.label} onClick={a.action} className="btn" style={{ width:"100%",justifyContent:"center",marginBottom:8,background:a.color+"22",color:a.color,border:`1px solid ${a.color}33`,fontSize:12 }}>{a.label}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ═══ ARTICLES ═══ */}
        {tab==="articles"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"flex",gap:10,marginBottom:16,flexWrap:"wrap",alignItems:"center" }}>
              <button className="btn btn-r" onClick={()=>setAddArtOpen(!addArtOpen)}>{addArtOpen?"✕ बंद":"+ नई खबर"}</button>
              <input className="inp" value={artSearch} onChange={e=>setArtSearch(e.target.value)} placeholder="खोजें..." style={{ maxWidth:200 }} />
              <select className="inp" value={artFilter} onChange={e=>setArtFilter(e.target.value)} style={{ maxWidth:160 }}>
                <option value="all">सभी</option><option value="published">Published</option><option value="draft">Draft</option>
                {cats.slice(0,6).map(c=><option key={c} value={c}>{c}</option>)}
              </select>
              <span style={{ fontSize:11,color:C.MUTED,fontFamily:"sans-serif",marginLeft:"auto" }}>{filteredArts.length} articles</span>
            </div>

            {addArtOpen&&(
              <div style={{ background:C.CARD,border:`1px solid ${C.GOLD}44`,borderRadius:10,padding:18,marginBottom:16,animation:"slideUp .25s" }}>
                <SHead icon="+" label="नई खबर जोड़ें" color={C.GOLD} />
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                  <div style={{ gridColumn:"1/-1" }}><Lbl t="TITLE *" /><input className="inp" value={newArt.title} onChange={e=>setNewArt({...newArt,title:e.target.value})} placeholder="खबर का शीर्षक..." /></div>
                  <div><Lbl t="CATEGORY" /><select className="inp" value={newArt.category} onChange={e=>setNewArt({...newArt,category:e.target.value})}>{cats.map(c=><option key={c}>{c}</option>)}</select></div>
                  <div><Lbl t="TAG" /><select className="inp" value={newArt.tag} onChange={e=>setNewArt({...newArt,tag:e.target.value})}>{ALL_TAGS.map(t=><option key={t}>{t}</option>)}</select></div>
                  <div><Lbl t="AUTHOR *" /><input className="inp" value={newArt.author} onChange={e=>setNewArt({...newArt,author:e.target.value})} placeholder="लेखक का नाम" /></div>
                  <div><Lbl t="STATUS" /><select className="inp" value={newArt.status} onChange={e=>setNewArt({...newArt,status:e.target.value})}><option value="published">✓ Published (Live)</option><option value="draft">Draft</option></select></div>
                  <div style={{ gridColumn:"1/-1" }}><Lbl t="EXCERPT" /><textarea className="inp" value={newArt.excerpt} onChange={e=>setNewArt({...newArt,excerpt:e.target.value})} placeholder="खबर का सारांश..." /></div>
                  <div style={{ gridColumn:"1/-1",display:"flex",alignItems:"center",gap:10 }}>
                    <Toggle val={newArt.featured} onChange={v=>setNewArt({...newArt,featured:v})} color={C.GOLD} />
                    <span style={{ fontSize:13,color:C.W }}>Homepage Hero पर Feature करें</span>
                  </div>
                  <div><Lbl t="SEO TITLE" /><input className="inp" value={newArt.seo_title} onChange={e=>setNewArt({...newArt,seo_title:e.target.value})} placeholder="Google के लिए title..." /></div>
                  <div><Lbl t="SEO DESCRIPTION" /><input className="inp" value={newArt.seo_desc} onChange={e=>setNewArt({...newArt,seo_desc:e.target.value})} placeholder="Meta description..." /></div>
                </div>
                <div style={{ display:"flex",gap:10,marginTop:14 }}>
                  <button className="btn btn-r" onClick={async()=>{ if(!newArt.title||!newArt.author){toast("Title और Author जरूरी है","error");return;} const a={...newArt,id:Date.now(),date:new Date().toISOString().slice(0,10),views:0,createdBy:user.username}; const d=[a,...articles]; await saveArts(d); setNewArt({title:"",category:"दिल्ली",tag:"ब्रेकिंग",author:"",excerpt:"",status:"published",featured:false,seo_title:"",seo_desc:""}); setAddArtOpen(false); toast("खबर website पर live हो गई! 🎉"); addLog(`Article add: "${a.title}"`); }}>✓ Publish करें</button>
                  <button className="btn btn-ghost" onClick={()=>setAddArtOpen(false)}>रद्द</button>
                </div>
              </div>
            )}

            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              {filteredArts.map((a,i)=>(
                <div key={a.id} className="rh" style={{ padding:"11px 16px",borderBottom:i<filteredArts.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:10,transition:"background .15s",cursor:"default" }}>
                  <div style={{ flex:1,minWidth:0 }}>
                    <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                      <div style={{ fontSize:13,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:380 }}>{a.title}</div>
                      {a.featured&&<span style={{ fontSize:9,color:C.GOLD,background:C.GOLD+"22",padding:"1px 6px",borderRadius:3,whiteSpace:"nowrap",fontFamily:"sans-serif" }}>★ Hero</span>}
                    </div>
                    <div style={{ fontSize:10,color:C.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{a.category} • {a.tag} • {a.date} • by {a.author}</div>
                  </div>
                  <button onClick={async()=>{ const d=articles.map(x=>x.id===a.id?{...x,status:x.status==="published"?"draft":"published"}:x); await saveArts(d); toast(`Status: ${a.status==="published"?"Draft":"Live"}`); addLog(`Status change: "${a.title}" → ${a.status==="published"?"draft":"published"}`); }} style={{ fontSize:10,fontWeight:700,padding:"4px 10px",borderRadius:4,cursor:"pointer",border:"none",background:a.status==="published"?C.GREEN+"33":C.GOLD+"22",color:a.status==="published"?"#5EC878":C.GOLD,fontFamily:"sans-serif",whiteSpace:"nowrap" }}>
                    {a.status==="published"?"✓ Live":"Draft"}
                  </button>
                  <button onClick={async()=>{ const d=articles.filter(x=>x.id!==a.id); await saveArts(d); toast("Article हटाया गया","error"); addLog(`Deleted: "${a.title}"`); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.MUTED,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑</button>
                </div>
              ))}
              {!filteredArts.length&&<div style={{ padding:28,textAlign:"center",color:C.MUTED,fontSize:13 }}>कोई खबर नहीं मिली</div>}
            </div>
          </div>
        )}

        {/* ═══ BREAKING ═══ */}
        {tab==="breaking"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:16,marginBottom:16 }}>
              <Lbl t="नई BREAKING NEWS" />
              <div style={{ display:"flex",gap:10 }}>
                <input className="inp" value={newBreak} onChange={e=>setNewBreak(e.target.value)} onKeyDown={e=>e.key==="Enter"&&newBreak.trim()&&(async()=>{ const d=[{id:Date.now(),text:newBreak.trim()},...breaking]; await saveBreak(d); setNewBreak(""); toast("Breaking live! Website ticker पर दिखेगी 🔴"); addLog(`Breaking add: "${newBreak}"`); })()} placeholder="Breaking news text लिखें..." />
                <button className="btn btn-r" onClick={async()=>{ if(!newBreak.trim())return; const d=[{id:Date.now(),text:newBreak.trim()},...breaking]; await saveBreak(d); setNewBreak(""); toast("Breaking website पर live! 🔴"); addLog(`Breaking: "${newBreak}"`); }}>+ Add</button>
              </div>
            </div>
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              <div style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,fontSize:13,fontWeight:700 }}>Active Tickers ({breaking.length})</div>
              {breaking.map((b,i)=>(
                <div key={b.id} className="rh" style={{ padding:"12px 16px",borderBottom:i<breaking.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:12 }}>
                  <span style={{ width:7,height:7,borderRadius:"50%",background:C.R,flexShrink:0 }}></span>
                  <span style={{ flex:1,fontSize:13 }}>{b.text}</span>
                  <button onClick={async()=>{ const d=breaking.filter(x=>x.id!==b.id); await saveBreak(d); toast("Breaking हटाई","error"); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"3px 10px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑 हटाएं</button>
                </div>
              ))}
              {!breaking.length&&<div style={{ padding:24,textAlign:"center",color:C.MUTED,fontSize:13 }}>कोई Breaking News नहीं</div>}
            </div>
          </div>
        )}

        {/* ═══ BOLE FREE ═══ */}
        {tab==="bole"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"flex",gap:12,marginBottom:16 }}>
              {["pending","approved","rejected"].map(s=>(
                <div key={s} style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:8,padding:"10px 18px",textAlign:"center",minWidth:100 }}>
                  <div style={{ fontSize:22,fontWeight:700,color:s==="pending"?C.ORANGE:s==="approved"?C.GREEN:C.R,fontFamily:"sans-serif" }}>{bole.filter(b=>b.status===s).length}</div>
                  <div style={{ fontSize:11,color:C.MUTED,marginTop:2,fontFamily:"sans-serif",textTransform:"capitalize" }}>{s}</div>
                </div>
              ))}
            </div>
            {bole.map(p=>(
              <div key={p.id} style={{ background:C.CARD,border:`1px solid ${p.status==="pending"?C.ORANGE+"33":C.BORDER}`,borderRadius:10,padding:16,marginBottom:12 }}>
                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8 }}>
                  <div>
                    <span style={{ fontSize:13,fontWeight:700 }}>{p.name}</span>
                    <span style={{ fontSize:11,color:C.MUTED,marginLeft:10,fontFamily:"sans-serif" }}>{p.area} • {p.date}</span>
                    <Badge text={p.issue} color={C.R} />
                  </div>
                  <Badge text={p.status==="approved"?"✓ Live":p.status==="rejected"?"✗ Rejected":"⏳ Pending"} color={p.status==="approved"?C.GREEN:p.status==="rejected"?C.R:C.ORANGE} />
                </div>
                <div style={{ fontSize:13,color:"#b5b1ac",lineHeight:1.6,marginBottom:10 }}>{p.text}</div>
                <div style={{ display:"flex",gap:8,alignItems:"center" }}>
                  <span style={{ fontSize:11,color:C.MUTED,fontFamily:"sans-serif",flex:1 }}>👍 {p.votes}</span>
                  {p.status!=="approved"&&<button className="btn btn-g" style={{ fontSize:10,padding:"4px 12px" }} onClick={async()=>{ const d=bole.map(b=>b.id===p.id?{...b,status:"approved"}:b); await saveBole(d); toast("Website पर Show होगी ✓"); addLog(`Approved: ${p.name} - ${p.issue}`); }}>✓ Website पर Show करें</button>}
                  {p.status!=="rejected"&&<button className="btn btn-ghost" style={{ fontSize:10,padding:"4px 12px",color:C.ORANGE,borderColor:C.ORANGE+"44" }} onClick={async()=>{ const d=bole.map(b=>b.id===p.id?{...b,status:"rejected"}:b); await saveBole(d); toast("Rejected","warn"); }}>✗ Reject</button>}
                  <button onClick={async()=>{ const d=bole.filter(b=>b.id!==p.id); await saveBole(d); toast("हटाया गया","error"); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ═══ REELS ═══ */}
        {tab==="reels"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14 }}>
              {reels.map(r=>(
                <div key={r.id} style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,display:"flex",gap:14,padding:14 }}>
                  <div style={{ width:64,height:96,borderRadius:8,background:`linear-gradient(160deg,${C.ORANGE}33,${C.CARD2})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0 }}>🎬</div>
                  <div style={{ flex:1 }}>
                    <Badge text={r.category} color={C.ORANGE} />
                    <div style={{ fontSize:13,fontWeight:600,marginTop:6,lineHeight:1.4 }}>{r.title}</div>
                    <div style={{ fontSize:11,color:C.MUTED,marginTop:5,fontFamily:"sans-serif" }}>👁 {r.views?.toLocaleString()} • ❤️ {r.likes?.toLocaleString()}</div>
                    <div style={{ display:"flex",gap:8,marginTop:10 }}>
                      <button onClick={async()=>{ const d=reels.map(x=>x.id===r.id?{...x,status:x.status==="published"?"draft":"published"}:x); await saveReels(d); toast("Reel status changed"); }} style={{ fontSize:10,fontWeight:700,padding:"3px 10px",borderRadius:4,cursor:"pointer",border:"none",background:r.status==="published"?C.GREEN+"33":C.GOLD+"22",color:r.status==="published"?"#5EC878":C.GOLD,fontFamily:"sans-serif" }}>
                        {r.status==="published"?"✓ Live":"Draft"}
                      </button>
                      <button onClick={async()=>{ const d=reels.filter(x=>x.id!==r.id); await saveReels(d); toast("Reel deleted","error"); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"3px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ POLLS ═══ */}
        {tab==="polls"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <button className="btn btn-b" style={{ marginBottom:16 }} onClick={()=>setAddPollOpen(!addPollOpen)}>+ नया Poll</button>
            {addPollOpen&&(
              <div style={{ background:C.CARD,border:`1px solid ${C.BLUE}44`,borderRadius:10,padding:18,marginBottom:16,animation:"slideUp .25s" }}>
                <Lbl t="POLL QUESTION" />
                <input className="inp" value={newPoll.q} onChange={e=>setNewPoll({...newPoll,q:e.target.value})} placeholder="पाठकों से क्या पूछना है?" style={{ marginBottom:12 }} />
                <Lbl t="OPTIONS (4)" />
                {newPoll.opts.map((o,i)=>(
                  <input key={i} className="inp" value={o} onChange={e=>{ const opts=[...newPoll.opts]; opts[i]=e.target.value; setNewPoll({...newPoll,opts}); }} placeholder={`Option ${i+1}...`} style={{ marginBottom:8 }} />
                ))}
                <div style={{ display:"flex",gap:8,marginTop:8 }}>
                  <button className="btn btn-b" onClick={async()=>{ if(!newPoll.q||newPoll.opts.filter(o=>o).length<2){toast("Question और कम से कम 2 options जरूरी","error");return;} const p={...newPoll,id:Date.now(),votes:newPoll.opts.map(()=>0)}; const d=[...polls,p]; await savePolls(d); setNewPoll({q:"",opts:["","","",""],active:true}); setAddPollOpen(false); toast("Poll live!"); addLog(`Poll created: "${p.q}"`); }}>✓ Publish Poll</button>
                  <button className="btn btn-ghost" onClick={()=>setAddPollOpen(false)}>Cancel</button>
                </div>
              </div>
            )}
            {polls.map(p=>(
              <div key={p.id} style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:16,marginBottom:12 }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:12 }}>
                  <div style={{ fontSize:14,fontWeight:700 }}>{p.q}</div>
                  <div style={{ display:"flex",gap:10,alignItems:"center" }}>
                    <Toggle val={p.active} onChange={async v=>{ const d=polls.map(x=>x.id===p.id?{...x,active:v}:x); await savePolls(d); toast(v?"Poll Live":"Poll Paused"); }} color={C.TEAL} />
                    <button onClick={async()=>{ const d=polls.filter(x=>x.id!==p.id); await savePolls(d); toast("Poll deleted","error"); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑</button>
                  </div>
                </div>
                {p.opts.map((o,i)=>{ const total=p.votes.reduce((s,v)=>s+v,0); const pct=total?Math.round(p.votes[i]/total*100):0; return (
                  <div key={i} style={{ marginBottom:8 }}>
                    <div style={{ display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:12 }}>
                      <span style={{ color:C.W }}>{o}</span>
                      <span style={{ color:C.MUTED,fontFamily:"sans-serif" }}>{p.votes[i]} ({pct}%)</span>
                    </div>
                    <div style={{ height:5,background:C.BORDER2,borderRadius:3 }}>
                      <div style={{ height:"100%",width:`${pct}%`,background:C.TEAL,borderRadius:3 }}></div>
                    </div>
                  </div>
                );})}
                <div style={{ fontSize:11,color:C.MUTED,marginTop:8,fontFamily:"sans-serif" }}>Total: {p.votes.reduce((s,v)=>s+v,0)} votes • {p.active?"🟢 Active":"⏸ Paused"}</div>
              </div>
            ))}
          </div>
        )}

        {/* ═══ CATEGORIES ═══ */}
        {tab==="categories"&&(
          <div style={{ animation:"fadeIn .3s",maxWidth:600 }}>
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:16,marginBottom:16 }}>
              <Lbl t="नई CATEGORY जोड़ें" />
              <div style={{ display:"flex",gap:10 }}>
                <input className="inp" value={addCat} onChange={e=>setAddCat(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addCat.trim()&&(async()=>{ const d=[...cats,addCat.trim()]; await saveCats(d); setAddCat(""); toast("Category added!"); })()} placeholder="Category का नाम..." />
                <button className="btn btn-p" onClick={async()=>{ if(!addCat.trim())return; const d=[...cats,addCat.trim()]; await saveCats(d); setAddCat(""); toast("Category website पर add हो गई!"); addLog(`Category add: "${addCat}"`); }}>+ Add</button>
              </div>
            </div>
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              <div style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,fontSize:13,fontWeight:700 }}>All Categories ({cats.length})</div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:0 }}>
                {cats.map((cat,i)=>(
                  <div key={i} className="rh" style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,borderRight:i%3!==2?`1px solid ${C.BORDER}`:"none",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                    <span style={{ fontSize:13,color:C.W }}>{cat}</span>
                    <button onClick={async()=>{ const d=cats.filter(c=>c!==cat); await saveCats(d); toast(`"${cat}" हटाई`,"warn"); }} style={{ background:"transparent",border:"none",color:C.R,cursor:"pointer",fontSize:14 }}>✕</button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ SEO MANAGER ═══ */}
        {tab==="seo"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <SHead icon="🔍" label="SEO Manager" color={C.BLUE} sub="Har article ka meta title, description aur featured image manage karein" />
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              <div style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,display:"grid",gridTemplateColumns:"2fr 1fr 1fr",fontSize:10,color:C.MUTED,fontFamily:"sans-serif",fontWeight:700,letterSpacing:.5 }}>
                <span>ARTICLE</span><span>SEO TITLE</span><span>STATUS</span>
              </div>
              {articles.filter(a=>a.status==="published").map((a,i)=>(
                <div key={a.id} className="rh" style={{ padding:"12px 16px",borderBottom:i<articles.length-1?`1px solid ${C.BORDER}`:"none",display:"grid",gridTemplateColumns:"2fr 1fr 1fr",alignItems:"center",gap:12 }}>
                  <div>
                    <div style={{ fontSize:12,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{a.title}</div>
                    <div style={{ fontSize:10,color:C.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{a.category} • {a.date}</div>
                  </div>
                  <div style={{ fontSize:11,color:a.seo_title?C.W:C.MUTED,fontFamily:"sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>
                    {a.seo_title||"(title से auto)"}
                  </div>
                  <div>
                    <Badge text={a.seo_title&&a.seo_desc?"✓ Optimized":"⚠ Missing"} color={a.seo_title&&a.seo_desc?C.GREEN:C.ORANGE} />
                  </div>
                </div>
              ))}
            </div>
            <div style={{ background:C.BLUE+"11",border:`1px solid ${C.BLUE}33`,borderRadius:8,padding:14,marginTop:16,fontSize:12,color:C.MUTED,fontFamily:"sans-serif",lineHeight:1.8 }}>
              💡 <b style={{ color:C.W }}>Tip:</b> Article add करते समय SEO title और description भरें। यह Google search में दिखता है। अगर खाली छोड़ा तो article का title और excerpt use होगा।
            </div>
          </div>
        )}

        {/* ═══ ADS ═══ */}
        {tab==="ads"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"flex",gap:10,marginBottom:16 }}>
              <button className="btn btn-ghost" style={{ color:C.GOLD,borderColor:C.GOLD+"44" }} onClick={()=>setAddAdOpen(!addAdOpen)}>+ New Campaign</button>
            </div>
            {addAdOpen&&(
              <div style={{ background:C.CARD,border:`1px solid ${C.GOLD}44`,borderRadius:10,padding:18,marginBottom:16,animation:"slideUp .25s" }}>
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                  <div><Lbl t="CAMPAIGN NAME" /><input className="inp" value={newAd.name} onChange={e=>setNewAd({...newAd,name:e.target.value})} placeholder="Campaign name" /></div>
                  <div><Lbl t="CLIENT" /><input className="inp" value={newAd.client} onChange={e=>setNewAd({...newAd,client:e.target.value})} placeholder="Client" /></div>
                  <div><Lbl t="SLOT" /><select className="inp" value={newAd.slot} onChange={e=>setNewAd({...newAd,slot:e.target.value})}>
                    {["Hero Banner","Sidebar","In-Article","Footer","Breaking Bar","Video Pre-roll"].map(s=><option key={s}>{s}</option>)}
                  </select></div>
                  <div><Lbl t="STATUS" /><select className="inp" value={newAd.status} onChange={e=>setNewAd({...newAd,status:e.target.value})}><option value="active">Active</option><option value="paused">Paused</option></select></div>
                </div>
                <div style={{ display:"flex",gap:8,marginTop:12 }}>
                  <button className="btn btn-gold" onClick={async()=>{ if(!newAd.name||!newAd.client){toast("Name और Client जरूरी","error");return;} const d=[...ads,{...newAd,id:Date.now(),impressions:0,clicks:0,rev:0}]; await saveAds(d); setNewAd({name:"",slot:"Hero Banner",client:"",status:"active"}); setAddAdOpen(false); toast("Campaign शुरू!"); }}>✓ Start Campaign</button>
                  <button className="btn btn-ghost" onClick={()=>setAddAdOpen(false)}>Cancel</button>
                </div>
              </div>
            )}
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              {ads.map((a,i)=>(
                <div key={a.id} className="rh" style={{ padding:"13px 16px",borderBottom:i<ads.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:12 }}>
                  <div style={{ flex:1,minWidth:0 }}>
                    <div style={{ fontSize:13,fontWeight:600 }}>{a.name}</div>
                    <div style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginTop:2 }}>{a.client} • {a.slot}</div>
                  </div>
                  <div style={{ textAlign:"right",minWidth:70 }}>
                    <div style={{ fontSize:12,fontWeight:700,color:C.GOLD,fontFamily:"sans-serif" }}>₹{a.rev?.toLocaleString()}</div>
                    <div style={{ fontSize:9,color:C.MUTED,fontFamily:"sans-serif" }}>Revenue</div>
                  </div>
                  <button onClick={async()=>{ const d=ads.map(x=>x.id===a.id?{...x,status:x.status==="active"?"paused":"active"}:x); await saveAds(d); toast("Status changed"); }} style={{ fontSize:10,padding:"4px 10px",borderRadius:5,cursor:"pointer",border:"none",background:a.status==="active"?C.GREEN+"22":C.GOLD+"22",color:a.status==="active"?C.GREEN:C.GOLD,fontFamily:"sans-serif",fontWeight:700 }}>
                    {a.status==="active"?"● Active":"⏸ Paused"}
                  </button>
                  <button onClick={async()=>{ const d=ads.filter(x=>x.id!==a.id); await saveAds(d); toast("Campaign deleted","error"); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ PUSH ═══ */}
        {tab==="push"&&(
          <div style={{ animation:"fadeIn .3s",maxWidth:640 }}>
            <SHead icon="🔔" label="Push Notifications" color={C.GREEN} />
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18,marginBottom:16 }}>
              <div style={{ marginBottom:14 }}>
                <Lbl t="TOPIC" />
                <select className="inp" value={pushForm.topic} onChange={e=>setPushForm({...pushForm,topic:e.target.value})}>
                  {[{v:"all",l:"🌐 All (3,24,000)"},{v:"breaking",l:"🚨 Breaking (2,84,000)"},{v:"delhi",l:"📍 Delhi (1,42,000)"},{v:"politics",l:"⚡ Politics (98,000)"}].map(t=><option key={t.v} value={t.v}>{t.l}</option>)}
                </select>
              </div>
              <div style={{ marginBottom:12 }}>
                <Lbl t="TITLE (max 80 chars)" />
                <input className="inp" value={pushForm.title} onChange={e=>{ if(e.target.value.length<=80) setPushForm({...pushForm,title:e.target.value}); }} placeholder="🚨 ब्रेकिंग: headline..." />
              </div>
              <div style={{ marginBottom:16 }}>
                <Lbl t="BODY" />
                <textarea className="inp" value={pushForm.body} onChange={e=>setPushForm({...pushForm,body:e.target.value})} placeholder="Notification विवरण..." rows={3} />
              </div>
              {(pushForm.title||pushForm.body)&&(
                <div style={{ background:C.CARD2,border:`1px solid ${C.BORDER2}`,borderRadius:8,padding:12,marginBottom:14 }}>
                  <div style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginBottom:8 }}>📱 Preview</div>
                  <div style={{ display:"flex",gap:10 }}>
                    <div style={{ width:34,height:34,borderRadius:8,background:C.R,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>📰</div>
                    <div>
                      <div style={{ fontSize:12,fontWeight:700 }}>{pushForm.title}</div>
                      <div style={{ fontSize:11,color:C.MUTED,marginTop:2,lineHeight:1.4 }}>{pushForm.body.slice(0,80)}</div>
                    </div>
                  </div>
                </div>
              )}
              <button className="btn btn-g" disabled={pushSending||!pushForm.title||!pushForm.body} onClick={async()=>{
                setPushSending(true);
                await new Promise(r=>setTimeout(r,1500));
                const h={id:Date.now(),title:pushForm.title,body:pushForm.body,topic:pushForm.topic,sent:324000,opened:71000,ctr:"21.9%",time:new Date().toLocaleTimeString("hi-IN")};
                setPushHistory(ph=>[h,...ph]);
                setPushForm({title:"",body:"",topic:"all"});
                setPushSending(false);
                toast("Push notification भेज दी गई! 🔔");
                addLog(`Push sent: "${h.title}" → ${h.topic}`);
              }}>
                {pushSending?<><Spin/> भेजी जा रही है...</>:"🔔 Send Notification"}
              </button>
            </div>
            {pushHistory.length>0&&(
              <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
                <div style={{ padding:"12px 16px",borderBottom:`1px solid ${C.BORDER}`,fontSize:13,fontWeight:700 }}>Sent History</div>
                {pushHistory.map((h,i)=>(
                  <div key={h.id} style={{ padding:"11px 16px",borderBottom:i<pushHistory.length-1?`1px solid ${C.BORDER}`:"none" }}>
                    <div style={{ fontSize:12,fontWeight:600 }}>{h.title}</div>
                    <div style={{ fontSize:11,color:C.MUTED,marginTop:3,fontFamily:"sans-serif" }}>Sent: {(h.sent/1000).toFixed(0)}K • Opened: {(h.opened/1000).toFixed(0)}K • CTR: {h.ctr} • {h.time}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ═══ ANALYTICS ═══ */}
        {tab==="analytics"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
              {[
                { icon:"👁", label:"Views (7d)", value:"1,58,600", color:C.W },
                { icon:"👤", label:"Users",      value:"36,000",  color:C.TEAL },
                { icon:"⏱",  label:"Avg Time",  value:"2m 54s",  color:C.GOLD },
                { icon:"📱", label:"Mobile",     value:"72%",     color:C.BLUE },
              ].map(s=>(
                <div key={s.label} style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:"16px 18px" }}>
                  <div style={{ fontSize:22,marginBottom:6 }}>{s.icon}</div>
                  <div style={{ fontSize:24,fontWeight:700,color:s.color,fontFamily:"sans-serif" }}>{s.value}</div>
                  <div style={{ fontSize:12,color:C.W,marginTop:2 }}>{s.label}</div>
                </div>
              ))}
            </div>
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18,marginBottom:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📈 Weekly Traffic</div>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={[{d:"Mon",v:14200,u:3200},{d:"Tue",v:18900,u:4100},{d:"Wed",v:22400,u:5600},{d:"Thu",v:19800,u:4400},{d:"Fri",v:27600,u:6200},{d:"Sat",v:31200,u:7100},{d:"Sun",v:24500,u:5400}]}>
                  <defs>
                    <linearGradient id="vg2" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={C.BLUE} stopOpacity={.3}/><stop offset="95%" stopColor={C.BLUE} stopOpacity={0}/></linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.BORDER} />
                  <XAxis dataKey="d" tick={{ fill:C.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill:C.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background:C.CARD2,border:`1px solid ${C.BORDER2}`,borderRadius:6,fontSize:11 }} />
                  <Area type="monotone" dataKey="v" stroke={C.BLUE} fill="url(#vg2)" strokeWidth={2} name="Views" />
                  <Line type="monotone" dataKey="u" stroke={C.TEAL} strokeWidth={2} dot={false} name="Users" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:16 }}>
              <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18 }}>
                <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>🏆 Top Articles</div>
                {[...articles].sort((a,b)=>(b.views||0)-(a.views||0)).slice(0,5).map((a,i)=>(
                  <div key={a.id} style={{ display:"flex",gap:10,marginBottom:10,alignItems:"flex-start" }}>
                    <span style={{ fontSize:16,fontWeight:900,color:i===0?C.GOLD:C.MUTED,fontFamily:"sans-serif",minWidth:20 }}>{i+1}</span>
                    <div>
                      <div style={{ fontSize:12,fontWeight:600,lineHeight:1.4,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical" }}>{a.title}</div>
                      <div style={{ fontSize:10,color:C.TEAL,marginTop:2,fontFamily:"sans-serif" }}>👁 {a.views?.toLocaleString()}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18 }}>
                <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📊 Category Split</div>
                {[...new Set(articles.map(a=>a.category))].slice(0,6).map(cat=>{
                  const count=articles.filter(a=>a.category===cat).length;
                  const pct=articles.length?Math.round(count/articles.length*100):0;
                  return (
                    <div key={cat} style={{ marginBottom:10 }}>
                      <div style={{ display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:12 }}>
                        <span>{cat}</span><span style={{ color:C.MUTED,fontFamily:"sans-serif" }}>{count}</span>
                      </div>
                      <div style={{ height:5,background:C.BORDER2,borderRadius:3 }}>
                        <div style={{ height:"100%",width:`${pct}%`,background:C.R,borderRadius:3 }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ═══ USERS (admin only) ═══ */}
        {tab==="users"&&user?.role==="admin"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <button className="btn btn-b" style={{ marginBottom:16 }} onClick={()=>setAddUserOpen(!addUserOpen)}>+ नया User</button>
            {addUserOpen&&(
              <div style={{ background:C.CARD,border:`1px solid ${C.BLUE}44`,borderRadius:10,padding:18,marginBottom:16,animation:"slideUp .25s" }}>
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                  <div><Lbl t="FULL NAME" /><input className="inp" value={newUser.name} onChange={e=>setNewUser({...newUser,name:e.target.value})} placeholder="पूरा नाम" /></div>
                  <div><Lbl t="USERNAME" /><input className="inp" value={newUser.username} onChange={e=>setNewUser({...newUser,username:e.target.value})} placeholder="login username" /></div>
                  <div><Lbl t="PASSWORD" /><input type="password" className="inp" value={newUser.password} onChange={e=>setNewUser({...newUser,password:e.target.value})} placeholder="min 6 chars" /></div>
                  <div><Lbl t="ROLE" /><select className="inp" value={newUser.role} onChange={e=>setNewUser({...newUser,role:e.target.value})}>
                    {Object.entries(ROLES).map(([k,v])=><option key={k} value={k}>{v.icon} {v.label}</option>)}
                  </select></div>
                </div>
                <div style={{ display:"flex",gap:8,marginTop:12 }}>
                  <button className="btn btn-b" onClick={async()=>{ if(!newUser.name||!newUser.username||newUser.password.length<6){toast("सभी fields जरूरी (password 6+ chars)","error");return;} if(users.find(u=>u.username===newUser.username)){toast("Username पहले से है","error");return;} const d=[...users,{...newUser,id:Date.now()}]; await saveUsers(d); setNewUser({username:"",password:"",name:"",role:"reporter",active:true}); setAddUserOpen(false); toast("User जोड़ा!"); addLog(`User add: ${newUser.username} (${newUser.role})`); }}>✓ Add</button>
                  <button className="btn btn-ghost" onClick={()=>setAddUserOpen(false)}>Cancel</button>
                </div>
              </div>
            )}
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              {users.map((u,i)=>(
                <div key={u.id} className="rh" style={{ padding:"12px 16px",borderBottom:i<users.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:12 }}>
                  <div style={{ width:32,height:32,borderRadius:"50%",background:ROLES[u.role]?.color+"25",border:`1.5px solid ${ROLES[u.role]?.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0 }}>{ROLES[u.role]?.icon}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13,fontWeight:600 }}>{u.name}{u.id===user.id&&<span style={{ fontSize:10,color:C.GOLD,marginLeft:8,fontFamily:"sans-serif" }}>(आप)</span>}</div>
                    <div style={{ fontSize:11,color:C.MUTED,fontFamily:"monospace",marginTop:2 }}>@{u.username}</div>
                  </div>
                  <select value={u.role} onChange={async e=>{ if(u.id===user.id){toast("खुद की role नहीं बदल सकते","warn");return;} const d=users.map(x=>x.id===u.id?{...x,role:e.target.value}:x); await saveUsers(d); toast("Role changed"); }} className="inp" style={{ width:140,padding:"5px 8px",fontSize:11 }}>
                    {Object.entries(ROLES).map(([k,v])=><option key={k} value={k}>{v.icon} {v.label}</option>)}
                  </select>
                  <Toggle val={u.active} color={C.GREEN} onChange={async v=>{ if(u.id===user.id){toast("खुद को disable नहीं कर सकते","warn");return;} const d=users.map(x=>x.id===u.id?{...x,active:v}:x); await saveUsers(d); toast(v?"Active":"Disabled"); }} />
                  <button onClick={async()=>{ if(u.id===user.id){toast("खुद को delete नहीं","warn");return;} const d=users.filter(x=>x.id!==u.id); await saveUsers(d); toast("User deleted","error"); addLog(`User deleted: ${u.username}`); }} style={{ background:"transparent",border:`1px solid ${C.BORDER}`,color:C.R,padding:"4px 8px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"sans-serif" }}>🗑</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ AUDIT LOG ═══ */}
        {tab==="auditlog"&&(
          <div style={{ animation:"fadeIn .3s" }}>
            <SHead icon="📋" label="Audit Log" color={C.MUTED} sub="किसने, क्या, कब किया — पूरी history" />
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,overflow:"hidden" }}>
              {auditLog.length===0&&<div style={{ padding:28,textAlign:"center",color:C.MUTED,fontSize:13 }}>कोई activity नहीं — कुछ actions perform करें</div>}
              {auditLog.map((l,i)=>(
                <div key={l.id} className="rh" style={{ padding:"10px 16px",borderBottom:i<auditLog.length-1?`1px solid ${C.BORDER}`:"none",display:"flex",alignItems:"center",gap:14 }}>
                  <div style={{ width:28,height:28,borderRadius:"50%",background:C.CARD2,border:`1px solid ${C.BORDER2}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontFamily:"sans-serif",color:C.MUTED,flexShrink:0 }}>
                    {l.user?.slice(0,1).toUpperCase()}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:12,color:C.W }}>{l.action}</div>
                    <div style={{ fontSize:10,color:C.MUTED,fontFamily:"sans-serif",marginTop:2 }}>by <b>{l.user}</b></div>
                  </div>
                  <span style={{ fontSize:11,color:C.MUTED,fontFamily:"sans-serif",whiteSpace:"nowrap" }}>{l.time}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ SETTINGS ═══ */}
        {tab==="settings"&&(
          <div style={{ animation:"fadeIn .3s",maxWidth:580 }}>
            <SHead icon="⚙️" label="Settings" color={C.MUTED} />
            {/* Theme */}
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18,marginBottom:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:14,borderLeft:`3px solid ${C.PINK}`,paddingLeft:10 }}>🎨 Website Theme</div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14 }}>
                {[{k:"primary",l:"Primary Color"},{k:"accent",l:"Accent/Gold"}].map(f=>(
                  <div key={f.k}>
                    <Lbl t={f.l.toUpperCase()} />
                    <div style={{ display:"flex",gap:8,alignItems:"center" }}>
                      <input type="color" value={theme[f.k]||"#ffffff"} onChange={e=>setThemeS({...theme,[f.k]:e.target.value})} style={{ width:36,height:36,borderRadius:6,border:"none",cursor:"pointer",background:"transparent" }} />
                      <input className="inp" value={theme[f.k]||""} onChange={e=>setThemeS({...theme,[f.k]:e.target.value})} style={{ fontFamily:"monospace",fontSize:11 }} />
                    </div>
                  </div>
                ))}
              </div>
              <button className="btn btn-g" onClick={async()=>{ await saveTheme(theme); toast("Theme website पर apply हो गई! 🎨"); addLog("Theme updated"); }}>💾 Theme Apply करें (Website पर Live होगी)</button>
            </div>
            {/* Password */}
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18,marginBottom:16 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:14,borderLeft:`3px solid ${C.R}`,paddingLeft:10 }}>🔑 Password Change</div>
              {[{k:"cur",l:"मौजूदा Password"},{k:"nw",l:"नया Password"},{k:"cf",l:"Confirm Password"}].map(f=>(
                <div key={f.k} style={{ marginBottom:12 }}><Lbl t={f.l.toUpperCase()} /><input type="password" className="inp" value={pwForm[f.k]} onChange={e=>setPwForm({...pwForm,[f.k]:e.target.value})} placeholder="••••••••" /></div>
              ))}
              {pwErr&&<div style={{ fontSize:12,color:C.R,marginBottom:10,fontFamily:"sans-serif" }}>{pwErr}</div>}
              <button className="btn btn-r" onClick={async()=>{
                setPwErr("");
                if(!pwForm.cur||!pwForm.nw||!pwForm.cf){setPwErr("सभी fields भरें");return;}
                if(pwForm.cur!==user.password){setPwErr("मौजूदा password गलत है");return;}
                if(pwForm.nw.length<6){setPwErr("कम से कम 6 characters");return;}
                if(pwForm.nw!==pwForm.cf){setPwErr("नया password match नहीं करता");return;}
                const d=users.map(u=>u.id===user.id?{...u,password:pwForm.nw}:u);
                await saveUsers(d);
                setPwForm({cur:"",nw:"",cf:""});
                toast("Password बदल दिया गया ✓");
                addLog("Password changed");
              }}>🔑 Password बदलें</button>
            </div>
            {/* Profile */}
            <div style={{ background:C.CARD,border:`1px solid ${C.BORDER}`,borderRadius:10,padding:18 }}>
              <div style={{ fontSize:13,fontWeight:700,marginBottom:12,borderLeft:`3px solid ${C.GOLD}`,paddingLeft:10 }}>👤 Profile</div>
              <div style={{ display:"flex",alignItems:"center",gap:14 }}>
                <div style={{ width:52,height:52,borderRadius:"50%",background:ROLES[user.role]?.color+"25",border:`2px solid ${ROLES[user.role]?.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22 }}>{ROLES[user.role]?.icon}</div>
                <div>
                  <div style={{ fontSize:16,fontWeight:700 }}>{user.name}</div>
                  <div style={{ fontSize:12,color:C.MUTED,fontFamily:"sans-serif",marginTop:2 }}>@{user.username}</div>
                  <div style={{ marginTop:6 }}><Badge text={ROLES[user.role]?.label} color={ROLES[user.role]?.color} /></div>
                </div>
              </div>
            </div>
          </div>
        )}

        </div>
      </div>

      <Toast msg={toastS.msg} type={toastS.type} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   ROOT ROUTER  —  Hash-based URL simulation
══════════════════════════════════════════════════════ */
export default function App() {
  const [route, setRoute] = useState("website");
  const [urlBar, setUrlBar] = useState("delhinama.com");

  const goAdmin = () => { setRoute("admin"); setUrlBar("admin.delhinama.com"); };
  const goWebsite = () => { setRoute("website"); setUrlBar("delhinama.com"); };

  return (
    <div>
      <style>{globalCSS}</style>

      {/* ── FAKE BROWSER BAR ── */}
      <div style={{ background:"#111",borderBottom:`1px solid #1e1e1e`,padding:"6px 14px",display:"flex",alignItems:"center",gap:10,fontFamily:"sans-serif",position:"sticky",top:0,zIndex:200 }}>
        <div style={{ display:"flex",gap:5 }}>
          <div style={{ width:10,height:10,borderRadius:"50%",background:"#FF5F57" }}></div>
          <div style={{ width:10,height:10,borderRadius:"50%",background:"#FEBC2E" }}></div>
          <div style={{ width:10,height:10,borderRadius:"50%",background:"#28C840" }}></div>
        </div>
        <div style={{ flex:1,background:"#1a1a1a",border:"1px solid #2a2a2a",borderRadius:6,padding:"4px 12px",fontSize:12,color:"#aaa",display:"flex",alignItems:"center",gap:8,maxWidth:500,margin:"0 auto" }}>
          <span style={{ fontSize:11,color:"#4CAF50" }}>🔒</span>
          <span style={{ color:route==="admin"?"#C8962E":"#aaa",fontWeight:route==="admin"?600:400 }}>https://{urlBar}</span>
        </div>
        <div style={{ display:"flex",gap:8 }}>
          <button onClick={goWebsite} style={{ background:route==="website"?"#C41E2822":"transparent",border:`1px solid ${route==="website"?"#C41E28":"#333"}`,borderRadius:5,padding:"3px 10px",color:route==="website"?"#C41E28":"#666",fontSize:11,cursor:"pointer" }}>🌐 Website</button>
          <button onClick={goAdmin} style={{ background:route==="admin"?"#C8962E22":"transparent",border:`1px solid ${route==="admin"?"#C8962E":"#333"}`,borderRadius:5,padding:"3px 10px",color:route==="admin"?"#C8962E":"#666",fontSize:11,cursor:"pointer" }}>🔐 Admin</button>
        </div>
      </div>

      {route==="website" && <Website onGoAdmin={goAdmin} />}
      {route==="admin"   && <AdminPanel onGoWebsite={goWebsite} />}
    </div>
  );
}
