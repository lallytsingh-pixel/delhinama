import { useState, useEffect } from "react";

const R = "#C41E28", GOLD = "#C8962E", BG = "#080809", CARD = "#0F0F12",
  CARD2 = "#161618", WHITE = "#EDE9E4", MUTED = "#6A6867", BORDER = "#1E1E21",
  BORDER2 = "#252527";

const CATS = ["होम","देश","विदेश","राज्य","राजनीति","बाजार","मनोरंजन",
  "दिल्ली","टेक","शिक्षा","कैरियर","ऑटो","यात्रा","लाइफ","अध्यात्म","बोले फ्री","फोटो","वीडियो"];

const TICKERS = [
  "संसद सत्र में विपक्ष का भारी हंगामा, अध्यक्ष ने कार्यवाही स्थगित की",
  "दिल्ली में अचानक बारिश — ITO, मिंटो ब्रिज पर जलभराव, लंबा ट्रैफिक जाम",
  "सेंसेक्स 400 अंक उछला, IT और फार्मा सेक्टर में जोरदार तेजी",
  "भारत-पाक सीमा पर BSF हाई अलर्ट, सेना की गश्त दोगुनी की गई",
  "मेट्रो फेज-4: जनकपुरी-RK Ashram कॉरिडोर पर काम फिर रुका, जांच के आदेश",
];

const HERO = {
  badge: "ब्रेकिंग", cat: "दिल्ली",
  title: "दिल्ली का AQI 412 पार — NGT का आदेश: कल से सम-विषम लागू, ट्रकों की एंट्री बंद",
  text: "प्रदूषण की आपातकालीन स्थिति में नेशनल ग्रीन ट्रिब्यूनल ने दिल्ली सरकार को तत्काल सम-विषम वाहन योजना लागू करने के आदेश दिए। ट्रकों व निर्माण कार्य पर भी पाबंदी।",
  time: "45 मिनट पहले", by: "विशेष संवाददाता",
};

const SIDE = [
  { cat:"राजनीति", title:"राहुल गांधी का ऐलान: 'अगले चुनाव में 200 सीट जीतेंगे, झूठ का जवाब जनता देगी'", time:"1 घ. पहले", bg:"#0a1230" },
  { cat:"देश", title:"मणिपुर में फिर हिंसा — सेना ने संभाला मोर्चा, इंटरनेट सेवाएं बंद", time:"2 घ. पहले", bg:"#200a0a" },
  { cat:"बाजार", title:"Nifty 23,450 के पार — IT और ऑटो सेक्टर में 3% की जोरदार छलांग", time:"3 घ. पहले", bg:"#0a1a0e" },
  { cat:"विदेश", title:"US में भारतीय छात्रों पर वीज़ा नियम कड़े, विदेश मंत्रालय नाराज", time:"4 घ. पहले", bg:"#0e0a1e" },
];

const DELHI = [
  { title:"पूर्वी दिल्ली में 30 घंटे से बिजली गुल, BSES का जवाब—'केबल खराब है'", tag:"🔥 वायरल", v:"1.2L" },
  { title:"DDA के नए फ्लैट्स में पानी की किल्लत, RWA ने CM को लिखा आपातकालीन पत्र", tag:"जरूरी", v:"84K" },
  { title:"मेट्रो फेज-4 में नई अड़चन — 3 स्टेशनों पर काम 2 महीने से ठप", tag:"शहर", v:"63K" },
  { title:"यमुना में प्रदूषण खतरनाक स्तर पर — DPCC का डेटा चौंकाने वाला", tag:"⚠️ जरूरी", v:"2.4L" },
  { title:"ओल्ड दिल्ली में सड़क धंसी, 6 दुकानें क्षतिग्रस्त — NDMC पर उठे सवाल", tag:"लोकल", v:"47K" },
  { title:"200 सरकारी स्कूलों में कमरों की कमी, बच्चे 3 शिफ्ट में पढ़ने को मजबूर", tag:"शिक्षा", v:"1.1L" },
];

const POLITICS = [
  { title:"PM मोदी का विपक्ष पर तीखा हमला: 'सत्ता के लिए देश को गुमराह करना बंद करो'", time:"1 घ. पहले", tag:"BJP" },
  { title:"कांग्रेस में टूट — 5 सांसदों ने छोड़ी पार्टी, इस्तीफे की वजह बताने से इनकार", time:"2 घ. पहले", tag:"कांग्रेस" },
  { title:"केजरीवाल का दावा: 'दिल्ली में अगली बार 70 में से 70 सीटें AAP को मिलेंगी'", time:"3 घ. पहले", tag:"AAP" },
  { title:"2026 चुनाव से पहले BJP का 'मेगा मिशन' — 100 रैलियों की तैयारी शुरू", time:"4 घ. पहले", tag:"चुनाव" },
];

const BOLE = [
  { name:"रमेश शर्मा", area:"पटपड़गंज, दिल्ली", issue:"टूटी सड़क", text:"6 महीने से गली में सड़क टूटी है। बारिश में कीचड़-कीचड़। नगर पालिका को 10 बार शिकायत की पर कुछ नहीं हुआ। अब बोले फ्री पर आवाज़ उठा रहे हैं।", votes:312 },
  { name:"सुनीता देवी", area:"शाहदरा, दिल्ली", issue:"बिजली कटौती", text:"रोज 8-10 घंटे बिजली नहीं। गर्मी में बच्चे बीमार पड़ रहे हैं। BSES का नंबर लगता नहीं, कोई सुनने वाला नहीं।", votes:245 },
  { name:"मोहम्मद अली", area:"जामिया नगर, दिल्ली", issue:"सरकारी स्कूल", text:"80 बच्चों के लिए सिर्फ 2 टीचर। सरकारी स्कूल में पढ़ाई नाम मात्र है। बच्चों का भविष्य खतरे में है।", votes:489 },
];

const VIDEOS = [
  { title:"दिल्ली प्रदूषण: ग्राउंड रिपोर्ट | सच क्या है?", dur:"8:24", v:"2.1L", col:"#1a0808" },
  { title:"संसद में हंगामा: विपक्ष ने क्यों रोकी कार्यवाही? पूरा सच", dur:"12:05", v:"5.3L", col:"#0a0820" },
  { title:"बोले फ्री: जनता पूछती है — नेता जवाब देंगे?", dur:"6:45", v:"1.8L", col:"#0a1808" },
];

const TAG_COLORS = { BJP:"#FF6B20", कांग्रेस:"#1060C0", AAP:"#0087E0", चुनाव:"#7B1FA2", राजनीति:R, देश:"#1565C0", दिल्ली:R, बाजार:"#2E7D32" };

function tagColor(t) { return TAG_COLORS[t] || R; }

export default function Delhinama() {
  const [nav, setNav] = useState("होम");
  const [tick, setTick] = useState(0);
  const [tickAnim, setTickAnim] = useState(true);
  const [voted, setVoted] = useState(null);
  const [votes, setVotes] = useState(BOLE.map(b => b.votes));

  useEffect(() => {
    const iv = setInterval(() => {
      setTickAnim(false);
      setTimeout(() => { setTick(i => (i + 1) % TICKERS.length); setTickAnim(true); }, 200);
    }, 5000);
    return () => clearInterval(iv);
  }, []);

  const doVote = i => {
    if (voted === i) return;
    setVoted(i);
    setVotes(v => v.map((n, j) => j === i ? n + 1 : n));
  };

  return (
    <div style={{ background: BG, color: WHITE, fontFamily: "'Noto Sans Devanagari', sans-serif", minHeight:"100vh", overflowX:"hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&family=Noto+Serif+Devanagari:wght@600;700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{height:3px;width:3px}
        ::-webkit-scrollbar-thumb{background:${BORDER2};border-radius:3px}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes scrollMarquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}
        .hov{transition:transform .2s,border-color .2s;cursor:pointer}
        .hov:hover{transform:translateY(-2px)}
        .hov-border:hover{border-color:${R}!important}
        .nav-btn{padding:8px 15px;cursor:pointer;white-space:nowrap;font-size:13.5px;font-weight:500;border-bottom:2px solid transparent;transition:all .2s;color:${MUTED}}
        .nav-btn:hover{color:${WHITE}}
        .vote-btn{border:1px solid ${BORDER2};background:transparent;color:${MUTED};padding:4px 12px;border-radius:5px;font-size:12px;cursor:pointer;transition:all .2s;font-family:'Noto Sans Devanagari',sans-serif}
        .vote-btn:hover{border-color:${R};color:${R};background:${R}11}
        .hide-scroll{overflow-x:auto;scrollbar-width:none}
        .hide-scroll::-webkit-scrollbar{display:none}
        a{color:inherit;text-decoration:none}
      `}</style>

      {/* ─── TOP BAR ─── */}
      <div style={{ background:"#000", borderBottom:`1px solid ${BORDER}`, padding:"5px 20px", display:"flex", justifyContent:"space-between", alignItems:"center", fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>
        <div style={{ display:"flex", gap:18, alignItems:"center" }}>
          <span>मंगलवार, 27 मई 2025</span>
          <span style={{ color:BORDER }}>│</span>
          <span>🌡 दिल्ली 38°C</span>
          <span style={{ color:BORDER }}>│</span>
          <span>AQI: <b style={{ color:"#E05030" }}>187 मध्यम</b></span>
          <span style={{ color:BORDER }}>│</span>
          <span>💧 आर्द्रता: 68%</span>
        </div>
        <div style={{ display:"flex", gap:14, alignItems:"center" }}>
          <span style={{ display:"flex", alignItems:"center", gap:5 }}>
            <span style={{ width:6, height:6, borderRadius:"50%", background:R, display:"inline-block", animation:"pulse 1.4s infinite" }}></span>
            <span style={{ color:R, fontWeight:700, letterSpacing:.5 }}>LIVE TV</span>
          </span>
          <span style={{ color:BORDER }}>│</span>
          <span style={{ cursor:"pointer" }}>📱 ऐप</span>
          <span style={{ color:BORDER }}>│</span>
          <span style={{ cursor:"pointer" }}>ई-पेपर</span>
        </div>
      </div>

      {/* ─── HEADER ─── */}
      <div style={{ background:CARD, borderBottom:`2.5px solid ${R}`, padding:"10px 20px", display:"flex", alignItems:"center", justifyContent:"space-between", position:"sticky", top:0, zIndex:100 }}>
        {/* Logo */}
        <div style={{ lineHeight:1 }}>
          <div style={{ fontSize:30, fontWeight:900, color:R, fontFamily:"'Noto Serif Devanagari', serif", letterSpacing:-1 }}>दिल्लीनामा</div>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginTop:3 }}>
            <span style={{ fontSize:9.5, color:GOLD, letterSpacing:3.5, fontFamily:"sans-serif", fontWeight:600 }}>DELHINAMA</span>
            <span style={{ color:BORDER }}>•</span>
            <span style={{ fontSize:11, color:MUTED }}>दिल्ली की असली आवाज़</span>
          </div>
        </div>

        {/* Search bar */}
        <div style={{ flex:1, maxWidth:340, margin:"0 28px", background:CARD2, border:`1px solid ${BORDER2}`, borderRadius:7, padding:"7px 14px", display:"flex", alignItems:"center", gap:8, cursor:"text" }}>
          <span style={{ color:MUTED, fontSize:14 }}>🔍</span>
          <span style={{ fontSize:13, color:MUTED }}>खोजें — खबर, शहर, मुद्दा...</span>
        </div>

        {/* Social + Subscribe */}
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          {[{l:"YT",c:"#FF0000"},{l:"FB",c:"#1877F2"},{l:"TW",c:"#1DA1F2"},{l:"IG",c:"#E1306C"}].map(({l,c})=>(
            <div key={l} style={{ width:30, height:30, borderRadius:6, background:CARD2, border:`1px solid ${BORDER2}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:c, cursor:"pointer", fontFamily:"sans-serif", fontWeight:700 }}>{l}</div>
          ))}
          <div style={{ background:R, color:WHITE, padding:"7px 16px", borderRadius:7, fontSize:11.5, fontWeight:700, cursor:"pointer", fontFamily:"sans-serif", letterSpacing:.5 }}>SUBSCRIBE</div>
        </div>
      </div>

      {/* ─── BREAKING TICKER ─── */}
      <div style={{ background:R, display:"flex", alignItems:"stretch", minHeight:34 }}>
        <div style={{ background:"#8B0000", padding:"7px 16px", fontSize:11.5, fontWeight:700, color:WHITE, letterSpacing:1, fontFamily:"sans-serif", display:"flex", alignItems:"center", gap:6, borderRight:"2px solid #ffffff22", whiteSpace:"nowrap" }}>
          <span style={{ width:7, height:7, borderRadius:"50%", background:WHITE, display:"inline-block", animation:"pulse 1s infinite" }}></span>
          ब्रेकिंग न्यूज़
        </div>
        <div style={{ padding:"7px 18px", fontSize:13.5, fontWeight:500, color:WHITE, animation: tickAnim ? "fadeIn .3s ease" : "none", flex:1 }}>
          {TICKERS[tick]}
        </div>
        <div style={{ padding:"7px 14px", fontSize:11, color:"#ffffff88", borderLeft:"1px solid #ffffff22", display:"flex", alignItems:"center", cursor:"pointer", fontFamily:"sans-serif", whiteSpace:"nowrap" }}>
          सब देखें ›
        </div>
      </div>

      {/* ─── NAV ─── */}
      <div style={{ background:CARD, borderBottom:`1px solid ${BORDER}` }} className="hide-scroll">
        <div style={{ display:"flex", padding:"0 10px", minWidth:"max-content" }}>
          {CATS.map(c => (
            <div key={c} className="nav-btn" onClick={() => setNav(c)}
              style={{ color: nav===c ? GOLD : undefined, borderBottomColor: nav===c ? GOLD : "transparent" }}>
              {c}
            </div>
          ))}
        </div>
      </div>

      <div style={{ maxWidth:1280, margin:"0 auto", padding:"18px 18px" }}>

        {/* ─── HERO ─── */}
        <div style={{ display:"grid", gridTemplateColumns:"3fr 2fr", gap:14, marginBottom:22 }}>

          {/* Big Story */}
          <div className="hov" style={{ borderRadius:10, overflow:"hidden", background:CARD, border:`1px solid ${BORDER}` }}>
            {/* Image area */}
            <div style={{ height:300, background:"linear-gradient(160deg, #2d0609 0%, #090810 55%, #180a00 100%)", position:"relative", display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
              <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top, #000000f0 0%, #00000044 45%, transparent 100%)" }}></div>
              {/* Decorative: abstract Delhi skyline dots */}
              <svg style={{ position:"absolute", bottom:0, left:0, right:0, opacity:.12 }} height="80" viewBox="0 0 800 80" preserveAspectRatio="none">
                <rect x="60" y="30" width="8" height="50" fill="#fff"/>
                <rect x="72" y="20" width="8" height="60" fill="#fff"/>
                <rect x="84" y="35" width="8" height="45" fill="#fff"/>
                <rect x="160" y="15" width="12" height="65" fill="#fff"/>
                <rect x="176" y="28" width="8" height="52" fill="#fff"/>
                <rect x="300" y="10" width="16" height="70" fill="#fff"/>
                <rect x="320" y="25" width="10" height="55" fill="#fff"/>
                <rect x="500" y="18" width="14" height="62" fill="#fff"/>
                <rect x="518" y="30" width="8" height="50" fill="#fff"/>
                <rect x="650" y="12" width="18" height="68" fill="#fff"/>
                <rect x="672" y="28" width="10" height="52" fill="#fff"/>
                <polygon points="300,10 308,10 304,0" fill="#fff"/>
                <polygon points="160,15 172,15 166,5" fill="#fff"/>
              </svg>
              {/* Badges */}
              <div style={{ position:"absolute", top:16, left:16, display:"flex", gap:8 }}>
                <span style={{ background:R, color:WHITE, padding:"3px 10px", borderRadius:5, fontSize:10.5, fontWeight:700, fontFamily:"sans-serif", letterSpacing:.5 }}>{HERO.badge}</span>
                <span style={{ background:GOLD+"25", color:GOLD, padding:"3px 10px", borderRadius:5, fontSize:10.5, fontWeight:600, border:`1px solid ${GOLD}44`, fontFamily:"sans-serif" }}>{HERO.cat}</span>
              </div>
              {/* LIVE pill */}
              <div style={{ position:"absolute", top:16, right:16, background:"#000c", border:`1px solid ${R}`, borderRadius:5, padding:"3px 10px", fontSize:10, color:R, fontFamily:"sans-serif", fontWeight:700, display:"flex", alignItems:"center", gap:5 }}>
                <span style={{ width:5, height:5, borderRadius:"50%", background:R, display:"inline-block", animation:"pulse 1s infinite" }}></span>LIVE
              </div>
              {/* Text */}
              <div style={{ position:"relative", zIndex:2, padding:"0 20px 20px" }}>
                <div style={{ fontSize:21, fontWeight:700, lineHeight:1.45, color:WHITE, fontFamily:"'Noto Serif Devanagari', serif", marginBottom:10 }}>{HERO.title}</div>
                <div style={{ fontSize:13, color:"#c8c4bf", lineHeight:1.6, marginBottom:10 }}>{HERO.text}</div>
                <div style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>{HERO.time} • {HERO.by}</div>
              </div>
            </div>
          </div>

          {/* Side stories */}
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {SIDE.map((n,i) => (
              <div key={i} className="hov hov-border" style={{ background:CARD, borderRadius:8, overflow:"hidden", display:"flex", gap:0, border:`1px solid ${BORDER}`, flexShrink:0 }}>
                <div style={{ width:88, minWidth:88, background:n.bg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22 }}>
                  {["📰","🗺️","📈","✈️"][i]}
                </div>
                <div style={{ padding:"10px 12px", flex:1 }}>
                  <span style={{ fontSize:10, fontWeight:700, color:tagColor(n.cat), fontFamily:"sans-serif" }}>{n.cat}</span>
                  <div style={{ fontSize:12.5, fontWeight:600, lineHeight:1.45, color:WHITE, marginTop:4 }}>{n.title}</div>
                  <div style={{ fontSize:10, color:MUTED, marginTop:6, fontFamily:"sans-serif" }}>{n.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ─── DELHI LOCAL ─── */}
        <div style={{ marginBottom:22 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:14 }}>
            <div style={{ borderLeft:`3.5px solid ${R}`, paddingLeft:12 }}>
              <div style={{ fontSize:19, fontWeight:700, color:WHITE, fontFamily:"'Noto Serif Devanagari', serif" }}>📍 दिल्ली की बात</div>
              <div style={{ fontSize:11, color:MUTED, marginTop:2, fontFamily:"sans-serif", letterSpacing:.3 }}>HYPERLOCAL • हर गली की खबर</div>
            </div>
            <span style={{ fontSize:12, color:GOLD, cursor:"pointer", fontFamily:"sans-serif" }}>सब देखें →</span>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:12 }}>
            {DELHI.map((n,i) => (
              <div key={i} className="hov hov-border" style={{ background:CARD, borderRadius:9, padding:14, border:`1px solid ${BORDER}` }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:9 }}>
                  <span style={{ background:R+"22", color:R, padding:"2px 9px", borderRadius:4, fontSize:10, fontWeight:600, border:`1px solid ${R}30` }}>{n.tag}</span>
                  <span style={{ fontSize:10, color:MUTED, fontFamily:"sans-serif" }}>👁 {n.v}</span>
                </div>
                <div style={{ fontSize:13, fontWeight:600, lineHeight:1.5, color:WHITE }}>{n.title}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ─── POLITICS + BOLE FREE ─── */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18, marginBottom:22 }}>

          {/* Politics */}
          <div>
            <div style={{ borderLeft:`3.5px solid #9C27B0`, paddingLeft:12, marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div style={{ fontSize:18, fontWeight:700, color:WHITE, fontFamily:"'Noto Serif Devanagari', serif" }}>⚡ राजनीति</div>
              <span style={{ fontSize:12, color:GOLD, cursor:"pointer", fontFamily:"sans-serif" }}>और →</span>
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {POLITICS.map((n,i) => (
                <div key={i} className="hov hov-border" style={{ background:CARD, borderRadius:8, padding:13, border:`1px solid ${BORDER}`, display:"flex", gap:10 }}>
                  <span style={{ background:tagColor(n.tag), color:WHITE, padding:"3px 8px", borderRadius:4, fontSize:9.5, fontWeight:700, whiteSpace:"nowrap", alignSelf:"flex-start", marginTop:2, fontFamily:"sans-serif" }}>{n.tag}</span>
                  <div>
                    <div style={{ fontSize:13, fontWeight:600, lineHeight:1.45, color:WHITE }}>{n.title}</div>
                    <div style={{ fontSize:10, color:MUTED, marginTop:5, fontFamily:"sans-serif" }}>{n.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bole Free */}
          <div style={{ background:`linear-gradient(160deg, ${R}0d 0%, ${CARD} 100%)`, border:`1px solid ${R}2a`, borderRadius:10, padding:16 }}>
            <div style={{ borderLeft:`3.5px solid ${GOLD}`, paddingLeft:12, marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div>
                <div style={{ fontSize:18, fontWeight:700, color:GOLD, fontFamily:"'Noto Serif Devanagari', serif" }}>📢 बोले फ्री</div>
                <div style={{ fontSize:10, color:MUTED, marginTop:2, fontFamily:"sans-serif" }}>CIVIC VOICE PLATFORM • जनता की आवाज़</div>
              </div>
              <button className="vote-btn" style={{ fontSize:11, color:GOLD, borderColor:GOLD+"44" }}>+ पोस्ट करें</button>
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {BOLE.map((p,i) => (
                <div key={i} style={{ background:CARD2, borderRadius:8, padding:13, border:`1px solid ${BORDER}` }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:7 }}>
                    <div>
                      <span style={{ fontSize:12.5, fontWeight:600, color:WHITE }}>{p.name}</span>
                      <span style={{ fontSize:10, color:MUTED, marginLeft:8, fontFamily:"sans-serif" }}>{p.area}</span>
                    </div>
                    <span style={{ background:R+"1a", color:R, padding:"2px 9px", borderRadius:4, fontSize:9.5, fontWeight:600, border:`1px solid ${R}30`, fontFamily:"sans-serif" }}>{p.issue}</span>
                  </div>
                  <div style={{ fontSize:12.5, color:"#b8b4b0", lineHeight:1.55, marginBottom:9 }}>{p.text}</div>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <button className="vote-btn" onClick={() => doVote(i)}
                      style={{ borderColor: voted===i ? R : BORDER2, color: voted===i ? R : MUTED, background: voted===i ? R+"18" : "transparent" }}>
                      👍 {votes[i]} समर्थन
                    </button>
                    <span style={{ fontSize:10, color:MUTED, cursor:"pointer", fontFamily:"sans-serif" }}>🔗 शेयर करें</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ─── VIDEO SECTION ─── */}
        <div style={{ marginBottom:22 }}>
          <div style={{ borderLeft:`3.5px solid ${R}`, paddingLeft:12, marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div>
              <div style={{ fontSize:18, fontWeight:700, color:WHITE, fontFamily:"'Noto Serif Devanagari', serif" }}>🎥 वीडियो खबरें</div>
              <div style={{ fontSize:11, color:MUTED, marginTop:2, fontFamily:"sans-serif" }}>VIDEO NEWS • ग्राउंड रिपोर्ट्स</div>
            </div>
            <span style={{ fontSize:12, color:GOLD, cursor:"pointer", fontFamily:"sans-serif" }}>YouTube पर देखें →</span>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:14 }}>
            {VIDEOS.map((v,i) => (
              <div key={i} className="hov hov-border" style={{ background:CARD, borderRadius:9, overflow:"hidden", border:`1px solid ${BORDER}` }}>
                <div style={{ height:126, background:v.col, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
                  <div style={{ width:46, height:46, borderRadius:"50%", background:`${R}cc`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:17, color:WHITE }}>▶</div>
                  <div style={{ position:"absolute", bottom:8, right:9, background:"#000b", padding:"2px 7px", borderRadius:4, fontSize:11, color:WHITE, fontFamily:"sans-serif" }}>{v.dur}</div>
                  <div style={{ position:"absolute", top:8, left:9, background:R, padding:"2px 7px", borderRadius:4, fontSize:9.5, color:WHITE, fontFamily:"sans-serif", fontWeight:700 }}>VIDEO</div>
                </div>
                <div style={{ padding:"12px 13px" }}>
                  <div style={{ fontSize:13, fontWeight:600, lineHeight:1.45, color:WHITE, marginBottom:7 }}>{v.title}</div>
                  <div style={{ fontSize:10.5, color:MUTED, fontFamily:"sans-serif" }}>👁 {v.v} व्यूज़</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ─── TICKER STRIP ─── */}
        <div style={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:8, padding:"10px 16px", marginBottom:22, overflow:"hidden" }}>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            <span style={{ fontSize:11, fontWeight:700, color:GOLD, whiteSpace:"nowrap", fontFamily:"sans-serif", borderRight:`1px solid ${BORDER2}`, paddingRight:14 }}>⚡ ट्रेंडिंग</span>
            <div style={{ overflow:"hidden", flex:1 }}>
              <div style={{ display:"flex", gap:32, animation:"scrollMarquee 28s linear infinite", whiteSpace:"nowrap", width:"max-content" }}>
                {[...TICKERS,...TICKERS].map((t,i) => (
                  <span key={i} style={{ fontSize:12, color:"#aaa", cursor:"pointer" }}>{t}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* ─── FOOTER ─── */}
      <div style={{ background:"#000", borderTop:`2.5px solid ${R}` }}>
        <div style={{ maxWidth:1280, margin:"0 auto", padding:"26px 18px 18px" }}>
          <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr 1fr 1fr", gap:28, marginBottom:24 }}>
            <div>
              <div style={{ fontSize:24, fontWeight:900, color:R, fontFamily:"'Noto Serif Devanagari', serif", letterSpacing:-0.5 }}>दिल्लीनामा</div>
              <div style={{ fontSize:9.5, color:GOLD, letterSpacing:3.5, fontFamily:"sans-serif", marginTop:4, marginBottom:12, fontWeight:600 }}>DELHINAMA</div>
              <div style={{ fontSize:12.5, color:MUTED, lineHeight:1.65, maxWidth:270 }}>दिल्ली और देश की हर खबर — जनता की भाषा में। सवाल भी, समाधान भी।</div>
              <div style={{ display:"flex", gap:8, marginTop:14 }}>
                {[{l:"YT",c:"#FF0000"},{l:"FB",c:"#1877F2"},{l:"TW",c:"#1DA1F2"},{l:"IG",c:"#E1306C"}].map(({l,c})=>(
                  <div key={l} style={{ width:32, height:32, borderRadius:7, background:CARD2, border:`1px solid ${BORDER2}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10.5, color:c, cursor:"pointer", fontFamily:"sans-serif", fontWeight:700 }}>{l}</div>
                ))}
              </div>
            </div>
            {[
              { h:"मुख्य खबरें", items:["देश","विदेश","राजनीति","दिल्ली","बाजार","मनोरंजन"] },
              { h:"लाइफस्टाइल", items:["लाइफ","स्टाइल","यात्रा","कैरियर","टेक","ऑटो"] },
              { h:"हमारे बारे में", items:["बोले फ्री","हमसे मिलें","विज्ञापन","गोपनीयता","संपर्क"] },
            ].map((col,i) => (
              <div key={i}>
                <div style={{ fontSize:13, fontWeight:700, color:WHITE, marginBottom:13, borderBottom:`1px solid ${BORDER}`, paddingBottom:9 }}>{col.h}</div>
                {col.items.map(item => (
                  <div key={item} style={{ fontSize:12, color:MUTED, marginBottom:9, cursor:"pointer" }}>{item}</div>
                ))}
              </div>
            ))}
          </div>
          <div style={{ borderTop:`1px solid ${BORDER}`, paddingTop:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div style={{ fontSize:11, color:MUTED, fontFamily:"sans-serif" }}>© 2025 Delhinama Media Pvt. Ltd. • सर्वाधिकार सुरक्षित</div>
            <div style={{ display:"flex", alignItems:"center", gap:6, fontSize:11, color:MUTED }}>
              <span style={{ width:6, height:6, borderRadius:"50%", background:R, display:"inline-block", animation:"pulse 1.5s infinite" }}></span>
              <span style={{ color:R, fontWeight:600, fontFamily:"sans-serif" }}>दिल्ली की असली आवाज़</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
