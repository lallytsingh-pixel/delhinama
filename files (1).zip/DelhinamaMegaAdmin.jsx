import { useState, useEffect, useRef, useCallback } from "react";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

/* ══ PALETTE ══ */
const P = {
  R:"#C41E28", GOLD:"#C8962E", BG:"#060608", CARD:"#0E0E12", CARD2:"#141418",
  WHITE:"#EDE9E4", MUTED:"#606060", BORDER:"#1A1A1E", BORDER2:"#222228",
  GREEN:"#16A34A", BLUE:"#1D4ED8", PURPLE:"#7C3AED", TEAL:"#0D9488",
  ORANGE:"#EA580C", PINK:"#DB2777"
};

/* ══ STORAGE ══ */
async function dbGet(k, fb) { try { const r = await window.storage.get(k); return r ? JSON.parse(r.value) : fb; } catch { return fb; } }
async function dbSet(k, v) { try { await window.storage.set(k, JSON.stringify(v)); return true; } catch { return false; } }

/* ══ NAV CONFIG ══ */
const MODULES = [
  { id:"dashboard",      icon:"📊", label:"Dashboard",       color:P.GOLD },
  { id:"ai",             icon:"🤖", label:"AI Automation",   color:P.PURPLE },
  { id:"security",       icon:"🛡️", label:"CF Security",    color:P.BLUE },
  { id:"infra",          icon:"☁️", label:"AWS + Docker",   color:P.TEAL },
  { id:"theme",          icon:"🎨", label:"Theme & Layout",  color:P.PINK },
  { id:"ads",            icon:"💰", label:"Ads Manager",     color:P.GOLD },
  { id:"reels",          icon:"🎬", label:"Reels Control",   color:P.ORANGE },
  { id:"push",           icon:"🔔", label:"Push Alerts",     color:P.GREEN },
  { id:"analytics",      icon:"📈", label:"Advanced Analytics", color:P.BLUE },
];

/* ══ SEED DATA ══ */
const analyticsData = [
  { day:"Mon", views:14200, users:3200, bounce:42 },
  { day:"Tue", views:18900, users:4100, bounce:38 },
  { day:"Wed", views:22400, users:5600, bounce:35 },
  { day:"Thu", views:19800, users:4400, bounce:40 },
  { day:"Fri", views:27600, users:6200, bounce:33 },
  { day:"Sat", views:31200, users:7100, bounce:29 },
  { day:"Sun", views:24500, users:5400, bounce:36 },
];
const revenueData = [
  { month:"Jan", display:12400, native:8200, video:5400 },
  { month:"Feb", month_:14200, display:15800, native:9100, video:7200 },
  { month:"Mar", display:18900, native:11400, video:9800 },
  { month:"Apr", display:16200, native:10200, video:8400 },
  { month:"May", display:22100, native:13800, video:12400 },
];
const catData = [
  { name:"दिल्ली", value:35, color:P.R },
  { name:"राजनीति", value:28, color:P.PURPLE },
  { name:"देश", value:18, color:P.BLUE },
  { name:"बाजार", value:12, color:P.GOLD },
  { name:"अन्य", value:7, color:P.MUTED },
];
const SEED_ADS = [
  { id:1, name:"Delhi Elections 2025", slot:"Hero Banner", status:"active", impressions:124000, clicks:3200, ctr:2.58, rev:18400, start:"2025-05-01", end:"2025-06-30", client:"BJP Media Cell" },
  { id:2, name:"Flipkart Big Sale", slot:"Sidebar Right", status:"active", impressions:89200, clicks:4100, ctr:4.60, rev:12200, start:"2025-05-15", end:"2025-05-31", client:"Flipkart" },
  { id:3, name:"HDFC Bank Loan", slot:"In-Article", status:"paused", impressions:45000, clicks:890, ctr:1.98, rev:6800, start:"2025-04-01", end:"2025-07-31", client:"HDFC Bank" },
  { id:4, name:"JEE Prep App", slot:"Footer", status:"active", impressions:67000, clicks:2800, ctr:4.18, rev:9200, start:"2025-05-20", end:"2025-06-15", client:"Vedantu" },
];
const SEED_REELS = [
  { id:1, title:"दिल्ली प्रदूषण: ग्राउंड रिपोर्ट", duration:"0:58", views:214000, likes:8400, status:"published", category:"दिल्ली", date:"2025-05-27" },
  { id:2, title:"संसद में हंगामा — पूरा सच", duration:"1:12", views:531000, likes:21200, status:"published", category:"राजनीति", date:"2025-05-26" },
  { id:3, title:"बोले फ्री: जनता की आवाज़", duration:"0:45", views:178000, likes:6900, status:"published", category:"विशेष", date:"2025-05-25" },
  { id:4, title:"दिल्ली मेट्रो अपडेट 2025", duration:"1:05", views:0, likes:0, status:"draft", category:"दिल्ली", date:"2025-05-27" },
];
const SEED_PUSH = [
  { id:1, title:"🚨 ब्रेकिंग: AQI 412 पार", body:"दिल्ली में प्रदूषण आपात — सम-विषम लागू", sent:284000, opened:68200, ctr:24.0, date:"2025-05-27 09:14", topic:"breaking" },
  { id:2, title:"📊 बाजार अपडेट", body:"Sensex 400 अंक उछला — जानें किस सेक्टर में तेजी", sent:142000, opened:29800, ctr:21.0, date:"2025-05-27 11:30", topic:"market" },
  { id:3, title:"📢 बोले फ्री: नई पोस्ट", body:"पटपड़गंज की टूटी सड़क — 312 लोगों ने समर्थन किया", sent:98000, opened:18400, ctr:18.8, date:"2025-05-26 15:45", topic:"community" },
];
const CF_RULES = [
  { id:1, name:"Block Scrapers", type:"Block", expression:"cf.client.bot", hits:2841, status:true },
  { id:2, name:"Rate Limit API", type:"Rate Limit", expression:"rate > 100/min", hits:412, status:true },
  { id:3, name:"Allow Googlebot", type:"Allow", expression:"cf.client.bot.name = Googlebot", hits:8924, status:true },
  { id:4, name:"Block Bad Countries", type:"Block", expression:"ip.geoip.country in {CN KP}", hits:184, status:false },
];

/* ══ TINY UI ══ */
const css = `
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
@keyframes slideUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
@keyframes spin{to{transform:rotate(360deg)}}
.rh:hover{background:${P.CARD2}!important}
.btn{border:none;border-radius:7px;padding:8px 16px;font-size:12px;font-weight:700;cursor:pointer;font-family:'Noto Sans Devanagari',sans-serif;transition:opacity .15s}
.btn:hover{opacity:.85}
.btn-r{background:${P.R};color:${P.WHITE}}
.btn-g{background:${P.GREEN};color:${P.WHITE}}
.btn-b{background:${P.BLUE};color:${P.WHITE}}
.btn-p{background:${P.PURPLE};color:${P.WHITE}}
.btn-o{background:${P.ORANGE};color:${P.WHITE}}
.btn-ghost{background:transparent;border:1px solid ${P.BORDER2};color:${P.MUTED}}
.inp{width:100%;background:${P.CARD2};border:1px solid ${P.BORDER2};border-radius:7px;padding:9px 12px;color:${P.WHITE};font-size:13px;outline:none;font-family:'Noto Sans Devanagari',sans-serif}
.inp:focus{border-color:${P.PURPLE}66}
select.inp option{background:${P.CARD2}}
.tag{display:inline-flex;align-items:center;padding:2px 9px;border-radius:4px;font-size:10px;font-weight:700;font-family:sans-serif}
textarea.inp{resize:vertical;min-height:80px}
::-webkit-scrollbar{width:3px;height:3px}
::-webkit-scrollbar-thumb{background:${P.BORDER2};border-radius:3px}
`;

function Toast({ msg, type }) {
  const col = { success:P.GREEN, error:P.R, warn:P.GOLD, info:P.BLUE }[type]||P.GREEN;
  return msg ? <div style={{ position:"fixed",bottom:24,right:24,background:col,color:"#fff",padding:"10px 20px",borderRadius:8,fontSize:12,fontFamily:"sans-serif",fontWeight:700,zIndex:9999,boxShadow:"0 4px 24px #0009",animation:"slideUp .3s" }}>{msg}</div> : null;
}
function SectionHead({ icon, label, color, sub }) {
  return (
    <div style={{ borderLeft:`3px solid ${color||P.GOLD}`,paddingLeft:12,marginBottom:20 }}>
      <div style={{ fontSize:16,fontWeight:700,color:P.WHITE }}>{icon} {label}</div>
      {sub && <div style={{ fontSize:11,color:P.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{sub}</div>}
    </div>
  );
}
function Card({ children, style }) {
  return <div style={{ background:P.CARD,border:`1px solid ${P.BORDER}`,borderRadius:10,padding:18,...style }}>{children}</div>;
}
function StatBox({ icon, label, value, sub, color, trend }) {
  return (
    <Card style={{ padding:"16px 18px" }}>
      <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start" }}>
        <span style={{ fontSize:20 }}>{icon}</span>
        {trend && <span style={{ fontSize:11,fontFamily:"sans-serif",color:trend>0?P.GREEN:P.R,fontWeight:600 }}>{trend>0?"↑":"↓"}{Math.abs(trend)}%</span>}
      </div>
      <div style={{ fontSize:24,fontWeight:700,color:color||P.WHITE,fontFamily:"sans-serif",marginTop:8,marginBottom:2 }}>{value}</div>
      <div style={{ fontSize:12,fontWeight:600,color:P.WHITE }}>{label}</div>
      {sub && <div style={{ fontSize:10,color:P.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{sub}</div>}
    </Card>
  );
}
function Toggle({ val, onChange, color }) {
  return (
    <div onClick={()=>onChange(!val)} style={{ width:40,height:22,borderRadius:11,background:val?(color||P.GREEN):P.BORDER2,position:"relative",cursor:"pointer",transition:"background .2s",flexShrink:0 }}>
      <div style={{ width:16,height:16,borderRadius:"50%",background:P.WHITE,position:"absolute",top:3,left:val?21:3,transition:"left .2s",boxShadow:"0 1px 4px #0004" }}></div>
    </div>
  );
}
function Badge({ text, color }) {
  return <span className="tag" style={{ background:(color||P.MUTED)+"22",color:color||P.MUTED,border:`1px solid ${(color||P.MUTED)}33` }}>{text}</span>;
}
function Spinner() {
  return <div style={{ width:16,height:16,border:`2px solid ${P.BORDER2}`,borderTopColor:P.PURPLE,borderRadius:"50%",animation:"spin .7s linear infinite",display:"inline-block" }}></div>;
}

/* ══════════════ AI MODULE ══════════════ */
function AIModule() {
  const [mode, setMode] = useState("headline");
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [autoTasks, setAutoTasks] = useState([
    { id:1, name:"Auto SEO Tags", desc:"हर खबर पर AI auto-tags लगाएगा", active:true },
    { id:2, name:"Breaking Detector", desc:"Keywords से breaking news auto-detect", active:true },
    { id:3, name:"Duplicate Check", desc:"नई खबर पोस्ट से पहले duplicate scan", active:false },
    { id:4, name:"Hindi Spell Check", desc:"AI-powered हिन्दी grammar correction", active:true },
    { id:5, name:"Auto Summary", desc:"लंबी खबरों का 2-line auto-summary", active:false },
    { id:6, name:"Sentiment Analysis", desc:"खबर का tone positive/negative detect करे", active:true },
  ]);

  const MODES = [
    { id:"headline", label:"📰 Headline", prompt:"Write 5 compelling Hindi news headlines about: " },
    { id:"summary",  label:"📝 Summary",  prompt:"Write a crisp 3-line Hindi news summary about: " },
    { id:"seo",      label:"🔍 SEO Tags", prompt:"Generate 10 Hindi SEO keywords and meta description for news about: " },
    { id:"social",   label:"📱 Social",  prompt:"Write a viral Hindi social media post (Twitter/WhatsApp) for news: " },
    { id:"push",     label:"🔔 Push",    prompt:"Write a short, punchy Hindi push notification (max 80 chars) for: " },
  ];

  const callAI = async () => {
    if (!prompt.trim()) return;
    setLoading(true); setResult("");
    const mode_obj = MODES.find(m=>m.id===mode);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          system:"You are a Hindi news content AI for Delhinama, a Delhi-based digital news portal. Generate high-quality Hindi content. Be concise, impactful, and journalistically sound. Always respond in Hindi (Devanagari script).",
          messages:[{ role:"user", content:`${mode_obj.prompt}${prompt}` }]
        })
      });
      const data = await res.json();
      setResult(data.content?.[0]?.text || "कोई result नहीं मिला");
    } catch { setResult("❌ AI से connect नहीं हो सका। Please retry करें।"); }
    setLoading(false);
  };

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="🤖" label="AI Automation" color={P.PURPLE} sub="Anthropic Claude powered — हिन्दी content generation & automation" />

      <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:18 }}>
        {/* Left: AI Content Generator */}
        <div>
          <Card style={{ marginBottom:16 }}>
            <div style={{ fontSize:13,fontWeight:700,color:P.WHITE,marginBottom:14 }}>✍️ AI Content Generator</div>
            {/* Mode selector */}
            <div style={{ display:"flex",gap:6,flexWrap:"wrap",marginBottom:14 }}>
              {MODES.map(m=>(
                <button key={m.id} className="btn" onClick={()=>setMode(m.id)} style={{ background:mode===m.id?P.PURPLE:P.CARD2,color:mode===m.id?P.WHITE:P.MUTED,border:`1px solid ${mode===m.id?P.PURPLE:P.BORDER2}`,fontSize:11,padding:"5px 12px" }}>{m.label}</button>
              ))}
            </div>
            <div style={{ marginBottom:12 }}>
              <label style={{ fontSize:11,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:6 }}>TOPIC / KEYWORDS</label>
              <textarea className="inp" value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="खबर का topic लिखें... जैसे: दिल्ली AQI प्रदूषण NGT आदेश" />
            </div>
            <button className="btn btn-p" onClick={callAI} disabled={loading} style={{ display:"flex",alignItems:"center",gap:8,opacity:loading?.7:1 }}>
              {loading?<><Spinner/> Generate हो रहा है...</>:"✨ AI से Generate करें"}
            </button>

            {result && (
              <div style={{ marginTop:16,background:P.PURPLE+"11",border:`1px solid ${P.PURPLE}33`,borderRadius:8,padding:14,animation:"slideUp .3s" }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:8 }}>
                  <span style={{ fontSize:11,fontWeight:700,color:P.PURPLE,fontFamily:"sans-serif" }}>AI RESULT</span>
                  <button className="btn btn-ghost" onClick={()=>navigator.clipboard?.writeText(result)} style={{ fontSize:10,padding:"3px 10px" }}>📋 Copy</button>
                </div>
                <pre style={{ fontSize:13,color:P.WHITE,lineHeight:1.7,whiteSpace:"pre-wrap",fontFamily:"'Noto Sans Devanagari',sans-serif" }}>{result}</pre>
              </div>
            )}
          </Card>
        </div>

        {/* Right: Automation Tasks */}
        <div>
          <Card>
            <div style={{ fontSize:13,fontWeight:700,color:P.WHITE,marginBottom:14 }}>⚙️ Auto Tasks</div>
            {autoTasks.map(t=>(
              <div key={t.id} style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",padding:"10px 0",borderBottom:`1px solid ${P.BORDER}` }}>
                <div style={{ flex:1,marginRight:12 }}>
                  <div style={{ fontSize:12,fontWeight:600,color:P.WHITE }}>{t.name}</div>
                  <div style={{ fontSize:11,color:P.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{t.desc}</div>
                </div>
                <Toggle val={t.active} color={P.PURPLE} onChange={v=>setAutoTasks(ts=>ts.map(x=>x.id===t.id?{...x,active:v}:x))} />
              </div>
            ))}
          </Card>

          <Card style={{ marginTop:14,background:`linear-gradient(135deg, ${P.PURPLE}11 0%, ${P.CARD} 100%)`,border:`1px solid ${P.PURPLE}33` }}>
            <div style={{ fontSize:12,fontWeight:700,color:P.PURPLE,marginBottom:10 }}>📊 AI Stats (Today)</div>
            {[
              { l:"Headlines Generated", v:"48" },
              { l:"SEO Tags Applied", v:"31" },
              { l:"Duplicates Blocked", v:"7" },
              { l:"Auto-Summaries", v:"22" },
            ].map(s=>(
              <div key={s.l} style={{ display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:`1px solid ${P.BORDER}`,fontSize:12 }}>
                <span style={{ color:P.MUTED,fontFamily:"sans-serif" }}>{s.l}</span>
                <span style={{ color:P.WHITE,fontWeight:700,fontFamily:"sans-serif" }}>{s.v}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ SECURITY MODULE ══════════════ */
function SecurityModule() {
  const [rules, setRules] = useState(CF_RULES);
  const [showAddRule, setShowAddRule] = useState(false);
  const [newRule, setNewRule] = useState({ name:"", type:"Block", expression:"" });
  const [ddosLevel, setDdosLevel] = useState("medium");
  const [sslMode, setSslMode] = useState("full");
  const [blockedIPs, setBlockedIPs] = useState(["103.21.244.0","198.41.128.0","141.101.64.0"]);
  const [newIP, setNewIP] = useState("");

  const threatData = [
    { h:"00", threats:12 },{ h:"03", threats:4 },{ h:"06", threats:28 },
    { h:"09", threats:67 },{ h:"12", threats:142 },{ h:"15", threats:89 },
    { h:"18", threats:54 },{ h:"21", threats:31 },
  ];

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="🛡️" label="Cloudflare Security" color={P.BLUE} sub="WAF · DDoS Protection · SSL · Firewall Rules · IP Management" />

      {/* Status Strip */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        {[
          { icon:"🛡️", label:"WAF Status", value:"Active", color:P.GREEN },
          { icon:"⚡", label:"DDoS", value:"Protected", color:P.GREEN },
          { icon:"🔒", label:"SSL", value:"Full (Strict)", color:P.TEAL },
          { icon:"🚫", label:"Threats Blocked", value:"1,284", color:P.R },
        ].map(s=><StatBox key={s.label} {...s} />)}
      </div>

      <div style={{ display:"grid",gridTemplateColumns:"2fr 1fr",gap:18 }}>
        <div>
          {/* WAF Rules */}
          <Card style={{ marginBottom:16 }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
              <div style={{ fontSize:13,fontWeight:700 }}>🔥 Firewall Rules</div>
              <button className="btn btn-b" onClick={()=>setShowAddRule(!showAddRule)} style={{ fontSize:11,padding:"5px 12px" }}>+ Add Rule</button>
            </div>

            {showAddRule && (
              <div style={{ background:P.CARD2,borderRadius:8,padding:14,marginBottom:14,border:`1px solid ${P.BLUE}44`,animation:"slideUp .2s" }}>
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10 }}>
                  <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>RULE NAME</label><input className="inp" value={newRule.name} onChange={e=>setNewRule({...newRule,name:e.target.value})} placeholder="Rule name..." /></div>
                  <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>ACTION</label>
                    <select className="inp" value={newRule.type} onChange={e=>setNewRule({...newRule,type:e.target.value})}>
                      <option>Block</option><option>Allow</option><option>Rate Limit</option><option>Challenge</option>
                    </select>
                  </div>
                  <div style={{ gridColumn:"1/-1" }}><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>EXPRESSION</label><input className="inp" value={newRule.expression} onChange={e=>setNewRule({...newRule,expression:e.target.value})} placeholder="cf.threat_score > 50" /></div>
                </div>
                <div style={{ display:"flex",gap:8 }}>
                  <button className="btn btn-b" onClick={()=>{ if(newRule.name&&newRule.expression){ setRules(r=>[...r,{...newRule,id:Date.now(),hits:0,status:true}]); setNewRule({name:"",type:"Block",expression:""}); setShowAddRule(false); }}}>Save Rule</button>
                  <button className="btn btn-ghost" onClick={()=>setShowAddRule(false)}>Cancel</button>
                </div>
              </div>
            )}

            {rules.map((r,i)=>(
              <div key={r.id} className="rh" style={{ display:"flex",alignItems:"center",gap:10,padding:"10px 0",borderBottom:i<rules.length-1?`1px solid ${P.BORDER}`:"none",transition:"background .15s" }}>
                <Toggle val={r.status} color={P.BLUE} onChange={v=>setRules(rs=>rs.map(x=>x.id===r.id?{...x,status:v}:x))} />
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ fontSize:12,fontWeight:600,color:P.WHITE }}>{r.name}</div>
                  <div style={{ fontSize:10,color:P.MUTED,fontFamily:"monospace",marginTop:2 }}>{r.expression}</div>
                </div>
                <Badge text={r.type} color={r.type==="Block"?P.R:r.type==="Allow"?P.GREEN:P.GOLD} />
                <span style={{ fontSize:11,color:P.MUTED,fontFamily:"sans-serif",whiteSpace:"nowrap" }}>{r.hits.toLocaleString()} hits</span>
                <button className="btn btn-ghost" onClick={()=>setRules(rs=>rs.filter(x=>x.id!==r.id))} style={{ fontSize:10,padding:"3px 8px",color:P.R,borderColor:P.R+"44" }}>✕</button>
              </div>
            ))}
          </Card>

          {/* Threat chart */}
          <Card>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📊 Threats (Last 24h)</div>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={threatData}>
                <defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={P.R} stopOpacity={.3}/><stop offset="95%" stopColor={P.R} stopOpacity={0}/></linearGradient></defs>
                <XAxis dataKey="h" tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background:P.CARD2,border:`1px solid ${P.BORDER2}`,borderRadius:6,fontSize:11 }} />
                <Area type="monotone" dataKey="threats" stroke={P.R} fill="url(#tg)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Right panel */}
        <div>
          {/* SSL Mode */}
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:12 }}>🔒 SSL Mode</div>
            {["off","flexible","full","strict"].map(m=>(
              <div key={m} onClick={()=>setSslMode(m)} style={{ display:"flex",alignItems:"center",gap:10,padding:"8px 10px",borderRadius:6,cursor:"pointer",marginBottom:4,background:sslMode===m?P.TEAL+"22":"transparent",border:`1px solid ${sslMode===m?P.TEAL+"44":P.BORDER}` }}>
                <div style={{ width:14,height:14,borderRadius:"50%",border:`2px solid ${sslMode===m?P.TEAL:P.BORDER2}`,background:sslMode===m?P.TEAL:"transparent",flexShrink:0 }}></div>
                <span style={{ fontSize:12,color:sslMode===m?P.WHITE:P.MUTED,textTransform:"capitalize",fontFamily:"sans-serif" }}>{m}</span>
              </div>
            ))}
          </Card>

          {/* DDoS Level */}
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:12 }}>⚡ DDoS Protection</div>
            {["low","medium","high","i'm under attack"].map(l=>(
              <div key={l} onClick={()=>setDdosLevel(l)} style={{ display:"flex",alignItems:"center",gap:10,padding:"8px 10px",borderRadius:6,cursor:"pointer",marginBottom:4,background:ddosLevel===l?P.BLUE+"22":"transparent",border:`1px solid ${ddosLevel===l?P.BLUE+"44":P.BORDER}` }}>
                <div style={{ width:14,height:14,borderRadius:"50%",border:`2px solid ${ddosLevel===l?P.BLUE:P.BORDER2}`,background:ddosLevel===l?P.BLUE:"transparent",flexShrink:0 }}></div>
                <span style={{ fontSize:12,color:ddosLevel===l?P.WHITE:P.MUTED,textTransform:"capitalize",fontFamily:"sans-serif" }}>{l}</span>
              </div>
            ))}
          </Card>

          {/* Block IPs */}
          <Card>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:12 }}>🚫 IP Blocklist</div>
            <div style={{ display:"flex",gap:8,marginBottom:12 }}>
              <input className="inp" value={newIP} onChange={e=>setNewIP(e.target.value)} placeholder="IP Address..." style={{ flex:1 }} />
              <button className="btn btn-r" onClick={()=>{ if(newIP.trim()){ setBlockedIPs(b=>[...b,newIP.trim()]); setNewIP(""); }}} style={{ padding:"8px 12px",whiteSpace:"nowrap" }}>Block</button>
            </div>
            {blockedIPs.map((ip,i)=>(
              <div key={i} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:`1px solid ${P.BORDER}`,fontSize:12 }}>
                <span style={{ fontFamily:"monospace",color:P.WHITE }}>{ip}</span>
                <button onClick={()=>setBlockedIPs(b=>b.filter(x=>x!==ip))} style={{ background:"transparent",border:"none",color:P.R,cursor:"pointer",fontSize:14 }}>✕</button>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ INFRA MODULE ══════════════ */
function InfraModule() {
  const [containers, setContainers] = useState([
    { name:"delhinama-web",    image:"node:20-alpine",  status:"running", cpu:"12%", mem:"248MB", uptime:"14d 6h", port:"3000" },
    { name:"delhinama-api",    image:"node:20-alpine",  status:"running", cpu:"8%",  mem:"182MB", uptime:"14d 6h", port:"4000" },
    { name:"postgres-db",      image:"postgres:15",     status:"running", cpu:"3%",  mem:"512MB", uptime:"30d 2h", port:"5432" },
    { name:"redis-cache",      image:"redis:7-alpine",  status:"running", cpu:"1%",  mem:"64MB",  uptime:"30d 2h", port:"6379" },
    { name:"nginx-proxy",      image:"nginx:alpine",    status:"running", cpu:"2%",  mem:"32MB",  uptime:"30d 2h", port:"80/443" },
    { name:"push-worker",      image:"node:20-alpine",  status:"stopped", cpu:"0%",  mem:"0MB",   uptime:"Stopped", port:"5000" },
  ]);

  const serverMetrics = [
    { time:"10:00", cpu:24, mem:61, disk:45 },
    { time:"10:30", cpu:31, mem:63, disk:45 },
    { time:"11:00", cpu:18, mem:59, disk:46 },
    { time:"11:30", cpu:42, mem:67, disk:46 },
    { time:"12:00", cpu:55, mem:71, disk:46 },
    { time:"12:30", cpu:38, mem:68, disk:47 },
    { time:"13:00", cpu:29, mem:64, disk:47 },
  ];

  const toggle = (name) => setContainers(cs=>cs.map(c=>c.name===name?{...c,status:c.status==="running"?"stopped":"running",uptime:c.status==="running"?"Stopped":"Just started",cpu:c.status==="running"?"0%":c.cpu,mem:c.status==="running"?"0MB":c.mem}:c));

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="☁️" label="AWS + Docker Infrastructure" color={P.TEAL} sub="Server Health · Containers · Deployment · Resource Monitor" />

      {/* AWS Summary */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        {[
          { icon:"🖥️", label:"EC2 Instance", value:"t3.medium", sub:"ap-south-1 (Mumbai)", color:P.TEAL },
          { icon:"💾", label:"RDS Storage", value:"128 GB", sub:"PostgreSQL 15.2", color:P.BLUE },
          { icon:"🌐", label:"Bandwidth", value:"2.4 TB", sub:"This month", color:P.GOLD },
          { icon:"💰", label:"AWS Cost", value:"₹8,240", sub:"Estimated monthly", color:P.ORANGE },
        ].map(s=><StatBox key={s.label} {...s} />)}
      </div>

      <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:18 }}>
        <div>
          {/* Docker containers */}
          <Card style={{ marginBottom:16 }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
              <div style={{ fontSize:13,fontWeight:700 }}>🐳 Docker Containers</div>
              <div style={{ display:"flex",gap:6 }}>
                <span style={{ fontSize:11,fontFamily:"sans-serif",color:P.GREEN }}>{containers.filter(c=>c.status==="running").length} running</span>
                <span style={{ color:P.BORDER }}>•</span>
                <span style={{ fontSize:11,fontFamily:"sans-serif",color:P.R }}>{containers.filter(c=>c.status==="stopped").length} stopped</span>
              </div>
            </div>
            {containers.map((c,i)=>(
              <div key={c.name} className="rh" style={{ display:"flex",alignItems:"center",gap:10,padding:"10px 0",borderBottom:i<containers.length-1?`1px solid ${P.BORDER}`:"none" }}>
                <span style={{ width:8,height:8,borderRadius:"50%",background:c.status==="running"?P.GREEN:P.R,flexShrink:0,animation:c.status==="running"?"pulse 2s infinite":"none" }}></span>
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ fontSize:12,fontWeight:600,color:P.WHITE,fontFamily:"monospace" }}>{c.name}</div>
                  <div style={{ fontSize:10,color:P.MUTED,fontFamily:"monospace",marginTop:1 }}>{c.image} • :{c.port}</div>
                </div>
                <div style={{ textAlign:"center",minWidth:50 }}>
                  <div style={{ fontSize:11,fontWeight:600,color:P.WHITE,fontFamily:"sans-serif" }}>{c.cpu}</div>
                  <div style={{ fontSize:9,color:P.MUTED,fontFamily:"sans-serif" }}>CPU</div>
                </div>
                <div style={{ textAlign:"center",minWidth:60 }}>
                  <div style={{ fontSize:11,fontWeight:600,color:P.WHITE,fontFamily:"sans-serif" }}>{c.mem}</div>
                  <div style={{ fontSize:9,color:P.MUTED,fontFamily:"sans-serif" }}>MEM</div>
                </div>
                <div style={{ textAlign:"center",minWidth:70 }}>
                  <div style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif" }}>{c.uptime}</div>
                </div>
                <button onClick={()=>toggle(c.name)} className="btn" style={{ fontSize:10,padding:"4px 10px",background:c.status==="running"?P.R+"22":P.GREEN+"22",color:c.status==="running"?P.R:P.GREEN,border:`1px solid ${c.status==="running"?P.R+"44":P.GREEN+"44"}` }}>
                  {c.status==="running"?"⏹ Stop":"▶ Start"}
                </button>
              </div>
            ))}
          </Card>

          {/* CPU/Memory Chart */}
          <Card>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📈 Server Metrics (Last 3h)</div>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={serverMetrics}>
                <CartesianGrid strokeDasharray="3 3" stroke={P.BORDER} />
                <XAxis dataKey="time" tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} unit="%" />
                <Tooltip contentStyle={{ background:P.CARD2,border:`1px solid ${P.BORDER2}`,borderRadius:6,fontSize:11 }} />
                <Line type="monotone" dataKey="cpu" stroke={P.TEAL} strokeWidth={2} dot={false} name="CPU" />
                <Line type="monotone" dataKey="mem" stroke={P.PURPLE} strokeWidth={2} dot={false} name="Memory" />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Right: Deploy + Logs */}
        <div>
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>🚀 Deploy Pipeline</div>
            {[
              { step:"Code Push (GitHub)", status:"done", time:"13:42" },
              { step:"Docker Build", status:"done", time:"13:44" },
              { step:"Tests Run", status:"done", time:"13:45" },
              { step:"Push to ECR", status:"done", time:"13:46" },
              { step:"ECS Deploy", status:"running", time:"13:47" },
              { step:"Health Check", status:"pending", time:"—" },
            ].map((s,i)=>(
              <div key={i} style={{ display:"flex",alignItems:"center",gap:10,padding:"7px 0",borderBottom:i<5?`1px solid ${P.BORDER}`:"none" }}>
                <span style={{ fontSize:14 }}>{s.status==="done"?"✅":s.status==="running"?"⏳":"⬜"}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:12,color:s.status==="done"?P.WHITE:s.status==="running"?P.GOLD:P.MUTED }}>{s.step}</div>
                </div>
                <span style={{ fontSize:10,color:P.MUTED,fontFamily:"monospace" }}>{s.time}</span>
              </div>
            ))}
            <button className="btn btn-b" style={{ width:"100%",marginTop:14 }}>🔄 Redeploy</button>
          </Card>

          <Card>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:12 }}>📋 Live Logs</div>
            <div style={{ background:"#000",borderRadius:6,padding:12,fontFamily:"monospace",fontSize:10,color:"#4ade80",lineHeight:1.8,maxHeight:160,overflowY:"auto" }}>
              <div><span style={{ color:P.MUTED }}>13:47:02</span> [INFO] ECS task deploying...</div>
              <div><span style={{ color:P.MUTED }}>13:46:58</span> [SUCCESS] Image pushed to ECR</div>
              <div><span style={{ color:P.MUTED }}>13:46:12</span> [INFO] Tests passed (42/42)</div>
              <div><span style={{ color:P.MUTED }}>13:44:31</span> [INFO] Docker build complete</div>
              <div><span style={{ color:"#facc15" }}>13:44:02</span> [WARN] Memory usage 71%</div>
              <div><span style={{ color:P.MUTED }}>13:42:10</span> [INFO] Push from main branch</div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ THEME MODULE ══════════════ */
function ThemeModule({ theme, setTheme }) {
  const presets = [
    { name:"Delhinama Classic", primary:"#C41E28", accent:"#C8962E", bg:"#060608", font:"Noto Sans Devanagari" },
    { name:"Midnight Blue",     primary:"#1D4ED8", accent:"#60A5FA", bg:"#020817", font:"Noto Sans Devanagari" },
    { name:"Forest Green",      primary:"#16A34A", accent:"#4ADE80", bg:"#020a05", font:"Noto Sans Devanagari" },
    { name:"Royal Purple",      primary:"#7C3AED", accent:"#C084FC", bg:"#07020e", font:"Noto Sans Devanagari" },
    { name:"Sunset Orange",     primary:"#EA580C", accent:"#FB923C", bg:"#090503", font:"Noto Sans Devanagari" },
    { name:"Delhinama Light",   primary:"#C41E28", accent:"#C8962E", bg:"#F8F9FA", font:"Noto Sans Devanagari" },
  ];

  const layouts = [
    { id:"grid",     label:"Grid Layout",      desc:"3-column editorial grid" },
    { id:"magazine", label:"Magazine Layout",  desc:"Hero + sidebar + cards" },
    { id:"list",     label:"List Layout",      desc:"Vertical news feed" },
    { id:"compact",  label:"Compact Layout",   desc:"Dense content, small cards" },
  ];

  const fonts = ["Noto Sans Devanagari","Noto Serif Devanagari","Mukta","Hind","Baloo 2","Rajdhani"];

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="🎨" label="Theme & Layout Control" color={P.PINK} sub="Website ka look admin panel se change karein — live preview ke saath" />

      <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:18 }}>
        <div>
          {/* Color Presets */}
          <Card style={{ marginBottom:16 }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>🎨 Color Themes</div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16 }}>
              {presets.map(pr=>(
                <div key={pr.name} onClick={()=>setTheme({...theme,...pr})} style={{ border:`2px solid ${theme.name===pr.name?pr.primary:P.BORDER}`,borderRadius:8,padding:"12px 14px",cursor:"pointer",background:pr.bg,transition:"border-color .2s" }}>
                  <div style={{ display:"flex",gap:6,marginBottom:8 }}>
                    <div style={{ width:20,height:20,borderRadius:"50%",background:pr.primary }}></div>
                    <div style={{ width:20,height:20,borderRadius:"50%",background:pr.accent }}></div>
                    <div style={{ width:20,height:20,borderRadius:"50%",background:pr.bg,border:"1px solid #fff3" }}></div>
                  </div>
                  <div style={{ fontSize:12,fontWeight:600,color:"#fff" }}>{pr.name}</div>
                </div>
              ))}
            </div>

            {/* Custom Colors */}
            <div style={{ fontSize:12,fontWeight:700,color:P.WHITE,marginBottom:12 }}>✏️ Custom Colors</div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10 }}>
              {[
                { label:"Primary Color", key:"primary" },
                { label:"Accent/Gold",   key:"accent" },
                { label:"Background",    key:"bg" },
              ].map(f=>(
                <div key={f.key}>
                  <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:5 }}>{f.label.toUpperCase()}</label>
                  <div style={{ display:"flex",gap:8,alignItems:"center" }}>
                    <input type="color" value={theme[f.key]||"#ffffff"} onChange={e=>setTheme({...theme,[f.key]:e.target.value,name:"Custom"})} style={{ width:36,height:36,borderRadius:6,border:"none",cursor:"pointer",background:"transparent" }} />
                    <input className="inp" value={theme[f.key]||""} onChange={e=>setTheme({...theme,[f.key]:e.target.value,name:"Custom"})} style={{ fontFamily:"monospace",fontSize:11 }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Layout */}
          <Card>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📐 Homepage Layout</div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
              {layouts.map(l=>(
                <div key={l.id} onClick={()=>setTheme({...theme,layout:l.id})} style={{ border:`2px solid ${theme.layout===l.id?P.PINK:P.BORDER}`,borderRadius:8,padding:14,cursor:"pointer",transition:"border-color .2s",background:theme.layout===l.id?P.PINK+"11":P.CARD2 }}>
                  <div style={{ fontSize:18,marginBottom:6 }}>
                    {{"grid":"▦","magazine":"▤","list":"☰","compact":"⊞"}[l.id]}
                  </div>
                  <div style={{ fontSize:12,fontWeight:700,color:P.WHITE }}>{l.label}</div>
                  <div style={{ fontSize:10,color:P.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{l.desc}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right: Typography + Live Preview */}
        <div>
          <Card style={{ marginBottom:14 }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>🔤 Typography</div>
            <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:6 }}>HINDI FONT</label>
            <div style={{ display:"flex",flexDirection:"column",gap:6,marginBottom:14 }}>
              {fonts.map(f=>(
                <div key={f} onClick={()=>setTheme({...theme,font:f})} style={{ display:"flex",alignItems:"center",gap:10,padding:"8px 12px",borderRadius:6,cursor:"pointer",border:`1px solid ${theme.font===f?P.PINK:P.BORDER}`,background:theme.font===f?P.PINK+"11":"transparent" }}>
                  <div style={{ width:14,height:14,borderRadius:"50%",border:`2px solid ${theme.font===f?P.PINK:P.BORDER2}`,background:theme.font===f?P.PINK:"transparent",flexShrink:0 }}></div>
                  <span style={{ fontSize:13,color:P.WHITE }}>{f}</span>
                </div>
              ))}
            </div>

            {/* Font size slider */}
            <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:6 }}>BASE FONT SIZE: {theme.fontSize||16}px</label>
            <input type="range" min={13} max={20} value={theme.fontSize||16} onChange={e=>setTheme({...theme,fontSize:Number(e.target.value)})} style={{ width:"100%",accentColor:P.PINK }} />
          </Card>

          {/* Live Mini Preview */}
          <Card style={{ border:`1px solid ${theme.primary||P.R}44` }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:12 }}>👁 Live Preview</div>
            <div style={{ background:theme.bg||P.BG,borderRadius:8,padding:12,border:`1px solid ${P.BORDER}` }}>
              {/* Mini header */}
              <div style={{ background:theme.primary||P.R,borderRadius:5,padding:"5px 10px",marginBottom:8,fontSize:10,fontWeight:700,color:"#fff" }}>
                दिल्लीनामा — Breaking News Ticker
              </div>
              {/* Mini nav */}
              <div style={{ display:"flex",gap:6,marginBottom:8 }}>
                {["होम","देश","दिल्ली","राजनीति"].map(c=>(
                  <span key={c} style={{ fontSize:9,padding:"2px 7px",borderRadius:3,background:theme.primary||P.R,color:"#fff" }}>{c}</span>
                ))}
              </div>
              {/* Mini card */}
              <div style={{ background:P.CARD,border:`1px solid ${theme.accent||P.GOLD}33`,borderRadius:5,padding:8 }}>
                <div style={{ fontSize:8,color:theme.primary||P.R,fontWeight:700,marginBottom:3 }}>ब्रेकिंग • दिल्ली</div>
                <div style={{ fontSize:10,color:"#fff",lineHeight:1.4 }}>दिल्ली का AQI 412 पार — NGT का आदेश जारी</div>
              </div>
            </div>
            <div style={{ marginTop:12,fontSize:11,color:P.MUTED,fontFamily:"sans-serif",textAlign:"center" }}>
              Theme: <span style={{ color:P.WHITE }}>{theme.name||"Custom"}</span> • Layout: <span style={{ color:P.WHITE }}>{theme.layout||"grid"}</span>
            </div>
          </Card>

          <button className="btn btn-g" style={{ width:"100%",marginTop:12 }} onClick={async()=>{ await dbSet("dnh:theme",theme); }}>
            💾 Theme Save करें
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ ADS MODULE ══════════════ */
function AdsModule() {
  const [ads, setAds] = useState(SEED_ADS);
  const [addOpen, setAddOpen] = useState(false);
  const [newAd, setNewAd] = useState({ name:"", slot:"Hero Banner", client:"", start:"", end:"" });
  const AD_SLOTS = ["Hero Banner","Sidebar Right","In-Article","Footer","Breaking Bar","Video Pre-roll","Mobile Sticky"];

  const totalRev = ads.reduce((s,a)=>s+a.rev,0);
  const totalImp = ads.reduce((s,a)=>s+a.impressions,0);
  const totalClk = ads.reduce((s,a)=>s+a.clicks,0);

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="💰" label="Ads Manager" color={P.GOLD} sub="Ad Campaigns · Slots · Revenue · CTR Tracking" />

      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        <StatBox icon="💰" label="Total Revenue" value={`₹${totalRev.toLocaleString()}`} sub="This month" color={P.GOLD} trend={12} />
        <StatBox icon="👁" label="Impressions" value={`${(totalImp/1000).toFixed(0)}K`} sub="All campaigns" color={P.WHITE} trend={8} />
        <StatBox icon="🖱️" label="Total Clicks" value={totalClk.toLocaleString()} sub="All campaigns" color={P.TEAL} trend={5} />
        <StatBox icon="📊" label="Avg. CTR" value={`${((totalClk/totalImp)*100).toFixed(2)}%`} sub="Click-through rate" color={P.GREEN} trend={-2} />
      </div>

      {/* Slot Map */}
      <Card style={{ marginBottom:16 }}>
        <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📍 Ad Slot Map</div>
        <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10 }}>
          {AD_SLOTS.map(slot=>{
            const filled = ads.some(a=>a.slot===slot&&a.status==="active");
            return (
              <div key={slot} style={{ border:`1.5px dashed ${filled?P.GOLD+"66":P.BORDER2}`,borderRadius:8,padding:12,textAlign:"center",background:filled?P.GOLD+"0d":"transparent" }}>
                <div style={{ fontSize:18,marginBottom:6 }}>{filled?"📢":"📭"}</div>
                <div style={{ fontSize:11,fontWeight:600,color:filled?P.GOLD:P.MUTED }}>{slot}</div>
                <div style={{ fontSize:10,color:filled?P.GREEN:P.MUTED,marginTop:3,fontFamily:"sans-serif" }}>{filled?"● Filled":"○ Available"}</div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Campaigns Table */}
      <Card>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
          <div style={{ fontSize:13,fontWeight:700 }}>📋 Active Campaigns</div>
          <button className="btn btn-ghost" onClick={()=>setAddOpen(!addOpen)} style={{ fontSize:11 }}>+ New Campaign</button>
        </div>

        {addOpen && (
          <div style={{ background:P.CARD2,borderRadius:8,padding:14,marginBottom:14,border:`1px solid ${P.GOLD}44`,animation:"slideUp .2s" }}>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
              <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>CAMPAIGN NAME</label><input className="inp" value={newAd.name} onChange={e=>setNewAd({...newAd,name:e.target.value})} placeholder="Campaign name" /></div>
              <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>CLIENT</label><input className="inp" value={newAd.client} onChange={e=>setNewAd({...newAd,client:e.target.value})} placeholder="Client name" /></div>
              <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>AD SLOT</label><select className="inp" value={newAd.slot} onChange={e=>setNewAd({...newAd,slot:e.target.value})}>{AD_SLOTS.map(s=><option key={s}>{s}</option>)}</select></div>
              <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>START DATE</label><input type="date" className="inp" value={newAd.start} onChange={e=>setNewAd({...newAd,start:e.target.value})} /></div>
            </div>
            <div style={{ display:"flex",gap:8,marginTop:10 }}>
              <button className="btn btn-ghost" style={{ fontSize:11,color:P.GOLD,borderColor:P.GOLD+"44" }} onClick={()=>{ if(newAd.name&&newAd.client){ setAds(a=>[...a,{...newAd,id:Date.now(),status:"active",impressions:0,clicks:0,ctr:0,rev:0,end:newAd.start}]); setNewAd({name:"",slot:"Hero Banner",client:"",start:"",end:""}); setAddOpen(false); }}}>✓ Add</button>
              <button className="btn btn-ghost" onClick={()=>setAddOpen(false)} style={{ fontSize:11 }}>Cancel</button>
            </div>
          </div>
        )}

        {ads.map((ad,i)=>(
          <div key={ad.id} className="rh" style={{ padding:"12px 0",borderBottom:i<ads.length-1?`1px solid ${P.BORDER}`:"none",display:"flex",alignItems:"center",gap:12 }}>
            <div style={{ flex:1,minWidth:0 }}>
              <div style={{ fontSize:12,fontWeight:600,color:P.WHITE }}>{ad.name}</div>
              <div style={{ fontSize:10,color:P.MUTED,marginTop:2,fontFamily:"sans-serif" }}>{ad.client} • {ad.slot} • {ad.start}→{ad.end}</div>
            </div>
            <div style={{ textAlign:"right",minWidth:70 }}>
              <div style={{ fontSize:12,fontWeight:700,color:P.GOLD,fontFamily:"sans-serif" }}>₹{ad.rev.toLocaleString()}</div>
              <div style={{ fontSize:9,color:P.MUTED,fontFamily:"sans-serif" }}>Revenue</div>
            </div>
            <div style={{ textAlign:"right",minWidth:60 }}>
              <div style={{ fontSize:12,fontWeight:600,color:P.WHITE,fontFamily:"sans-serif" }}>{(ad.impressions/1000).toFixed(0)}K</div>
              <div style={{ fontSize:9,color:P.MUTED,fontFamily:"sans-serif" }}>Impr.</div>
            </div>
            <div style={{ textAlign:"right",minWidth:50 }}>
              <div style={{ fontSize:12,fontWeight:600,color:P.TEAL,fontFamily:"sans-serif" }}>{ad.ctr}%</div>
              <div style={{ fontSize:9,color:P.MUTED,fontFamily:"sans-serif" }}>CTR</div>
            </div>
            <button onClick={()=>setAds(a=>a.map(x=>x.id===ad.id?{...x,status:x.status==="active"?"paused":"active"}:x))} className="btn" style={{ fontSize:10,padding:"4px 10px",background:ad.status==="active"?P.GREEN+"22":P.GOLD+"22",color:ad.status==="active"?P.GREEN:P.GOLD,border:`1px solid ${ad.status==="active"?P.GREEN+"44":P.GOLD+"44"}` }}>
              {ad.status==="active"?"⏸ Pause":"▶ Resume"}
            </button>
            <button className="btn btn-ghost" onClick={()=>setAds(a=>a.filter(x=>x.id!==ad.id))} style={{ fontSize:10,padding:"4px 8px",color:P.R,borderColor:P.R+"44" }}>✕</button>
          </div>
        ))}
      </Card>
    </div>
  );
}

/* ══════════════ REELS MODULE ══════════════ */
function ReelsModule() {
  const [reels, setReels] = useState(SEED_REELS);
  const [addOpen, setAddOpen] = useState(false);
  const [newReel, setNewReel] = useState({ title:"", category:"दिल्ली", duration:"0:30", status:"draft" });
  const CATS = ["देश","विदेश","राजनीति","दिल्ली","बाजार","मनोरंजन","विशेष"];

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="🎬" label="Reels Control" color={P.ORANGE} sub="Short Videos · Upload · Manage · Analytics" />

      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        <StatBox icon="🎬" label="Total Reels" value={reels.length} sub={`${reels.filter(r=>r.status==="published").length} live`} color={P.ORANGE} />
        <StatBox icon="👁" label="Total Views" value={`${(reels.reduce((s,r)=>s+r.views,0)/1000).toFixed(0)}K`} color={P.WHITE} trend={22} />
        <StatBox icon="❤️" label="Total Likes" value={reels.reduce((s,r)=>s+r.likes,0).toLocaleString()} color={P.PINK} trend={18} />
        <StatBox icon="⏱" label="Avg Duration" value="0:55" sub="seconds" color={P.TEAL} />
      </div>

      <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
        <div style={{ fontSize:13,fontWeight:700,color:P.WHITE }}>🎬 Reel Library</div>
        <button className="btn btn-o" onClick={()=>setAddOpen(!addOpen)}>+ Upload Reel</button>
      </div>

      {addOpen && (
        <Card style={{ marginBottom:16,border:`1px solid ${P.ORANGE}44`,animation:"slideUp .25s" }}>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
            <div style={{ gridColumn:"1/-1" }}><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>TITLE</label><input className="inp" value={newReel.title} onChange={e=>setNewReel({...newReel,title:e.target.value})} placeholder="Reel का शीर्षक..." /></div>
            <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>CATEGORY</label><select className="inp" value={newReel.category} onChange={e=>setNewReel({...newReel,category:e.target.value})}>{CATS.map(c=><option key={c}>{c}</option>)}</select></div>
            <div><label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:4 }}>STATUS</label><select className="inp" value={newReel.status} onChange={e=>setNewReel({...newReel,status:e.target.value})}><option value="published">Published</option><option value="draft">Draft</option></select></div>
            <div style={{ gridColumn:"1/-1",border:`2px dashed ${P.BORDER2}`,borderRadius:8,padding:24,textAlign:"center",cursor:"pointer" }}>
              <div style={{ fontSize:28,marginBottom:6 }}>🎬</div>
              <div style={{ fontSize:12,color:P.MUTED,fontFamily:"sans-serif" }}>Video file drag करें या click करें<br/><span style={{ fontSize:10 }}>MP4, MOV • Max 100MB • 9:16 format</span></div>
            </div>
          </div>
          <div style={{ display:"flex",gap:8,marginTop:12 }}>
            <button className="btn btn-o" onClick={()=>{ if(newReel.title){ setReels(r=>[{...newReel,id:Date.now(),views:0,likes:0,date:new Date().toISOString().slice(0,10),...newReel},...r]); setNewReel({title:"",category:"दिल्ली",duration:"0:30",status:"draft"}); setAddOpen(false); }}}>✓ Upload & Publish</button>
            <button className="btn btn-ghost" onClick={()=>setAddOpen(false)}>Cancel</button>
          </div>
        </Card>
      )}

      <div style={{ display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14 }}>
        {reels.map(r=>(
          <Card key={r.id} style={{ display:"flex",gap:14,alignItems:"flex-start" }}>
            {/* Thumbnail placeholder */}
            <div style={{ width:72,height:106,borderRadius:8,background:`linear-gradient(160deg,${P.ORANGE}33,${P.CARD2})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0,position:"relative" }}>
              🎬
              <div style={{ position:"absolute",bottom:5,right:5,background:"#000a",fontSize:9,color:"#fff",padding:"1px 5px",borderRadius:3,fontFamily:"sans-serif" }}>{r.duration}</div>
            </div>
            <div style={{ flex:1,minWidth:0 }}>
              <Badge text={r.category} color={P.ORANGE} />
              <div style={{ fontSize:13,fontWeight:600,color:P.WHITE,marginTop:6,lineHeight:1.4 }}>{r.title}</div>
              <div style={{ display:"flex",gap:12,marginTop:8,fontSize:11,fontFamily:"sans-serif" }}>
                <span style={{ color:P.MUTED }}>👁 {r.views.toLocaleString()}</span>
                <span style={{ color:P.MUTED }}>❤️ {r.likes.toLocaleString()}</span>
                <span style={{ color:P.MUTED }}>{r.date}</span>
              </div>
              <div style={{ display:"flex",gap:6,marginTop:10 }}>
                <button onClick={()=>setReels(rs=>rs.map(x=>x.id===r.id?{...x,status:x.status==="published"?"draft":"published"}:x))} className="btn" style={{ fontSize:10,padding:"3px 10px",background:r.status==="published"?P.GREEN+"22":P.GOLD+"22",color:r.status==="published"?P.GREEN:P.GOLD,border:`1px solid ${r.status==="published"?P.GREEN+"44":P.GOLD+"44"}` }}>
                  {r.status==="published"?"✓ Live":"Draft"}
                </button>
                <button className="btn btn-ghost" onClick={()=>setReels(rs=>rs.filter(x=>x.id!==r.id))} style={{ fontSize:10,padding:"3px 8px",color:P.R,borderColor:P.R+"44" }}>🗑</button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ══════════════ PUSH NOTIFICATIONS MODULE ══════════════ */
function PushModule() {
  const [notifs, setNotifs] = useState(SEED_PUSH);
  const [form, setForm] = useState({ title:"", body:"", topic:"breaking", url:"", schedule:"now" });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const TOPICS = [
    { id:"breaking", label:"🚨 Breaking News", subs:"2,84,000" },
    { id:"delhi",    label:"📍 Delhi Local",   subs:"1,42,000" },
    { id:"politics", label:"⚡ Politics",      subs:"98,000" },
    { id:"market",   label:"📊 Market",        subs:"64,000" },
    { id:"community",label:"📢 Bole Free",     subs:"1,12,000" },
    { id:"all",      label:"🌐 All Subscribers",subs:"3,24,000" },
  ];

  const doSend = async () => {
    if (!form.title || !form.body) return;
    setSending(true); setSent(false);
    await new Promise(r=>setTimeout(r,1800));
    const topic = TOPICS.find(t=>t.id===form.topic);
    const subsNum = parseInt(topic.subs.replace(/,/g,""));
    const newN = { id:Date.now(), title:form.title, body:form.body, sent:subsNum, opened:Math.round(subsNum*0.22), ctr:22.0, date:new Date().toLocaleString("hi-IN").slice(0,15), topic:form.topic };
    setNotifs(n=>[newN,...n]);
    setForm({ title:"", body:"", topic:"breaking", url:"", schedule:"now" });
    setSending(false); setSent(true);
    setTimeout(()=>setSent(false),3000);
  };

  const charLeft = 80 - form.title.length;

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="🔔" label="Push Notifications" color={P.GREEN} sub="FCM / Web Push — subscribers ko directly khaber bhejein" />

      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        <StatBox icon="🔔" label="Total Subscribers" value="3,24,000" sub="All topics" color={P.GREEN} trend={3} />
        <StatBox icon="📤" label="Sent (Today)" value={notifs.length} color={P.WHITE} />
        <StatBox icon="📖" label="Avg Open Rate" value="22%" sub="Industry avg 10%" color={P.TEAL} trend={12} />
        <StatBox icon="🎯" label="Avg CTR" value="21%" color={P.GOLD} trend={5} />
      </div>

      <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:18 }}>
        {/* Compose */}
        <div>
          <Card style={{ marginBottom:16 }}>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:16,borderLeft:`3px solid ${P.GREEN}`,paddingLeft:10 }}>✍️ नई Notification भेजें</div>

            {/* Topic Selector */}
            <div style={{ marginBottom:14 }}>
              <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:6 }}>TOPIC (किसे भेजनी है)</label>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:6 }}>
                {TOPICS.map(t=>(
                  <div key={t.id} onClick={()=>setForm({...form,topic:t.id})} style={{ border:`1.5px solid ${form.topic===t.id?P.GREEN:P.BORDER}`,borderRadius:7,padding:"8px 12px",cursor:"pointer",background:form.topic===t.id?P.GREEN+"11":"transparent",transition:"all .15s" }}>
                    <div style={{ fontSize:12,fontWeight:600,color:P.WHITE }}>{t.label}</div>
                    <div style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",marginTop:2 }}>{t.subs} subscribers</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ marginBottom:12 }}>
              <div style={{ display:"flex",justifyContent:"space-between",marginBottom:6 }}>
                <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif" }}>TITLE *</label>
                <span style={{ fontSize:10,color:charLeft<10?P.R:P.MUTED,fontFamily:"sans-serif" }}>{charLeft} chars left</span>
              </div>
              <input className="inp" value={form.title} onChange={e=>{ if(e.target.value.length<=80) setForm({...form,title:e.target.value}); }} placeholder="🚨 ब्रेकिंग: खबर का headline..." />
            </div>
            <div style={{ marginBottom:12 }}>
              <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:6 }}>BODY *</label>
              <textarea className="inp" value={form.body} onChange={e=>setForm({...form,body:e.target.value})} placeholder="Notification का विवरण — 2-3 lines..." rows={3} />
            </div>
            <div style={{ marginBottom:16 }}>
              <label style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",display:"block",marginBottom:6 }}>CLICK URL (optional)</label>
              <input className="inp" value={form.url} onChange={e=>setForm({...form,url:e.target.value})} placeholder="https://delhinama.com/article/..." />
            </div>

            {/* Preview */}
            {(form.title||form.body) && (
              <div style={{ background:P.CARD2,border:`1px solid ${P.BORDER2}`,borderRadius:8,padding:14,marginBottom:16,position:"relative" }}>
                <div style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",marginBottom:8 }}>📱 Preview</div>
                <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
                  <div style={{ width:36,height:36,borderRadius:8,background:P.R,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0 }}>📰</div>
                  <div>
                    <div style={{ fontSize:12,fontWeight:700,color:P.WHITE }}>{form.title||"Title..."}</div>
                    <div style={{ fontSize:11,color:P.MUTED,marginTop:3,lineHeight:1.4 }}>{form.body.slice(0,80)||"Body..."}</div>
                    <div style={{ fontSize:10,color:P.MUTED,marginTop:4,fontFamily:"sans-serif" }}>delhinama.com • now</div>
                  </div>
                </div>
              </div>
            )}

            <button className="btn btn-g" onClick={doSend} disabled={sending||!form.title||!form.body} style={{ display:"flex",alignItems:"center",gap:8,opacity:(sending||!form.title||!form.body)?0.6:1 }}>
              {sending?<><Spinner/> भेजी जा रही है...</>:sent?"✅ भेज दी गई!":"🔔 Send Notification"}
            </button>
          </Card>
        </div>

        {/* History */}
        <div>
          <Card>
            <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📜 Notification History</div>
            {notifs.map((n,i)=>(
              <div key={n.id} style={{ padding:"11px 0",borderBottom:i<notifs.length-1?`1px solid ${P.BORDER}`:"none" }}>
                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:5 }}>
                  <div style={{ fontSize:12,fontWeight:600,color:P.WHITE,flex:1,marginRight:8 }}>{n.title}</div>
                  <span style={{ fontSize:9,color:P.GREEN,fontFamily:"sans-serif",fontWeight:700,background:P.GREEN+"22",padding:"1px 6px",borderRadius:3,whiteSpace:"nowrap" }}>Sent</span>
                </div>
                <div style={{ fontSize:11,color:P.MUTED,marginBottom:6,lineHeight:1.4 }}>{n.body}</div>
                <div style={{ display:"flex",gap:12,fontSize:10,fontFamily:"sans-serif" }}>
                  <span style={{ color:P.MUTED }}>📤 {(n.sent/1000).toFixed(0)}K</span>
                  <span style={{ color:P.TEAL }}>📖 {(n.opened/1000).toFixed(0)}K</span>
                  <span style={{ color:P.GOLD }}>CTR {n.ctr}%</span>
                </div>
                <div style={{ fontSize:9,color:P.MUTED,fontFamily:"sans-serif",marginTop:4 }}>{n.date}</div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ ANALYTICS MODULE ══════════════ */
function AnalyticsModule() {
  const [range, setRange] = useState("7d");
  const deviceData = [{ name:"Mobile",value:72,color:P.TEAL },{ name:"Desktop",value:21,color:P.BLUE },{ name:"Tablet",value:7,color:P.GOLD }];
  const sourceData = [
    { source:"Google", sessions:42000, pct:48 },
    { source:"Direct", sessions:18200, pct:21 },
    { source:"WhatsApp", sessions:14800, pct:17 },
    { source:"Facebook", sessions:7400, pct:8 },
    { source:"Others", sessions:5200, pct:6 },
  ];
  const topPages = [
    { url:"/delhi-aqi-412", views:24400, bounce:"31%", time:"2:42" },
    { url:"/modi-virodhi-dal", views:18900, bounce:"38%", time:"3:10" },
    { url:"/nifty-23450", views:14200, bounce:"41%", time:"1:55" },
    { url:"/bole-free", views:11800, bounce:"22%", time:"5:30" },
    { url:"/manipur-violence", views:9200, bounce:"36%", time:"2:18" },
  ];

  return (
    <div style={{ animation:"fadeIn .3s" }}>
      <SectionHead icon="📈" label="Advanced Analytics" color={P.BLUE} sub="Traffic · Users · Revenue · Behavior · Real-time data" />

      {/* Range selector */}
      <div style={{ display:"flex",gap:6,marginBottom:20 }}>
        {["24h","7d","30d","90d"].map(r=>(
          <button key={r} className="btn" onClick={()=>setRange(r)} style={{ background:range===r?P.BLUE:P.CARD2,color:range===r?P.WHITE:P.MUTED,border:`1px solid ${range===r?P.BLUE:P.BORDER2}`,padding:"6px 14px",fontSize:11 }}>{r}</button>
        ))}
      </div>

      {/* KPIs */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        <StatBox icon="👁" label="Total Views" value="1,58,600" sub="Last 7 days" color={P.WHITE} trend={14} />
        <StatBox icon="👤" label="Unique Users" value="36,000" sub="Last 7 days" color={P.TEAL} trend={9} />
        <StatBox icon="📱" label="Sessions" value="87,400" sub="Avg 2.4 pages/session" color={P.BLUE} trend={7} />
        <StatBox icon="⏱" label="Avg Time" value="2m 54s" sub="On site" color={P.GOLD} trend={-3} />
      </div>

      {/* Charts row 1 */}
      <div style={{ display:"grid",gridTemplateColumns:"3fr 2fr",gap:16,marginBottom:16 }}>
        <Card>
          <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📈 Traffic Overview</div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={analyticsData}>
              <defs>
                <linearGradient id="vg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={P.BLUE} stopOpacity={.3}/><stop offset="95%" stopColor={P.BLUE} stopOpacity={0}/></linearGradient>
                <linearGradient id="ug" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={P.TEAL} stopOpacity={.3}/><stop offset="95%" stopColor={P.TEAL} stopOpacity={0}/></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={P.BORDER} />
              <XAxis dataKey="day" tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background:P.CARD2,border:`1px solid ${P.BORDER2}`,borderRadius:6,fontSize:11 }} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize:11,color:P.MUTED }} />
              <Area type="monotone" dataKey="views" stroke={P.BLUE} fill="url(#vg)" strokeWidth={2} name="Views" />
              <Area type="monotone" dataKey="users" stroke={P.TEAL} fill="url(#ug)" strokeWidth={2} name="Users" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>📱 Device Split</div>
          <ResponsiveContainer width="100%" height={140}>
            <PieChart>
              <Pie data={deviceData} dataKey="value" cx="50%" cy="50%" outerRadius={60} innerRadius={35}>
                {deviceData.map((d,i)=><Cell key={i} fill={d.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background:P.CARD2,border:`1px solid ${P.BORDER2}`,borderRadius:6,fontSize:11 }} />
            </PieChart>
          </ResponsiveContainer>
          {deviceData.map(d=>(
            <div key={d.name} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6,fontSize:12 }}>
              <div style={{ display:"flex",alignItems:"center",gap:7 }}>
                <div style={{ width:10,height:10,borderRadius:2,background:d.color }}></div>
                <span style={{ color:P.MUTED,fontFamily:"sans-serif" }}>{d.name}</span>
              </div>
              <span style={{ color:P.WHITE,fontFamily:"sans-serif",fontWeight:600 }}>{d.value}%</span>
            </div>
          ))}
        </Card>
      </div>

      {/* Revenue Chart */}
      <Card style={{ marginBottom:16 }}>
        <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>💰 Ad Revenue Breakdown</div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={revenueData}>
            <CartesianGrid strokeDasharray="3 3" stroke={P.BORDER} />
            <XAxis dataKey="month" tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill:P.MUTED,fontSize:10 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background:P.CARD2,border:`1px solid ${P.BORDER2}`,borderRadius:6,fontSize:11 }} formatter={v=>`₹${v.toLocaleString()}`} />
            <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize:11,color:P.MUTED }} />
            <Bar dataKey="display" fill={P.GOLD} name="Display" radius={[3,3,0,0]} />
            <Bar dataKey="native" fill={P.BLUE} name="Native" radius={[3,3,0,0]} />
            <Bar dataKey="video" fill={P.TEAL} name="Video" radius={[3,3,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Traffic sources + Top pages */}
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:16 }}>
        <Card>
          <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>🌐 Traffic Sources</div>
          {sourceData.map(s=>(
            <div key={s.source} style={{ marginBottom:12 }}>
              <div style={{ display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:12 }}>
                <span style={{ color:P.WHITE }}>{s.source}</span>
                <span style={{ color:P.MUTED,fontFamily:"sans-serif" }}>{s.sessions.toLocaleString()} ({s.pct}%)</span>
              </div>
              <div style={{ height:5,background:P.BORDER2,borderRadius:3 }}>
                <div style={{ height:"100%",width:`${s.pct}%`,background:P.BLUE,borderRadius:3 }}></div>
              </div>
            </div>
          ))}
        </Card>

        <Card>
          <div style={{ fontSize:13,fontWeight:700,marginBottom:14 }}>🏆 Top Pages</div>
          {topPages.map((p,i)=>(
            <div key={p.url} style={{ display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:i<topPages.length-1?`1px solid ${P.BORDER}`:"none",fontSize:12 }}>
              <span style={{ fontSize:14,fontWeight:800,color:i===0?P.GOLD:P.MUTED,fontFamily:"sans-serif",minWidth:18 }}>{i+1}</span>
              <div style={{ flex:1,minWidth:0 }}>
                <div style={{ color:P.WHITE,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontFamily:"monospace",fontSize:11 }}>{p.url}</div>
                <div style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",marginTop:2 }}>Bounce: {p.bounce} • Avg: {p.time}</div>
              </div>
              <span style={{ color:P.TEAL,fontWeight:700,fontFamily:"sans-serif",whiteSpace:"nowrap" }}>{p.views.toLocaleString()}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════ MAIN APP ══════════════════════════════════════════ */
export default function DelhinamaMega() {
  const [tab, setTab] = useState("dashboard");
  const [theme, setTheme] = useState({ name:"Delhinama Classic", primary:"#C41E28", accent:"#C8962E", bg:"#060608", font:"Noto Sans Devanagari", fontSize:15, layout:"grid" });
  const [toast, setToast] = useState({ msg:"", type:"success" });
  const [articles, setArticles] = useState([]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const showToast = (msg, type="success") => { setToast({ msg, type }); setTimeout(()=>setToast({ msg:"", type:"" }),3000); };

  useEffect(()=>{
    dbGet("dnh:theme",null).then(t=>{ if(t) setTheme(t); });
  },[]);

  /* ── DASHBOARD ── */
  const Dashboard = () => (
    <div style={{ animation:"fadeIn .3s" }}>
      <div style={{ marginBottom:20 }}>
        <div style={{ fontSize:20,fontWeight:700,color:P.WHITE }}>नमस्ते, Admin 👋</div>
        <div style={{ fontSize:12,color:P.MUTED,fontFamily:"sans-serif",marginTop:3 }}>दिल्लीनामा के सभी systems normal हैं • {new Date().toLocaleDateString("hi-IN",{weekday:"long",day:"numeric",month:"long"})}</div>
      </div>

      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20 }}>
        <StatBox icon="📰" label="खबरें" value="5" sub="3 live, 2 draft" color={P.GOLD} trend={12} />
        <StatBox icon="👁" label="Views (Today)" value="24,400" color={P.WHITE} trend={18} />
        <StatBox icon="💰" label="Ad Revenue" value="₹46,600" sub="This month" color={P.GREEN} trend={8} />
        <StatBox icon="🔔" label="Subscribers" value="3,24,000" color={P.TEAL} trend={3} />
      </div>

      {/* System Status */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:20 }}>
        {[
          { label:"Website (delhinama.com)", status:"online", ping:"24ms", icon:"🌐" },
          { label:"API Server (EC2)", status:"online", ping:"12ms", icon:"⚙️" },
          { label:"Database (RDS)", status:"online", ping:"8ms", icon:"💾" },
          { label:"Cloudflare CDN", status:"online", ping:"4ms", icon:"🛡️" },
          { label:"Push Service (FCM)", status:"online", ping:"42ms", icon:"🔔" },
          { label:"Redis Cache", status:"online", ping:"2ms", icon:"⚡" },
        ].map(s=>(
          <div key={s.label} className="rh" style={{ background:P.CARD,border:`1px solid ${P.BORDER}`,borderRadius:8,padding:"10px 14px",display:"flex",alignItems:"center",gap:10,cursor:"default" }}>
            <span style={{ fontSize:16 }}>{s.icon}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12,fontWeight:600,color:P.WHITE }}>{s.label}</div>
              <div style={{ fontSize:10,color:P.MUTED,fontFamily:"sans-serif",marginTop:1 }}>Ping: {s.ping}</div>
            </div>
            <div style={{ display:"flex",alignItems:"center",gap:5 }}>
              <span style={{ width:7,height:7,borderRadius:"50%",background:P.GREEN,animation:"pulse 2s infinite" }}></span>
              <span style={{ fontSize:10,color:P.GREEN,fontFamily:"sans-serif",fontWeight:600 }}>Online</span>
            </div>
          </div>
        ))}
      </div>

      {/* Quick access cards */}
      <div style={{ fontSize:13,fontWeight:700,color:P.WHITE,marginBottom:14 }}>🚀 Quick Access</div>
      <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12 }}>
        {MODULES.slice(1).map(m=>(
          <div key={m.id} onClick={()=>setTab(m.id)} style={{ background:P.CARD,border:`1px solid ${m.color}22`,borderRadius:10,padding:"16px 14px",cursor:"pointer",transition:"all .2s",textAlign:"center" }} className="rh">
            <div style={{ fontSize:26,marginBottom:8 }}>{m.icon}</div>
            <div style={{ fontSize:12,fontWeight:700,color:P.WHITE }}>{m.label}</div>
            <div style={{ width:30,height:2,background:m.color,margin:"8px auto 0",borderRadius:1 }}></div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div style={{ background:P.BG,minHeight:"100vh",display:"flex",color:P.WHITE,fontFamily:"'Noto Sans Devanagari',sans-serif" }}>
      <style>{css}</style>

      {/* ── SIDEBAR ── */}
      <div style={{ width:sidebarCollapsed?60:220,background:P.CARD,borderRight:`1px solid ${P.BORDER}`,display:"flex",flexDirection:"column",flexShrink:0,transition:"width .25s" }}>
        {/* Logo */}
        <div style={{ padding:sidebarCollapsed?"16px 14px":"18px 16px",borderBottom:`1px solid ${P.BORDER}`,display:"flex",alignItems:"center",justifyContent:"space-between" }}>
          {!sidebarCollapsed && (
            <div>
              <div style={{ fontSize:17,fontWeight:900,color:P.R }}>दिल्लीनामा</div>
              <div style={{ fontSize:7.5,color:P.GOLD,letterSpacing:3,fontFamily:"sans-serif",marginTop:2 }}>ADMIN PANEL v2</div>
            </div>
          )}
          <button onClick={()=>setSidebarCollapsed(!sidebarCollapsed)} style={{ background:"transparent",border:"none",color:P.MUTED,cursor:"pointer",fontSize:16,padding:2 }}>
            {sidebarCollapsed?"→":"←"}
          </button>
        </div>

        {/* Nav */}
        <div style={{ flex:1,padding:"8px 6px",overflowY:"auto" }}>
          {MODULES.map(m=>(
            <div key={m.id} onClick={()=>setTab(m.id)} title={sidebarCollapsed?m.label:""} style={{ display:"flex",alignItems:"center",gap:10,padding:sidebarCollapsed?"10px":"9px 10px",borderRadius:8,cursor:"pointer",marginBottom:2,background:tab===m.id?m.color+"22":"transparent",borderLeft:tab===m.id?`3px solid ${m.color}`:"3px solid transparent",transition:"all .15s",justifyContent:sidebarCollapsed?"center":"flex-start" }}>
              <span style={{ fontSize:16,flexShrink:0 }}>{m.icon}</span>
              {!sidebarCollapsed && <span style={{ fontSize:12,fontWeight:tab===m.id?700:500,color:tab===m.id?P.WHITE:P.MUTED,whiteSpace:"nowrap" }}>{m.label}</span>}
            </div>
          ))}
        </div>

        {/* Bottom */}
        {!sidebarCollapsed && (
          <div style={{ padding:"10px 8px",borderTop:`1px solid ${P.BORDER}` }}>
            <div style={{ display:"flex",alignItems:"center",gap:8,padding:"8px 10px",borderRadius:8,cursor:"pointer",color:P.MUTED,fontSize:12 }}>
              <span>🚪</span><span>Logout</span>
            </div>
          </div>
        )}
      </div>

      {/* ── MAIN ── */}
      <div style={{ flex:1,overflowY:"auto",overflowX:"hidden",display:"flex",flexDirection:"column" }}>
        {/* Top bar */}
        <div style={{ background:P.CARD,borderBottom:`1px solid ${P.BORDER}`,padding:"10px 24px",display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,zIndex:50,flexShrink:0 }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <span style={{ fontSize:16 }}>{MODULES.find(m=>m.id===tab)?.icon}</span>
            <span style={{ fontSize:14,fontWeight:700 }}>{MODULES.find(m=>m.id===tab)?.label}</span>
            <span style={{ width:6,height:6,borderRadius:"50%",background:P.GREEN,animation:"pulse 2s infinite" }}></span>
            <span style={{ fontSize:10,color:P.GREEN,fontFamily:"sans-serif" }}>All Systems Normal</span>
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:12 }}>
            <button onClick={()=>setTab("push")} style={{ background:P.GREEN+"22",border:`1px solid ${P.GREEN}44`,borderRadius:7,padding:"5px 12px",color:P.GREEN,fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"sans-serif",display:"flex",alignItems:"center",gap:5 }}>
              🔔 Send Push
            </button>
            <div style={{ width:32,height:32,borderRadius:"50%",background:P.R+"33",border:`1.5px solid ${P.R}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14 }}>👑</div>
          </div>
        </div>

        <div style={{ padding:22, flex:1 }}>
          {tab==="dashboard" && <Dashboard />}
          {tab==="ai"        && <AIModule />}
          {tab==="security"  && <SecurityModule />}
          {tab==="infra"     && <InfraModule />}
          {tab==="theme"     && <ThemeModule theme={theme} setTheme={setTheme} />}
          {tab==="ads"       && <AdsModule />}
          {tab==="reels"     && <ReelsModule />}
          {tab==="push"      && <PushModule />}
          {tab==="analytics" && <AnalyticsModule />}
        </div>
      </div>

      <Toast msg={toast.msg} type={toast.type} />
    </div>
  );
}
